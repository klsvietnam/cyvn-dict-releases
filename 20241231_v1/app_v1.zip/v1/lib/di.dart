import 'package:vgisc_glossary/app/exceptions/di_exception.dart';

class DI {
  static final Map<Type, Object> _instances = <Type, Object>{};

  static void put<T>(T instance) {
    _instances.putIfAbsent(T, () => instance as Object);
  }

  static T get<T>() {
    if (_instances[T] != null) {
      return _instances[T] as T;
    }

    throw DiException('Instance of type $T is not initialized.');
  }
}
