import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:sizer/sizer.dart';
import 'package:universal_platform/universal_platform.dart';
import 'package:vgisc_glossary/app/utils/device_utils.dart';
import 'package:vgisc_glossary/presentation/notifiers/index.dart';
import 'package:vgisc_glossary/presentation/routes.dart';
import 'package:windows_single_instance/windows_single_instance.dart';

import 'app/base/index.dart';
import 'app/base/app_settings.dart';

void main(List<String> args) async {
  WidgetsFlutterBinding.ensureInitialized();

  await Future.wait([
    EasyLocalization.ensureInitialized(),

    
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.manual,
      overlays: [
        SystemUiOverlay.top, 
        
      ],
    ),
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
  ]);

  debugPrint('Starting ...............');

  if (UniversalPlatform.isWindows) {
    
    await WindowsSingleInstance.ensureSingleInstance(
      args,
      '${AppConstants.appIdentifier}.${AppSettings.env}',
      onSecondWindow: (secondArgs) {
        debugPrint('$secondArgs');
      },
      bringWindowToFront: true,
    );
  }

  final mainApp = MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (context) => AppNotifier()),
      ChangeNotifierProvider(create: (context) => TabNotifier()),
      if (DeviceUtils.isMobile) ChangeNotifierProvider(create: (context) => DictionaryNotifier()),
      if (DeviceUtils.isDesktop) ChangeNotifierProvider(create: (_) => DesktopDictionaryNotifier()),
    ],
    child: EasyLocalization(
      supportedLocales: gSupportedLocales,
      path: 'assets/translations',
      fallbackLocale: gFallbackLocale,
      startLocale: gStartLocale,
      child: GlobalLoaderOverlay(
        child: const MyApp(),
        overlayWidgetBuilder: (context) => const ColoredBox(
          color: Color(0x80000000),
          child: Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(KlsColors.primary),
            ),
          ),
        ),
      ),
    ),
  );

  if (kDebugMode) {
    runApp(mainApp);
  } else {
    
    await SentryFlutter.init(
      (options) {
        options.dsn = AppSettings.sentryDsn;
        options.environment = AppSettings.env;
        options.tracesSampleRate = AppSettings.sentryTraceSampleRate;
        options.profilesSampleRate = AppSettings.sentryProfileSampleRate;
      },
      appRunner: () => runApp(mainApp),
    );
  }
}

class MyApp extends StatelessWidget {
  static final log = Logger((MyApp).toString());

  const MyApp({super.key});

  
  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (context, orientation, screenType) => Listener(
        onPointerDown: (_) {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus && currentFocus.focusedChild != null) {
            currentFocus.focusedChild?.unfocus();
          }
        },
        child: MaterialApp.router(
          scaffoldMessengerKey: globalScaffoldMessengerKey,
          debugShowCheckedModeBanner: false,
          
          
          checkerboardOffscreenLayers: true,
          title: 'VGISC Glossary',
          localizationsDelegates: context.localizationDelegates,
          supportedLocales: context.supportedLocales,
          locale: context.locale,
          routerConfig: appRoutes,
          theme: AppThemes.light,
        ),
      ),
    );
  }
}
