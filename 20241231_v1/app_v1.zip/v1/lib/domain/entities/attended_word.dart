import 'package:floor/floor.dart';
import 'package:json_annotation/json_annotation.dart';

part 'attended_word.g.dart';




@JsonSerializable()
class AttendedWord {
  final int? id;

  final int wordId;

  final bool? isViewed;

  final DateTime? viewAt;

  final bool? isSaved;

  final DateTime? savedAt;

  final DateTime? lastUpdateTime;

  AttendedWord({
    required this.id,
    required this.wordId,
    this.isViewed = false,
    this.viewAt,
    this.isSaved = false,
    this.savedAt,
    this.lastUpdateTime,
  });

  factory AttendedWord.fromJson(Map<String, dynamic> json) => _$AttendedWordFromJson(json);
  Map<String, dynamic> toJson() => _$AttendedWordToJson(this);

  
  AttendedWord copyWith({
    int? id,
    int? wordId,
    bool? isViewed,
    DateTime? viewAt,
    bool? isSaved,
    DateTime? savedAt,
    DateTime? lastUpdateTime,
  }) {
    return AttendedWord(
      id: id ?? this.id,
      wordId: wordId ?? this.wordId,
      isViewed: isViewed,
      viewAt: viewAt,
      isSaved: isSaved ?? this.isSaved,
      savedAt: savedAt ?? this.savedAt,
      lastUpdateTime: lastUpdateTime ?? this.lastUpdateTime,
    );
  }

  @override
  String toString() {
    return 'AttendedWord{id: $id, word_id: $wordId, seen: $isViewed, saved: $isSaved, last update: $lastUpdateTime}';
  }
}
