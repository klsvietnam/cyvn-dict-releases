import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:vgisc_glossary/app/base/app_constants.dart';

part 'app_language.g.dart';

@JsonSerializable()
@HiveType(typeId: HiveIds.appLanguage)
class AppLanguage {
  @HiveField(0)
  final String languageCode;

  @HiveField(1)
  final String countryCode;

  @HiveField(2)
  final String displayText;

  AppLanguage({required this.languageCode, required this.countryCode, required this.displayText});

  Locale get locale => Locale(languageCode, countryCode);

  factory AppLanguage.fromJson(Map<String, dynamic> json) => _$AppLanguageFromJson(json);

  Map<String, dynamic> toJson() => _$AppLanguageToJson(this);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other.runtimeType != runtimeType) {
      return false;
    }
    return other is AppLanguage && other.languageCode == languageCode && other.countryCode == countryCode;
  }

  @override
  int get hashCode => Object.hash(languageCode, countryCode);

  @override
  String toString() {
    return 'AppLanguage{languageCode: $languageCode, countryCode: $countryCode, displayText: $displayText}';
  }
}

extension LocaleEx on Locale {
  bool get isVietnamese => languageCode == 'vi';
  bool get isEnglish => languageCode == 'en';
}
