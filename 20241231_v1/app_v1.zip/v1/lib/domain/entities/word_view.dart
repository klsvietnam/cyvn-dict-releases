import 'package:vgisc_glossary/app/base/app_constants.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:floor/floor.dart';

import '../../app/utils/string_utils.dart';

class WordView {
  final int id;
  final String? english;
  final String? vietnamese;

  
  final String? abbreviation;

  
  final String explanation;

  
  final String? synonym;

  
  final bool? deleted;

  @ColumnInfo(name: 'attended_id')
  final int? attendedId;

  @ColumnInfo(name: 'seen')
  final bool? isViewed;
  @ColumnInfo(name: 'seen_at')
  final DateTime? viewAt;

  @ColumnInfo(name: 'saved')
  final bool? isSaved;
  @ColumnInfo(name: 'saved_at')
  final DateTime? savedAt;

  String get html {
    final wordTitle1 = english ?? '';
    final wordTitle2 = vietnamese ?? '';
    var wordAbbreviation = '';
    if ((abbreviation ?? '').isNotEmpty) {
      wordAbbreviation = ' ($abbreviation)';
    }

    final htmlContent = AppConstants.htmlTemplate
        .replaceAll('{{ref_link_prefix}}', AppConstants.refLinkPrefix)
        .replaceAll('{{word_title_1}}', wordTitle1)
        .replaceAll('{{word_title_2}}', wordTitle2)
        .replaceAll('{{word_abbreviation}}', wordAbbreviation)
        .replaceAll('{{word_explanation}}', explanation);

    return htmlContent;
  }

  String? get shareContent => [
        if (StringUtils.isNotEmpty(english)) "${'views.word.english'.tr()}: $english",
        if (StringUtils.isNotEmpty(abbreviation)) "${'views.word.abbreviation'.tr()}: $abbreviation",
        if (StringUtils.isNotEmpty(vietnamese)) "${'views.word.vietnamese'.tr()}: $vietnamese",
        "${'views.word.explanation'.tr()}: ${StringUtils.stripHtmlTags(explanation)}",
      ].join('\r\n');

  String get firstChar => StringUtils.isEmpty(english?.trim()) ? '' : english!.trim()[0].toUpperCase();

  
  String get displayText => english ?? abbreviation ?? vietnamese ?? '';

  
  bool isMatch(String query) {
    final lowercaseQuery = query.toLowerCase();
    return (StringUtils.isNotEmpty(english) && english!.toLowerCase().contains(lowercaseQuery)) ||
            (StringUtils.isNotEmpty(abbreviation) && abbreviation!.toLowerCase().contains(lowercaseQuery)) ||
            (StringUtils.isNotEmpty(vietnamese) && vietnamese!.toLowerCase().contains(lowercaseQuery))
        
        ;
  }

  int compareTo(WordView other) {
    int c1 = StringUtils.compare(english, other.english);
    if (c1 != 0) {
      return c1;
    }

    int c2 = StringUtils.compare(abbreviation, other.abbreviation);
    if (c2 != 0) {
      return c2;
    }

    final c3 = StringUtils.compare(vietnamese, other.vietnamese);
    if (c3 != 0) {
      return c3;
    }

    return 0;
  }

  WordView({
    required this.id,
    required this.english,
    required this.vietnamese,
    required this.abbreviation,
    required this.explanation,
    required this.synonym,
    this.deleted = false,
    this.attendedId,
    this.isViewed = false,
    this.viewAt,
    this.isSaved = false,
    this.savedAt,
  });

  WordView copyWith({
    int? id,
    String? english,
    String? vietnamese,
    String? abbreviation,
    String? explanation,
    String? synonym,
    bool? deleted,
    int? attendedId,
    bool? isViewed,
    DateTime? viewAt,
    bool? isSaved,
    DateTime? savedAt,
  }) =>
      WordView(
        id: id ?? this.id,
        english: english ?? this.english,
        vietnamese: vietnamese ?? this.vietnamese,
        abbreviation: abbreviation ?? this.abbreviation,
        explanation: explanation ?? this.explanation,
        synonym: synonym ?? this.synonym,
        deleted: deleted ?? this.deleted,
        attendedId: attendedId ?? this.attendedId,
        isViewed: isViewed ?? this.isViewed,
        viewAt: viewAt ?? this.viewAt,
        isSaved: isSaved ?? this.isSaved,
        savedAt: savedAt ?? this.savedAt,
      );

  @override
  String toString() {
    return 'WordView{id: $id, en: $english, vi: $vietnamese, abbr: $abbreviation, seen: $isViewed, saved: $isSaved}';
  }
}
