// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'attended_word.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AttendedWord _$AttendedWordFromJson(Map<String, dynamic> json) => AttendedWord(
      id: (json['id'] as num?)?.toInt(),
      wordId: (json['wordId'] as num).toInt(),
      isViewed: json['isViewed'] as bool? ?? false,
      viewAt: json['viewAt'] == null
          ? null
          : DateTime.parse(json['viewAt'] as String),
      isSaved: json['isSaved'] as bool? ?? false,
      savedAt: json['savedAt'] == null
          ? null
          : DateTime.parse(json['savedAt'] as String),
      lastUpdateTime: json['lastUpdateTime'] == null
          ? null
          : DateTime.parse(json['lastUpdateTime'] as String),
    );

Map<String, dynamic> _$AttendedWordToJson(AttendedWord instance) =>
    <String, dynamic>{
      'id': instance.id,
      'wordId': instance.wordId,
      'isViewed': instance.isViewed,
      'viewAt': instance.viewAt?.toIso8601String(),
      'isSaved': instance.isSaved,
      'savedAt': instance.savedAt?.toIso8601String(),
      'lastUpdateTime': instance.lastUpdateTime?.toIso8601String(),
    };
