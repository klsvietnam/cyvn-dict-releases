// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'web_attended_word.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class WebAttendedWordAdapter extends TypeAdapter<WebAttendedWord> {
  @override
  final int typeId = 4;

  @override
  WebAttendedWord read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return WebAttendedWord(
      id: fields[0] as int?,
      wordId: fields[1] as int,
      isViewed: fields[2] as bool?,
      viewAt: fields[3] as DateTime?,
      isSaved: fields[4] as bool?,
      savedAt: fields[5] as DateTime?,
      lastUpdateTime: fields[6] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, WebAttendedWord obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.wordId)
      ..writeByte(2)
      ..write(obj.isViewed)
      ..writeByte(3)
      ..write(obj.viewAt)
      ..writeByte(4)
      ..write(obj.isSaved)
      ..writeByte(5)
      ..write(obj.savedAt)
      ..writeByte(6)
      ..write(obj.lastUpdateTime);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is WebAttendedWordAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
