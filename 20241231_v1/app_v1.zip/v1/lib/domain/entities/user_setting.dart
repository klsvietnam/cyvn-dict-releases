import 'package:vgisc_glossary/app/base/app_constants.dart';
import 'package:hive/hive.dart';
import 'package:json_annotation/json_annotation.dart';

import 'app_language.dart';

part 'user_setting.g.dart';

@HiveType(typeId: HiveIds.userSettings)
@JsonSerializable(explicitToJson: true)
class UserSetting {
  @JsonKey(name: "lang")
  @HiveField(0)
  final AppLanguage selectedLang;

  @HiveField(1)
  final int theme; 

  UserSetting({required this.selectedLang, this.theme = 0});

  factory UserSetting.defaults() {
    return UserSetting(selectedLang: gSupportedLanguages[0]);
  }

  UserSetting copyWith({
    AppLanguage? selectedLang,
    int? theme,
  }) {
    return UserSetting(
      selectedLang: selectedLang ?? this.selectedLang,
      theme: theme ?? this.theme,
    );
  }

  factory UserSetting.fromJson(Map<String, dynamic> json) => _$UserSettingFromJson(json);

  Map<String, dynamic> toJson() => _$UserSettingToJson(this);
}
