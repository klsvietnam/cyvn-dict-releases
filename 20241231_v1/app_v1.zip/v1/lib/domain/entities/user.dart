import 'package:hive/hive.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:vgisc_glossary/app/base/app_constants.dart';

part 'user.g.dart';

@JsonSerializable()
@HiveType(typeId: HiveIds.user)
class User {
  @HiveField(0)
  final int? id;

  @HiveField(1)
  final String name;

  @HiveField(2)
  final String fullName;

  @HiveField(3)
  final String? email;

  @HiveField(4)
  final String phoneNumber;

  @HiveField(5)
  final int? languageId;

  @HiveField(6)
  final List<int>? roleIds;

  User(this.id, this.name, this.fullName, this.email, this.phoneNumber, this.languageId, this.roleIds);

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);

  Map<String, dynamic> toJson() => _$UserToJson(this);

  @override
  String toString() {
    return 'User{id: $id, name: $fullName, phone: $phoneNumber}';
  }
}
