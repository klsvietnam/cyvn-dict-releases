import 'package:floor/floor.dart';
import 'package:hive/hive.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:vgisc_glossary/app/base/app_constants.dart';

part 'web_attended_word.g.dart';










@HiveType(typeId: HiveIds.attendedWords)
class WebAttendedWord {
  @HiveField(0)
  final int? id;

  @HiveField(1)
  final int wordId;

  @HiveField(2)
  final bool? isViewed;

  @HiveField(3)
  final DateTime? viewAt;

  @HiveField(4)
  final bool? isSaved;

  @HiveField(5)
  final DateTime? savedAt;

  @HiveField(6)
  final DateTime? lastUpdateTime;

  WebAttendedWord({
    required this.id,
    required this.wordId,
    this.isViewed = false,
    this.viewAt,
    this.isSaved = false,
    this.savedAt,
    this.lastUpdateTime,
  });

  
  WebAttendedWord copyWith({
    int? id,
    int? wordId,
    bool? isViewed,
    DateTime? viewAt,
    bool? isSaved,
    DateTime? savedAt,
    DateTime? lastUpdateTime,
  }) {
    return WebAttendedWord(
      id: id ?? this.id,
      wordId: wordId ?? this.wordId,
      isViewed: isViewed,
      viewAt: viewAt,
      isSaved: isSaved ?? this.isSaved,
      savedAt: savedAt ?? this.savedAt,
      lastUpdateTime: lastUpdateTime ?? this.lastUpdateTime,
    );
  }

  @override
  String toString() {
    return 'WebAttendedWord{id: $id, word_id: $wordId, seen: $isViewed, saved: $isSaved, last update: $lastUpdateTime}';
  }
}
