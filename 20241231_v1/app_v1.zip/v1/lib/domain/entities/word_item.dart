import 'package:floor/floor.dart';
import 'package:json_annotation/json_annotation.dart';

part 'word_item.g.dart';

@JsonSerializable()
class WordItem {
  final int? id;

  final String english;
  final String vietnamese;

  
  final String? abbreviation;

  
  final String explanation;

  
  final String? synonym;

  
  final bool? deleted;

  WordItem({
    required this.id,
    required this.english,
    required this.vietnamese,
    this.abbreviation,
    required this.explanation,
    this.synonym,
    this.deleted = false,
  });

  factory WordItem.fromJson(Map<String, dynamic> json) =>
      _$WordItemFromJson(json);
  Map<String, dynamic> toJson() => _$WordItemToJson(this);

  @override
  String toString() {
    return '{id: $id, english: $english, vietnamese: $vietnamese}';
  }
}
