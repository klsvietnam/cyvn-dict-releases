class DomainDependencies {
  static Future<void> init() async {}
}
