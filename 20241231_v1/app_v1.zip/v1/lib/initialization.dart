import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:logging/logging.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';
import 'package:vgisc_glossary/app/logging/log_init.dart';
import 'package:vgisc_glossary/data/datasources/local/shared_pref/pref_helper.dart';
import 'package:vgisc_glossary/di.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/routes.dart';

import 'app/base/app_constants.dart';
import 'app/base/app_dependencies.dart';
import 'app/base/app_settings.dart';

class Initialization {
  Initialization._();

  static final _instance = Initialization._();

  static Initialization get instance => _instance;
  static bool isInitialized = false;

  Future<void> initialize(BuildContext context) async {
    if (!isInitialized) {
      isInitialized = true;
      await LogInitialization.init();

      final logger = Logger((Initialization).toString());
      logger.info('Init start. Settings: $AppSettings');

      AppConstants.htmlTemplate = (await rootBundle.loadString('assets/template.html'));

      
      var fontSizeCss = '';
      if (UniversalPlatform.isIOS) {
        fontSizeCss = 'html {font-size: ${kIosInitialFontSize}px;}';
      } else if (UniversalPlatform.isDesktopOrWeb) {
        fontSizeCss = 'html {font-size: ${kWindowInitialFontSize}px;}';
      }
      AppConstants.htmlTemplate = AppConstants.htmlTemplate.replaceAll('{{additional_style}}', fontSizeCss);

      logger.fine('Init step 1');
      await AppDI.init();

      
      

      logger.fine('Init step 2');
      
      final app = context.read<AppNotifier>();
      final sharedPref = DI.get<PrefHelper>();
      final userSetting = await sharedPref.getUserSettings();
      if (userSetting != null) {
        app.applySettings(language: userSetting.selectedLang);
        logger.fine('Init step 3 - apply user settings');
      }

      if (UniversalPlatform.isWindows) {
        await __initForWindows();
        logger.fine('Init step 4 - init for Windows');
      }

      app.initialized = true;
      appRoutes.refresh();
      logger.info('Init done.');
    } else {
      debugPrint('Initialized. Ignore ...');
    }
  }

  static WebViewEnvironment? webViewEnvironment;

  static Future<void> __initForWindows() async {
    final availableVersion = await WebViewEnvironment.getAvailableVersion();
    assert(availableVersion != null,
        'Failed to find an installed WebView2 Runtime or non-stable Microsoft Edge installation.');

    final dir = await getApplicationDocumentsDirectory();

    webViewEnvironment =
        await WebViewEnvironment.create(settings: WebViewEnvironmentSettings(userDataFolder: dir.path));
  }
}
