import 'package:collection/collection.dart';
import 'package:logging/logging.dart';
import 'package:vgisc_glossary/app/index.dart';
import 'package:vgisc_glossary/presentation/notifiers/index.dart';
import 'package:vgisc_glossary/presentation/views/tabs/directory_test_desktop.dart';
import 'package:vgisc_glossary/presentation/views/tabs/home_tab_desktop.dart';
import 'package:vgisc_glossary/presentation/views/tabs/saved_words_tab_desktop.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class HomeScreenDesktop extends StatefulWidget {
  const HomeScreenDesktop({super.key});

  @override
  State<HomeScreenDesktop> createState() => _HomeScreenDesktopState();
}

class _HomeScreenDesktopState extends State<HomeScreenDesktop> {
  static final logger = Logger((HomeScreenDesktop).toString());

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await context.read<DesktopDictionaryNotifier>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    logger.fine('Building ...');
    return Scaffold(
      body: Consumer<TabNotifier>(
        builder: (context, tabNotifier, _) => IndexedStack(
          index: tabNotifier.currentTabIndex,
          children: <Widget>[
            HomeDesktopTab(),
            if (!kIsWeb) const SavedWordsTabDesktop(),
            
            if (kDebugMode) const DirectoryTestDesktop(),
          ],
        ),
      ),
      bottomNavigationBar: kIsWeb ? null : buildBottomNavigationBar(),
    );
  }

  Widget buildBottomNavigationBar() {
    const double iconSize = 24;
    const double selectedIconSize = iconSize + 8;
    final iconList = [
      (icon: Icons.search, tooltip: 'menu.search'.tr()),
      (icon: Icons.bookmark, tooltip: 'menu.favourite'.tr()),
      
      if (kDebugMode) (icon: Icons.folder_copy, tooltip: 'Directories'),
    ];

    return Consumer<TabNotifier>(
      builder: (_, tab, __) => BottomAppBar(
        elevation: 8,
        color: KlsColors.primary12,
        padding: const EdgeInsets.symmetric(vertical: 0),
        height: 48,
        child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: iconList
                .mapIndexed((index, item) => IconButton(
                      onPressed: () => tab.currentTabIndex = index,
                      
                      icon: Icon(
                        item.icon,
                        size: tab.currentTabIndex == index ? selectedIconSize : iconSize,
                        color: tab.currentTabIndex == index ? KlsColors.primary : null,
                      ),
                      tooltip: item.tooltip,
                    ))
                .toList()),
      ),
    );
  }
}
