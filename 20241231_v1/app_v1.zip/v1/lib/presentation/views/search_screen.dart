import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/app/utils/string_utils.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/routes.dart';
import 'package:vgisc_glossary/presentation/widgets/common/kls_speech_to_text.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  static final Logger logger = Logger((SearchScreen).toString());
  bool _hasContent = false;

  @override
  void initState() {
    super.initState();

    final controller = context.read<DictionaryNotifier>().controller;

    controller.addListener(() {
      setState(() {
        _hasContent = controller.text.isNotEmpty;
      });
    });
    setState(() {
      _hasContent = controller.text.isNotEmpty;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: __buildAppBar(context),
      body: __buildBody(context),
    );
  }

  Widget __buildBody(BuildContext context) {
    return Container(
      
      height: double.infinity,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage("assets/images/app/dongson.png"),
          fit: BoxFit.fitWidth,
          alignment: Alignment.topCenter,
          repeat: ImageRepeat.noRepeat,
          colorFilter: ColorFilter.mode(
            Colors.white.withOpacity(0.75),
            
            BlendMode.screen,
          ),
        ),
      ),
      child: Consumer<DictionaryNotifier>(
        builder: (context, dict, _) {
          if (dict.hasError) {
            SnackBarUtils.error(dict.errorMessage!);
          } else if (dict.state == DictionaryState.success) {
            if (StringUtils.isNotEmpty(dict.successMessage)) {
              SnackBarUtils.success(dict.successMessage!);
            }
          }

          if (dict.searchItems.isEmpty) {
            return Center(child: Text('common.no_data'.tr(), style: TextStyle(color: KlsColors.primary70)));
          }

          return ListView.separated(
            shrinkWrap: true,
            itemBuilder: (context, index) => WordListItem(
              word: dict.searchItems[index],
              isViewed: true,
              canDelete: false,
              onPressed: (word) {
                dict.changeCurrentDisplayWord(word);
                appRoutes.goNamed(Routes.viewWordFromSearch, extra: word);
              },
            ),
            separatorBuilder: (_, __) => const Divider(),
            itemCount: dict.searchItems.length,
          );
        },
      ),
    );
  }

  AppBar __buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white.withOpacity(_hasContent ? 0.9 : 0.0),
      title: Consumer<DictionaryNotifier>(
        builder: (context, dict, _) {
          final suffixIcon = StringUtils.isNotEmpty(dict.controller.text) ? const Icon(Icons.clear) : Container();

          return TextField(
            controller: dict.controller,
            autofocus: true,
            style: Theme.of(context).textTheme.bodyMedium,
            decoration: InputDecoration(
              hintText: 'views.home.searchWord'.tr(),
              hintStyle: const TextStyle(color: Colors.white30),
              
              
              suffixIcon: StringUtils.isNotEmpty(dict.controller.text)
                  ? GestureDetector(
                      child: suffixIcon,
                      onTap: () {
                        logger.fine('Icon clicked');
                        if (StringUtils.isNotEmpty(dict.controller.text)) {
                          
                          dict.controller.text = '';
                        } else {
                          
                        }
                      },
                    )
                  : null,
            ),
            onChanged: dict.search,
          );
        },
      ),
      actions: [
        Consumer<DictionaryNotifier>(
          builder: (_, dict, __) => KlsSpeechToText(
            onWordDetected: (word) async {
              dict.controller.text = word;
              await dict.search(word);
            },
          ),
        ),
      ],
    );
  }
}
