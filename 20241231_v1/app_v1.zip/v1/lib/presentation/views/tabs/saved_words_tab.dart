import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/app/utils/string_utils.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/notifiers/dictionary_notifier_interface.dart';
import 'package:vgisc_glossary/presentation/routes.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

class SavedWordsTab extends StatefulWidget {
  const SavedWordsTab({super.key});

  @override
  State<SavedWordsTab> createState() => _SavedWordsTabState();
}

class _SavedWordsTabState extends State<SavedWordsTab> {
  static final Logger logger = Logger((SavedWordsTab).toString());

  final TextEditingController _searchQueryController = TextEditingController();
  bool _isSearching = false;
  String searchQuery = '';

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DictionaryNotifier>().getSavedItems();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: __buildAppBar(context),
      body: __buildBody(context),
    );
  }

  AppBar __buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.transparent,
      bottom: PreferredSize(preferredSize: Size.fromHeight(kDefaultPadding), child: Container()),
      title: _isSearching ? _buildSearchField() : Text('views.home.savedWord'.tr()),
      actions: _buildActions(),
    );
  }

  Widget __buildBody(BuildContext context) {
    return Container(
      
      height: double.infinity,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage("assets/images/app/dongson.png"),
          fit: BoxFit.fitWidth,
          alignment: Alignment.topCenter,
          repeat: ImageRepeat.noRepeat,
          colorFilter: ColorFilter.mode(
            Colors.white.withOpacity(0.75),
            
            BlendMode.screen,
          ),
        ),
      ),
      child: Consumer<DictionaryNotifier>(
        builder: (context, dict, _) {
          if (dict.state == DictionaryState.error) {
            SnackBarUtils.error(dict.errorMessage!);
          } else if (dict.state == DictionaryState.success) {
            if (StringUtils.isNotEmpty(dict.successMessage)) {
              SnackBarUtils.success(dict.successMessage!);
            }
          }

          final items = StringUtils.isEmpty(searchQuery)
              ? dict.savedItems
              : dict.savedItems.where((i) => i.isMatch(searchQuery)).toList();

          if (items.isEmpty) {
            logger.fine(
                'Không có thuat ngữ đã lưu, query: $searchQuery, items length: ${items.length}, savedItems length: ${dict.savedItems.length}');
            return Center(child: Text('common.no_data'.tr(), style: TextStyle(color: KlsColors.primary70)));
          }

          return ListView.separated(
            
            shrinkWrap: true,
            itemBuilder: (context, index) => WordListItem(
              word: items[index],
              isSaved: true,
              onPressed: (word) {
                dict.changeCurrentDisplayWord(word);
                appRoutes.goNamed(Routes.viewWordFromHome, extra: word);
              },
              onDeleted: (_, deletedItem) async {
                if (await showAlertDialog(context)) {
                  logger.fine('Now to delete saved word $deletedItem');
                  dict.removeFromFavourite(deletedItem);
                } else {
                  logger.fine('Cancel ========');
                }
              },
            ),
            separatorBuilder: (_, __) => const Divider(),
            itemCount: items.length,
          );
        },
      ),
    );
  }

  Widget _buildSearchField() {
    return TextField(
      controller: _searchQueryController,
      autofocus: true,
      decoration: InputDecoration(
        hintText: 'views.home.searchSavedWord'.tr(),
        border: InputBorder.none,
        hintStyle: const TextStyle(color: Colors.white30),
      ),
      style: TextStyle(fontSize: kDefaultPadding),
      onChanged: (query) => updateSearchQuery(query),
    );
  }

  List<Widget> _buildActions() {
    final iconSize = 22.sp;

    if (_isSearching) {
      return <Widget>[
        Padding(
          padding: EdgeInsets.only(right: kDefaultPadding),
          child: IconButton(
            icon: Icon(Icons.clear, size: iconSize),
            onPressed: () {
              if (_searchQueryController.text.isEmpty) {
                Navigator.pop(context);
                return;
              }
              _clearSearchQuery();
            },
          ),
        ),
      ];
    }

    return <Widget>[
      Padding(
        padding: EdgeInsets.only(right: kDefaultPadding),
        child: IconButton(
          icon: Icon(Icons.search, color: KlsColors.primary, size: iconSize),
          onPressed: _startSearch,
        ),
      ),
    ];
  }

  void _startSearch() {
    ModalRoute.of(context)?.addLocalHistoryEntry(LocalHistoryEntry(onRemove: _stopSearching));

    setState(() {
      _isSearching = true;
    });
  }

  void updateSearchQuery(String newQuery) {
    setState(() {
      searchQuery = newQuery;
    });
  }

  void _stopSearching() {
    _clearSearchQuery();

    setState(() {
      _isSearching = false;
    });
  }

  void _clearSearchQuery() {
    setState(() {
      _searchQueryController.clear();
      updateSearchQuery("");
    });
  }
}
