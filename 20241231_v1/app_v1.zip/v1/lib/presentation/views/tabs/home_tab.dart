import 'package:vgisc_glossary/app/base/index.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/routes.dart';
import 'package:vgisc_glossary/presentation/widgets/recent_search_list.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

class HomeTab extends StatefulWidget {
  HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final Logger logger = Logger((HomeTab).toString());

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DictionaryNotifier>().getRecentViewItems();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body: NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxScrolled) {
          return <Widget>[
            KlsSliverHeaderAppBar(
              onLanguageIconClicked: () {
                showModalBottomSheet(
                  context: context,
                  backgroundColor: Colors.white,
                  isScrollControlled: true,
                  builder: (_) => Wrap(
                    children: [
                      Consumer<AppNotifier>(
                        builder: (_, app, __) => KlsLanguageSelectionDialog(
                          languages: gSupportedLanguages,
                          selectedLanguage: app.userSettings.selectedLang,
                          onChanged: (lang) async {
                            logger.fine('Change lang to ${lang.languageCode}, $lang');
                            await Future.wait<void>([
                              app.applySettings(language: lang),
                              context.setLocale(lang.locale),
                              
                              WidgetsBinding.instance.performReassemble(),
                            ]);
                          },
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            Consumer<DictionaryNotifier>(
              builder: (context, dictNotifier, _) => KlsSliverSearchAppBar(
                controller: dictNotifier.controller,
                onTap: (query) {
                  appRoutes.goNamed(Routes.search, extra: query);
                },
              ),
            ),
          ];
        },
        body: buildBody(context),
      ),
    );
  }

  Widget buildBody(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: SizedBox(height: kDefaultPadding),
        ),

        
        SliverToBoxAdapter(
          child: __buildSavedItems(context),
        ),

        
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: kDefaultPadding),
            child: const Divider(),
          ),
        ),

        
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: kDefaultPadding),
            child: Text(
              'views.home.recentSearch'.tr(),
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontSize: KlsSizes.textHeader, fontWeight: FontWeight.w500),
            ),
          ),
        ),
        Consumer<DictionaryNotifier>(
          builder: (_, dict, __) => SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                return WordListItem(
                  word: dict.recentViewItems[index],
                  isViewed: true,
                  onDeleted: (_, deletedItem) async {
                    logger.fine('deleting $deletedItem');
                    if (await showAlertDialog(context)) {
                      logger.fine('Now to delete recent searched word $deletedItem');
                      dict.deleteRecentViewItems(deletedItem);
                    } else {
                      logger.fine('Cancel ========');
                    }
                  },
                  onPressed: (word) {
                    dict.changeCurrentDisplayWord(word);
                    appRoutes.goNamed(Routes.viewWordFromHome, extra: word);
                  },
                );
              },
              childCount: dict.recentViewItems.length,
            ),
          ),
        ),
      ],
    );
  }

  
  Widget __buildSavedItems(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Consumer<TabNotifier>(
          builder: (_, tab, __) => TextButton(
            onPressed: () => tab.currentTabIndex = 1,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.grey.withOpacity(0.2),
              textStyle: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontSize: KlsSizes.textNormal,
                    fontWeight: FontWeight.normal,
                    foreground: Paint()..color = Theme.of(context).textTheme.titleSmall?.color ?? Colors.black38,
                  ),
              padding: EdgeInsets.symmetric(horizontal: 20.sp, vertical: 12.sp),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.bookmark,
                  color: KlsColors.primary,
                ),
                const SizedBox(width: 8),
                Text('views.home.savedWord'.tr()),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
