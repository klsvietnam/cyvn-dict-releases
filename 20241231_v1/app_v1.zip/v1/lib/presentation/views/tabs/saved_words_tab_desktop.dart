import 'dart:math';

import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/widgets/desktop/index.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

import '../../../domain/entities/word_view.dart';

class SavedWordsTabDesktop extends StatefulWidget {
  const SavedWordsTabDesktop({super.key});

  static final Logger logger = Logger((SavedWordsTabDesktop).toString());
  static const double minSearchTextWidth = 600;

  @override
  State<SavedWordsTabDesktop> createState() => _SavedWordsTabDesktopState();
}

class _SavedWordsTabDesktopState extends State<SavedWordsTabDesktop> {
  
  InAppWebViewController? _savedWebController;
  final TextEditingController _savedController = TextEditingController();
  WordView? _current;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: __buildAppBar(context),
      body: __buildBody(context),
    );
  }

  Widget __buildBody(BuildContext context) {
    return ResizableSplitView(
      left: Consumer<DesktopDictionaryNotifier>(
        builder: (_, dict, __) {
          final query = _savedController.text;

          final displayingItems =
              query.isEmpty ? dict.savedItems : dict.savedItems.where((w) => w.isMatch(query)).toList();

          return DictionaryListDesktop(
            displayingWords: displayingItems,
            onTap: (newWord) {
              _savedWebController?.loadData(data: newWord.html);
              setState(() {
                _current = newWord;
              });
            },
          );
        },
      ),
      right: Consumer<DesktopDictionaryNotifier>(
        builder: (context, dict, _) => WebViewDesktop(
          word: _current,
          onCreated: (controller) => _savedWebController = controller,
          onLinkClicked: (linkedWord) {
            dict.findByWord(linkedWord).then((newWordItem) {
              if (newWordItem != null) {
                SavedWordsTabDesktop.logger.fine('Change word to $newWordItem');

                if (context.mounted) {
                  _savedWebController?.loadData(data: newWordItem.html);
                  setState(() {
                    _current = newWordItem;
                  });
                }
              } else {
                SnackBarUtils.error('views.word.word_not_found'.tr(namedArgs: {'word': linkedWord}));
              }
            });
          },
        ),
      ),
      initialLeftWidth: max(MediaQuery.of(context).size.width * 0.3, 300),
      leftWidthMin: 300,
      leftWidthMax: 500,
    );
  }

  PreferredSize __buildAppBar(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return PreferredSize(
      preferredSize: const Size.fromHeight(80), 
      child: KlsHeaderDesktopAppBar(children: [
        if (screenWidth > SavedWordsTabDesktop.minSearchTextWidth + 200)
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 16),
              child: Text(
                'menu.favourite'.tr(),
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ),
        Align(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Consumer<DesktopDictionaryNotifier>(
              builder: (_, dict, __) => Container(
                constraints:
                    BoxConstraints(maxWidth: max(screenWidth / 3 * 2, SavedWordsTabDesktop.minSearchTextWidth)),
                child: SearchWidgetDesktop(
                  controller: _savedController,
                  hintText: 'views.search.input_keyword'.tr(),
                  fillColor: Colors.white,
                  onClearText: () {
                    setState(() {
                      _savedController.text = '';
                    });
                  },
                  onTextChanged: (_) {
                    
                    setState(() {});
                  },
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
