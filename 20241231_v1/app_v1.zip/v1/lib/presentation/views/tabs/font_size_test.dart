import 'package:vgisc_glossary/app/index.dart';
import 'package:flutter/material.dart';

class FontSizeTest extends StatelessWidget {
  const FontSizeTest({super.key});

  @override
  Widget build(BuildContext context) {
    final scaler = MediaQuery.of(context).textScaler;

    return Scaffold(
      appBar: AppBar(title: const Text('Test font sizes'), backgroundColor: KlsColors.primary),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text('Normal text, scale: $scaler'),
            ...KlsSizes.getTestSizes(context)
                .entries
                .map<Text>((entry) => Text(entry.key, style: TextStyle(fontSize: entry.value))),
          ],
        ),
      ),
    );
  }
}
