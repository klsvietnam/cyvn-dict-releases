import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:vgisc_glossary/app/base/index.dart';
import 'package:vgisc_glossary/domain/entities/app_language.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/widgets/desktop/index.dart';

class HomeDesktopTab extends StatelessWidget {
  final Logger logger = Logger((HomeDesktopTab).toString());

  HomeDesktopTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: __buildAppBar(context),
      body: __buildBody(context),
      
    );
  }

  PreferredSize __buildAppBar(BuildContext context) {
    const logoSize = 54.0;
    final horizontalPadding = kDefaultPadding;
    final appNameLeftPadding = horizontalPadding + logoSize + 16;

    return PreferredSize(
      preferredSize: const Size.fromHeight(80), 
      child: KlsHeaderDesktopAppBar(children: [
        
        Align(
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: EdgeInsets.only(left: horizontalPadding),
            child: Image.asset(
              'assets/images/app/logo_cyvn.png', 
              width: logoSize,
              height: logoSize,
              fit: BoxFit.contain,
            ),
          ),
        ),

        Align(
          alignment: Alignment.centerRight,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            
            children: [
              
              Padding(
                padding: EdgeInsets.only(left: appNameLeftPadding),
                child: __buildAppName(context),
              ),

              
              Padding(
                padding: EdgeInsets.only(right: horizontalPadding),
                child: __buildLanguageSelectionButton(context),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget __buildBody(BuildContext context) {
    return Stack(
      children: [
        
        Positioned(
          bottom: 0, 
          left: 0,
          right: 0,
          child: Image.asset(
            'assets/images/app/desktop/lotus.png', 
            height: kIsWeb ? null : 200, 
            fit: BoxFit.cover, 
          ),
        ),

        
        ResizableSplitView(
          initialLeftWidth: max(MediaQuery.of(context).size.width * 0.3, 300),
          leftWidthMin: 300,
          leftWidthMax: 500,
          left: __buildLeftSide(context),
          right: __buildRightSide(context),
        ),
      ],
    );
  }

  Widget __buildLeftSide(BuildContext context) {
    return Column(
      children: [
        
        Consumer<DesktopDictionaryNotifier>(
          builder: (context, dict, __) {
            if (dict.isLoading) {
              context.loaderOverlay.show();
            } else {
              context.loaderOverlay.hide();
            }

            if (dict.hasError) {
              SnackBarUtils.error(dict.errorMessage ?? '');
            }

            return SearchWidgetDesktop(
              controller: dict.controller,
              hintText: 'views.home.searchWord'.tr(),
              onClearText: dict.clearSearch,
              onTextChanged: dict.search,
            );
          },
        ),

        
        Expanded(
          child: Consumer<DesktopDictionaryNotifier>(
            builder: (_, dict, __) => DictionaryListDesktop(
              displayingWords: dict.displayingItems,
              onTap: (word) => dict.changeCurrentDisplayWord(word),
            ),
          ),
        ),
      ],
    );
  }

  Widget __buildRightSide(BuildContext context) {
    return Consumer<DesktopDictionaryNotifier>(
      builder: (context, dict, _) => WebViewDesktop(
        word: dict.current,
        onCreated: (controller) => dict.webController = controller,
        onLinkClicked: (linkedWord) {
          dict.findByWord(linkedWord).then((newWordItem) {
            if (newWordItem != null) {
              
              logger.fine('Change word to $newWordItem');

              if (context.mounted) {
                dict
                  ..addToRecentViewItems(newWordItem)
                  ..changeCurrentDisplayWord(newWordItem);
              }
              
            } else {
              SnackBarUtils.error('views.word.word_not_found'.tr(namedArgs: {'word': linkedWord}));
            }
          });
        },
      ),
    );
  }

  Widget __buildLanguageSelectionButton(BuildContext context) {
    return GestureDetector(
      onTapDown: (TapDownDetails details) async {
        final app = context.read<AppNotifier>();
        final lang = await _showLanguagePopupMenu(context, details.globalPosition);

        if (lang != null) {
          logger.fine('Change lang to ${lang.languageCode}, $lang');
          await Future.wait<void>([
            app.applySettings(language: lang),
            context.setLocale(lang.locale),
            
            WidgetsBinding.instance.performReassemble(),
          ]);
        }
      },
      child: KlsCircleIcon(
        Icons.language_outlined,
        iconSize: 16.sp,
        padding: 6.sp,
      ),
    );
  }

  Future<AppLanguage?> _showLanguagePopupMenu(BuildContext context, Offset offset) async {
    double left = offset.dx;
    double top = offset.dy;
    final app = context.read<AppNotifier>();

    return await showMenu(
      context: context,
      position: RelativeRect.fromLTRB(left, top, left + 20, top + 20),
      color: Colors.white,
      items: gSupportedLanguages.map((lang) {
        final isSelected = app.userSettings.selectedLang == lang;
        const double flagSize = 24;

        return PopupMenuItem(
          value: lang,
          padding: EdgeInsets.symmetric(horizontal: kDefaultPadding),
          child: Row(
            children: [
              SizedBox(
                key: const Key('countryFlags_CircularFlag_SizedBox'),
                width: flagSize,
                height: flagSize,
                child: ClipOval(
                  child: SvgPicture.asset(
                    'assets/images/app/flags/${lang.countryCode.toLowerCase()}.svg',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SizedBox(width: kDefaultPadding),
              Text(lang.displayText, style: Theme.of(context).textTheme.labelMedium),
              const Spacer(),
              if (isSelected) const Icon(Icons.check_circle, color: KlsColors.primary),
            ],
          ),
        );
      }).toList(),
      elevation: 8.0,
    );
  }

  Widget __buildAppName(BuildContext context) {
    final fontCompany = context.locale.isVietnamese ? 20.0 : 18.0;
    final fontAppName = context.locale.isVietnamese ? 14.0 : 14.0;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'app.companyName'.tr(),
          style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.white, fontSize: fontCompany),
        ),
        Text(
          'app.name'.tr(),
          style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.white, fontSize: fontAppName),
        )
      ],
    );
  }

  OutlineInputBorder _border(Color color) => OutlineInputBorder(
        borderSide: BorderSide(width: 0.5, color: color),
        borderRadius: BorderRadius.circular(100),
      );
}
