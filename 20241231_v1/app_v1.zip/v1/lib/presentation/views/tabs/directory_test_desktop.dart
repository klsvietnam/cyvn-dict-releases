import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

class DirectoryTestDesktop extends StatefulWidget {
  const DirectoryTestDesktop({super.key});

  @override
  State<DirectoryTestDesktop> createState() => _DirectoryTestDesktopState();
}

class _DirectoryTestDesktopState extends State<DirectoryTestDesktop> {
  List<String>? dirList;

  @override
  Widget build(BuildContext context) {
    MediaQuery.of(context).size.shortestSide;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Show directory info'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () async {
              getDirInfo().then((value) {
                setState(() {
                  dirList = value;
                });
              });
            },
            child: const Text('Get dir info'),
          ),
          ...?dirList?.map((k) => ListTile(title: Text(k)))
        ],
      ),
    );
  }

  Future<List<String>> getDirInfo() async {
    final map = {
      'cache': getApplicationCacheDirectory(),
      'documents': getApplicationDocumentsDirectory(),
      'support': getApplicationSupportDirectory(),
      'download': getDownloadsDirectory(),
      'library': getLibraryDirectory(),
      'temporary': getTemporaryDirectory(),
    };

    return await Future.wait(map.keys.map((key) async {
      try {
        final xxx = (await map[key])?.path;
        return '$key : $xxx';
      } catch (e, st) {
        return '$key: $e';
      }
    }));
  }
}
