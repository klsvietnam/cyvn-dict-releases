import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:vgisc_glossary/presentation/index.dart';

import '../../initialization.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  static final logger = Logger((SplashScreen).toString());
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    debugPrint('Build SplashScreen');

    return FutureBuilder(
      future: Initialization.instance.initialize(context),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        final appState = context.read<AppNotifier>();
        logger.fine('Current state: ${snapshot.connectionState}, init: ${appState.initialized}');
        if (snapshot.connectionState != ConnectionState.done || !appState.initialized) {
          return Scaffold(
            body: Center(
              child: Lottie.asset(
                'assets/animations/dictionary.json',
                width: 200,
                height: 240,
              ),
            ),
          );
        } else {
          return const SizedBox();
        }
      },
    );
  }
}
