import 'package:vgisc_glossary/app/index.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';


class WordScreen extends StatefulWidget {
  const WordScreen({super.key});

  @override
  State<WordScreen> createState() => _WordScreenState();
}

class _WordScreenState extends State<WordScreen> {
  static final logger = Logger((WordScreen).toString());
  InAppWebViewController? webController;

  @override
  void initState() {
    super.initState();

    
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.manual,
      overlays: [
        SystemUiOverlay.top, 
        
      ],
    );

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final dict = Provider.of<DictionaryNotifier>(context, listen: false);
      dict.addToRecentViewItems(dict.current!);
    });

    
    logger.fine("Init OK *********************");
  }

  @override
  Widget build(BuildContext context) {
    logger.fine('build word screen');

    return Scaffold(
      appBar: AppBar(
        title: Consumer<DictionaryNotifier>(builder: (context, dict, child) => Text(dict.current?.english ?? '')),
      ),
      body: __buildBody(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: __buildFloatingActionButtons(),
    );
  }

  Widget __buildFloatingActionButtons() {
    return Padding(
      padding: EdgeInsets.all(kDefaultPadding),
      child: Consumer<DictionaryNotifier>(
        builder: (_, dict, __) {
          final currentWord = dict.current!;
          final saved = currentWord.isSaved ?? false;

          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              FloatingActionButton(
                
                onPressed: () async {
                  final isSaved = await dict.isItemSaved(currentWord.id);
                  if (!isSaved) {
                    
                    await dict.addToFavourite(currentWord);
                    SnackBarUtils.success('views.word.msg_save_successful'.tr());
                  } else {
                    await dict.removeFromFavourite(currentWord);
                    SnackBarUtils.success('views.word.msg_delete_successful'.tr());
                  }
                },
                heroTag: 'bookmark',
                child: Icon(
                  saved ? Icons.bookmark : Icons.bookmark_outline,
                  color: saved ? KlsColors.primary : null,
                ),
              ),
              FloatingActionButton(
                
                onPressed: () async {
                  final content = currentWord.shareContent;
                  if (StringUtils.isNotEmpty(content)) {
                    final result = await Share.share(
                      content!,
                      subject: 'views.word.share_subject'.tr(namedArgs: {'word': currentWord.displayText}),
                    );

                    
                    
                    
                    
                    
                    
                  }
                },
                heroTag: 'share',
                child: const Icon(Icons.share),
              )
            ],
          );
        },
      ),
    );
  }

  Widget __buildBody(BuildContext context) {
    return Consumer<DictionaryNotifier>(builder: (context, dict, _) {
      if (dict.state == DictionaryState.loading) {
        return const Center(child: CircularProgressIndicator());
      } else if (dict.state == DictionaryState.error) {
        SnackBarUtils.error(dict.errorMessage ?? 'Error');
      }

      String htmlContent = dict.current?.html ?? '';

      logger.info('html in wordview: $htmlContent');

      return InAppWebView(
          initialData: InAppWebViewInitialData(data: htmlContent),
          initialSettings: InAppWebViewSettings(
            
            
            supportZoom: false,
            useShouldOverrideUrlLoading: true,
            transparentBackground: true,
            
          ),
          onWebViewCreated: (InAppWebViewController controller) {
            webController = controller;
          },
          shouldOverrideUrlLoading: (inAppWebViewController, navigationAction) async {
            var url = navigationAction.request.url!.toString();

            logger.info('Clicked on $url, navi: $navigationAction');

            if (url.startsWith(AppConstants.refLinkPrefix)) {
              final linkedWord = Uri.decodeFull(url).replaceAll(AppConstants.refLinkPrefix, '');

              logger.info('Clicked on $linkedWord');

              dict.findByWord(linkedWord).then((newWordItem) {
                if (newWordItem != null) {
                  
                  logger.info('Change word to $newWordItem');

                  if (context.mounted) {
                    dict
                      ..addToRecentViewItems(newWordItem)
                      ..changeCurrentDisplayWord(newWordItem);
                  }
                  webController!.loadData(data: newWordItem.html);
                } else {
                  SnackBarUtils.error('views.word.word_not_found'.tr(namedArgs: {'word': linkedWord}));
                }
              });

              return NavigationActionPolicy.CANCEL;
            }

            return NavigationActionPolicy.ALLOW;
          });
    });
  }
}
