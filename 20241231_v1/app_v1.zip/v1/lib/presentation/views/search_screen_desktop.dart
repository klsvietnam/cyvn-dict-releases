import 'dart:math';

import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/app/utils/string_utils.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/routes.dart';
import 'package:vgisc_glossary/presentation/widgets/desktop/kls_header_app_bar_desktop.dart';
import 'package:vgisc_glossary/presentation/widgets/recent_search_list.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

class SearchScreenDesktop extends StatelessWidget {
  const SearchScreenDesktop({super.key});

  static final Logger logger = Logger((SearchScreenDesktop).toString());
  static const double minSearchTextWidth = 600;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: __buildAppBar(context),
      body: __buildBody(context),
    );
  }

  Widget __buildBody(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Consumer<DictionaryNotifier>(
      builder: (context, dict, _) {
        if (dict.hasError) {
          SnackBarUtils.error(dict.errorMessage!);
        } else if (dict.state == DictionaryState.success) {
          if (StringUtils.isNotEmpty(dict.successMessage)) {
            SnackBarUtils.success(dict.successMessage!);
          }
        }

        if (StringUtils.isEmpty(dict.controller.text)) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: max(100, screenWidth / 6)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 15.sp),
                Text('views.search.recent_words'.tr(),
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
                const Divider(),
                const RecentSearchList(),
              ],
            ),
          );
        }

        if (dict.searchItems.isEmpty) {
          return Center(child: Text('common.no_data'.tr(), style: TextStyle(color: KlsColors.primary70)));
        }

        return ListView.separated(
          shrinkWrap: true,
          itemBuilder: (context, index) => WordListItem(
            word: dict.searchItems[index],
            isViewed: true,
            canDelete: false,
            onPressed: (word) {
              dict.changeCurrentDisplayWord(word);
              appRoutes.goNamed(Routes.viewWordFromSearch, extra: word);
            },
          ),
          separatorBuilder: (_, __) => const Divider(),
          itemCount: dict.searchItems.length,
        );
      },
    );
  }

  PreferredSize __buildAppBar(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return PreferredSize(
      preferredSize: const Size.fromHeight(80), 
      child: KlsHeaderDesktopAppBar(children: [
        if (screenWidth > minSearchTextWidth + 200)
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 16),
              child: Text(
                'views.search.title'.tr(),
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ),
        Align(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: __buildSearchText(context),
          ),
        ),
      ]),
    );
  }

  Widget __buildSearchText(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Consumer<DictionaryNotifier>(
      builder: (context, dict, _) {
        final suffixIcon = StringUtils.isNotEmpty(dict.controller.text)
            ? GestureDetector(
                child: const Padding(
                  padding: EdgeInsets.all(16),
                  child: const Icon(Icons.clear),
                ),
                onTap: () {
                  if (StringUtils.isNotEmpty(dict.controller.text)) {
                    
                    dict.clearSearch();
                  } else {
                    
                    logger.fine('fine, do nothing');
                  }
                },
              )
            : const Icon(Icons.search, color: KlsColors.primary);

        return Container(
          constraints: BoxConstraints(maxWidth: max(width / 3 * 2, minSearchTextWidth)),
          child: TextField(
            controller: dict.controller,
            autofocus: true,
            style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.normal),
            decoration: InputDecoration(
              hintText: 'views.search.input_keyword'.tr(),
              hintStyle: const TextStyle(color: Colors.grey),
              filled: true,
              
              fillColor: Colors.blueGrey[50],
              
              border: OutlineInputBorder(
                borderSide: const BorderSide(width: 0.5, color: KlsColors.primary),
                borderRadius: BorderRadius.circular(100),
              ),
              prefixIcon: GestureDetector(
                onTap: context.pop,
                child: const Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(Icons.arrow_back),
                ),
              ),
              suffixIcon: suffixIcon,
            ),
            onChanged: dict.search,
          ),
        );
      },
    );
  }
}
