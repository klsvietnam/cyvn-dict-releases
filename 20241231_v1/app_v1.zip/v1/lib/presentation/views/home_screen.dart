import 'package:vgisc_glossary/app/index.dart';
import 'package:vgisc_glossary/presentation/notifiers/index.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

import 'tabs/index.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<TabNotifier>(
        builder: (context, tabNotifier, _) => IndexedStack(
          index: tabNotifier.currentTabIndex,
          children: <Widget>[
            HomeTab(),
            const SavedWordsTab(),
            
          ],
        ),
      ),
      bottomNavigationBar: buildBottomNavigationBar(),
    );
  }

  Widget buildBottomNavigationBar() {
    final iconSize = 22.sp;

    return Consumer<TabNotifier>(
      builder: (context, tabNotifier, _) => BottomNavigationBar(
        onTap: (int value) => tabNotifier.currentTabIndex = value,
        currentIndex: tabNotifier.currentTabIndex,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
        backgroundColor: Colors.white,
        selectedFontSize: KlsSizes.textNormal,
        unselectedFontSize: KlsSizes.textNormal,
        unselectedItemColor: const Color(0xFF4d4d4d),
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.search, size: iconSize),
            label: 'menu.search'.tr(),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bookmark, size: iconSize),
            label: 'menu.favourite'.tr(),
          ),
          
          
          
          
        ],
      ),
    );
  }
}
