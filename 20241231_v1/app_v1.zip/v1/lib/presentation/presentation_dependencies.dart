import 'package:vgisc_glossary/di.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:logging/logging.dart';

class PresentationDependencies {
  static final Logger logger = Logger((PresentationDependencies).toString());

  static Future<void> init() async {
    logger.fine('Start init presentation dependencies');

    DI.put<AppNotifier>(AppNotifier());
    DI.put<TabNotifier>(TabNotifier());
    DI.put<DictionaryNotifier>(DictionaryNotifier());

    logger.fine('Finish init presentation dependencies');
  }
}
