import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class KlsCircleIcon extends StatelessWidget {
  final Color? backgroundColor;
  final IconData icon;
  final Color? iconColor;
  final double? iconSize;
  final double? padding;

  const KlsCircleIcon(
    this.icon, {
    super.key,
    this.backgroundColor = Colors.white,
    this.iconColor = KlsColors.primary,
    this.iconSize,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(100),
      ),
      padding: EdgeInsets.all(padding ?? 4.sp),
      child: Icon(
        icon,
        color: iconColor,
        size: iconSize ?? 20.sp,
      ),
    );
  }
}
