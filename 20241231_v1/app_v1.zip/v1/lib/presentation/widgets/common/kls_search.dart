import 'dart:async';

import 'package:flutter/material.dart';
import 'package:logging/logging.dart';


typedef SuggestionsCallback<T> = Future<List<T>?> Function(String search);


typedef SuggestionsItemBuilder<T> = Widget Function(
  BuildContext context,
  T value,
);











class KlsSearch<T> extends SearchDelegate<T> {
  static final logger = Logger((KlsSearch).toString());

  final SuggestionsCallback<T> fetchSuggestions;
  final SuggestionsItemBuilder<T> suggestionBuilder;

  

  KlsSearch({
    super.searchFieldLabel,
    super.searchFieldStyle,
    super.searchFieldDecorationTheme,
    super.keyboardType,
    super.textInputAction,
    required this.fetchSuggestions,
    required this.suggestionBuilder,
  });

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
          
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () => Navigator.of(context).pop(),
      
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder(
      future: fetchSuggestions(query),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          final results = snapshot.data ?? [];
          return ListView.builder(
            itemCount: results.length,
            itemBuilder: (context, index) => suggestionBuilder(context, results[index]),
          );
        } else {
          return const CircularProgressIndicator();
        }
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return FutureBuilder(
      future: fetchSuggestions(query),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          final results = snapshot.data ?? [];

          logger.fine('Searched [$query], with results: $results');
          return results.isNotEmpty
              ? ListView.builder(
                  itemCount: results.length,
                  itemBuilder: (context, index) => this.suggestionBuilder(context, results[index]),
                )

              
              
              
              
              
              
              
              
              
              
              : Container();
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      },
    );
  }

  @override
  ThemeData appBarTheme(BuildContext context) {
    final theme = Theme.of(context);
    return theme.copyWith(
      appBarTheme: theme.appBarTheme.copyWith(
        toolbarHeight: 80,
        
        backgroundColor: Colors.transparent,
      ),
      inputDecorationTheme: searchFieldDecorationTheme ??
          InputDecorationTheme(
            hintStyle: searchFieldStyle ?? theme.inputDecorationTheme.hintStyle,
            
          ),
    );
  }
}
