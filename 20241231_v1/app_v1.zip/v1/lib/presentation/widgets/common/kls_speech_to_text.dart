import 'package:vgisc_glossary/app/index.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

typedef OnWordDetected = void Function(String);

class KlsSpeechToText extends StatefulWidget {
  final OnWordDetected? onWordDetected;

  const KlsSpeechToText({super.key, this.onWordDetected});

  @override
  State<KlsSpeechToText> createState() => _KlsSpeechToTextState();
}

class _KlsSpeechToTextState extends State<KlsSpeechToText> {
  static final logger = Logger((KlsSpeechToText).toString());
  final SpeechToText _speechToText = SpeechToText();
  bool _speechEnabled = false;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _initSpeech();
  }

  @override
  void dispose() {
    _speechToText.stop();
    super.dispose();
  }

  
  void _initSpeech() async {
    try {
      _speechEnabled = await _speechToText.initialize(
        onError: (obj) {
          logger.warning('Khong the speech duoc $obj');
        },
        onStatus: (s) {
          logger.fine('Speech status $s');
        },
        debugLogging: true,
      );
    } catch (e) {
      logger.info('Không khởi tạo được speech2text', e);
    }
    setState(() {});
    if (kDebugMode) {
      final locales = await _speechToText.locales();
      logger.fine('Supported locales: [${locales.map((e) => '{id: ${e.localeId}, name: ${e.name}}').join(', ')}]');
    }
    logger.fine('SpeechToText enabled: $_speechEnabled');
  }

  
  void _startListening() async {
    await _speechToText.listen(localeId: 'en-US', onResult: _onSpeechResult);
    setState(() {
      _isListening = true;
    });
  }

  
  
  
  
  void _stopListening() async {
    await _speechToText.stop();
    setState(() {
      _isListening = false;
    });
  }

  
  
  void _onSpeechResult(SpeechRecognitionResult result) {
    if (widget.onWordDetected != null) {
      widget.onWordDetected!(result.recognizedWords);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: !_speechEnabled ? null : (_speechToText.isNotListening ? _startListening : _stopListening),
      child: Padding(
        padding: EdgeInsets.only(right: kDefaultPadding),
        child: Icon(
          _isListening ? Icons.mic : Icons.mic_off,
          color: _speechEnabled ? null : Colors.red,
        ),
      ),
    );
  }
}
