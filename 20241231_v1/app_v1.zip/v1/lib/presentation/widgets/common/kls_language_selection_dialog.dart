import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/domain/entities/app_language.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class KlsLanguageSelectionDialog extends StatelessWidget {
  const KlsLanguageSelectionDialog({
    super.key,
    required this.languages,
    this.selectedLanguage,
    required this.onChanged,
    this.backgroundColor = Colors.white,
  });

  final List<AppLanguage> languages;
  final AppLanguage? selectedLanguage;
  final Function(AppLanguage value) onChanged;
  final Color? backgroundColor;

  @override
  Widget build(BuildContext context) {
    final selectedTextStyle =
        Theme.of(context).textTheme.titleSmall!.copyWith(color: KlsColors.primary, fontWeight: FontWeight.bold);
    return SimpleDialog(
      title: Text(tr('common.select_language')),
      backgroundColor: backgroundColor,
      children: languages.map((lang) {
        final isSelected = selectedLanguage == lang;
        const double flagSize = 24;

        return SimpleDialogOption(
          padding: const EdgeInsets.symmetric(
            horizontal: 24.0,
            vertical: 14,
          ),
          child: Container(
            padding: EdgeInsets.symmetric(vertical: kDefaultPadding / 2, horizontal: kDefaultPadding),
            decoration: BoxDecoration(
              color: isSelected ? KlsColors.primary.withOpacity(0.1) : null,
              borderRadius: const BorderRadius.all(Radius.circular(8)),
            ),
            child: Row(
              children: [
                SizedBox(
                  key: const Key('countryFlags_CircularFlag_SizedBox'),
                  width: flagSize,
                  height: flagSize,
                  child: ClipOval(
                    child: SvgPicture.asset(
                      'assets/images/app/flags/${lang.countryCode.toLowerCase()}.svg',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(width: kDefaultPadding),
                Text(lang.displayText),
                const Spacer(),
                if (isSelected) const Icon(Icons.check_circle, color: KlsColors.primary),
              ],
            ),
          ),
          onPressed: () {
            onChanged(lang);
            Navigator.pop(context);
          },
        );
      }).toList(),
    );
  }
}
