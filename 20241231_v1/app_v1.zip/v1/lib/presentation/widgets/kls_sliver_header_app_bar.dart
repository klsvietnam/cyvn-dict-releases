import 'package:universal_platform/universal_platform.dart';

import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/domain/entities/app_language.dart';
import 'package:vgisc_glossary/presentation/widgets/common/kls_circle_icon.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:sizer/sizer.dart';

class KlsSliverHeaderAppBar extends StatelessWidget {
  static final Logger logger = Logger((KlsSliverHeaderAppBar).toString());

  final VoidCallback? onLanguageIconClicked;

  const KlsSliverHeaderAppBar({super.key, this.onLanguageIconClicked});

  @override
  Widget build(BuildContext context) {
    const logoSize = 54.0;
    const appBarHeight = 120.0;

    const bottomPadding = (appBarHeight - logoSize) / 2;
    final horizontalPadding = kDefaultPadding;
    final appNameLeftPadding = horizontalPadding + logoSize + 8;

    final languageSelectionIconSize = 32 + 4.sp;
    final appNameRightPadding = horizontalPadding + languageSelectionIconSize + 8;
    const appNameBottomPadding = bottomPadding;

    final languageSelectionIconBottomPadding = (appBarHeight - languageSelectionIconSize) / 2;
    var fontCompany = context.locale.isVietnamese ? 17.0 : 13.0;
    var fontAppName = context.locale.isVietnamese ? 13.5 : 11.0;
    if (UniversalPlatform.isIOS) {
      fontCompany = context.locale.isVietnamese ? 18.5 : 15.0;
      fontAppName = context.locale.isVietnamese ? 13.5 : 11.5;
    }

    return SliverAppBar(
      expandedHeight: appBarHeight,
      backgroundColor: KlsColors.background,
      floating: false,
      elevation: 0,
      flexibleSpace: FlexibleSpaceBar(
        collapseMode: CollapseMode.parallax,
        background: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/app/mobile/header.png',
              fit: BoxFit.fitWidth,
              color: KlsColors.primary,
              colorBlendMode: BlendMode.dstOver,
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Padding(
                padding: EdgeInsets.only(left: horizontalPadding, bottom: bottomPadding),
                child: Image.asset('assets/images/app/logo_cyvn.png', width: logoSize, height: logoSize),
              ),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: EdgeInsets.only(right: horizontalPadding, bottom: languageSelectionIconBottomPadding),
                child: GestureDetector(
                  onTap: onLanguageIconClicked,
                  child: KlsCircleIcon(
                    Icons.language_outlined,
                    iconSize: 32,
                    padding: 4.sp,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding:
                    EdgeInsets.only(left: appNameLeftPadding, right: appNameRightPadding, bottom: appNameBottomPadding),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'app.companyName'.tr(),
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: Colors.white,
                            fontSize: fontCompany,
                          ),
                    ),
                    Text(
                      'app.name'.tr(),
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: Colors.white,
                            fontSize: fontAppName,
                          ),
                    ),
                    
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
