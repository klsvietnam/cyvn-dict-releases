import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/app/utils/string_utils.dart';
import 'package:vgisc_glossary/presentation/notifiers/dictionary_notifier.dart';
import 'package:vgisc_glossary/presentation/notifiers/dictionary_notifier_interface.dart';
import 'package:vgisc_glossary/presentation/routes.dart';
import 'package:vgisc_glossary/presentation/utils/kls_dialog_utils.dart';
import 'package:vgisc_glossary/presentation/utils/kls_snackbar_utils.dart';
import 'package:vgisc_glossary/presentation/widgets/word_list_item.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class RecentSearchList extends StatefulWidget {
  const RecentSearchList({super.key});

  @override
  State<RecentSearchList> createState() => _RecentSearchListState();
}

class _RecentSearchListState extends State<RecentSearchList> {
  static final Logger logger = Logger((RecentSearchList).toString());

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DictionaryNotifier>().getRecentViewItems();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DictionaryNotifier>(
      builder: (context, dict, _) {
        if (dict.state == DictionaryState.error) {
          SnackBarUtils.error(dict.errorMessage!);
        } else if (dict.state == DictionaryState.success) {
          if (StringUtils.isNotEmpty(dict.successMessage)) {
            SnackBarUtils.success(dict.successMessage!);
          }
        }

        if (dict.recentViewItems.isEmpty) {
          return Center(
            child: Padding(
              padding: EdgeInsets.only(top: kDefaultPadding),
              child: Text('common.no_data'.tr(), style: TextStyle(color: KlsColors.primary70)),
            ),
          );
        }

        
        
        
        
        

        return ListView.separated(
          shrinkWrap: true,
          itemBuilder: (context, index) => WordListItem(
            word: dict.recentViewItems[index],
            isViewed: true,
            onDeleted: (_, deletedItem) async {
              logger.fine('deleting $deletedItem');
              if (await showAlertDialog(context)) {
                logger.fine('Now to delete recent searched word $deletedItem');
                dict.deleteRecentViewItems(deletedItem);
              } else {
                logger.fine('Cancel ========');
              }
            },
            onPressed: (word) {
              dict.changeCurrentDisplayWord(word);
              appRoutes.goNamed(Routes.viewWordFromHome, extra: word);
            },
          ),
          separatorBuilder: (_, __) => const Divider(),
          itemCount: dict.recentViewItems.length,
        );
      },
    );
  }
}
