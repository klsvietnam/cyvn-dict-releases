import 'package:vgisc_glossary/app/index.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:sizer/sizer.dart';

typedef SlidableActionEvent<T> = void Function(BuildContext context, T item);
typedef WordListItemOnAction<T> = void Function(T item);

class WordListItem<T> extends StatelessWidget {
  final WordView word;
  final SlidableActionEvent<WordView>? onDeleted;
  final WordListItemOnAction<WordView>? onPressed;

  final bool isViewed;
  final bool isSaved;
  final bool canDelete;

  const WordListItem({
    super.key,
    required this.word,
    this.isViewed = false,
    this.isSaved = false,
    this.onDeleted,
    this.onPressed,
    this.canDelete = true,
  });

  @override
  Widget build(BuildContext context) {
    final leadingIcon = isViewed
        ? const KlsCircleIcon(
            Icons.history,
            backgroundColor: Color(0xFFE7E7E7),
            iconColor: Color(0xFF666666),
          )
        : null;

    final trailingIcon = isSaved ? const Icon(Icons.bookmark, color: KlsColors.primary) : null;

    final subStyle = Theme.of(context).textTheme.titleSmall?.copyWith(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          fontStyle: FontStyle.normal,
          color: const Color(0xFF999999),
        );

    var titleText = '${word.english}';
    if (StringUtils.isNotEmpty(word.abbreviation)) {
      titleText += ' (${word.abbreviation})';
    }

    final item = ListTile(
      leading: leadingIcon,
      trailing: trailingIcon,
      title: isSaved
          ? RichText(
              text: TextSpan(
                  text: word.english,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(color: KlsColors.primary, fontSize: KlsSizes.textHeader),
                  children: [
                    if (StringUtils.isNotEmpty(word.abbreviation))
                      TextSpan(text: ' (${word.abbreviation})', style: subStyle),
                  ]),
            )
          : Text(titleText),
      subtitle: word.vietnamese != null ? Text(word.vietnamese ?? '') : null,
      onTap: () => onPressed != null ? onPressed!(word) : null,
      
    );

    return canDelete
        ? Slidable(
            endActionPane: ActionPane(motion: const ScrollMotion(), children: [
              SlidableAction(
                backgroundColor: const Color(0xFFFE4A49),
                foregroundColor: Colors.white,
                icon: Icons.delete,
                label: 'buttons.delete'.tr(),
                onPressed: (context) => onDeleted != null ? onDeleted!(context, word) : null,
              ),
            ]),
            child: item,
          )
        : item;
  }
}
