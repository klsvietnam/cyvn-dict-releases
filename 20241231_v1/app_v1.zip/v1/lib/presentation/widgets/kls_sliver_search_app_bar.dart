import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

typedef OnSearchTapped = void Function(String query);

class KlsSliverSearchAppBar extends StatelessWidget {
  final OnSearchTapped? onTap;
  final TextEditingController controller;
  const KlsSliverSearchAppBar({super.key, required this.controller, this.onTap});

  void actionWhenSearching() {
    if (onTap != null) {
      onTap!(controller.text);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      pinned: true,
      backgroundColor: Colors.white70,
      expandedHeight: 32.sp,
      title: Padding(
        padding: EdgeInsets.symmetric(horizontal: kDefaultPadding),
        child: TextField(
          controller: controller,
          style: Theme.of(context).textTheme.bodyMedium,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white54,
            focusColor: KlsColors.primary,
            focusedBorder: _border(KlsColors.primary),
            border: _border(Colors.grey),
            enabledBorder: _border(Colors.grey),
            hintText: 'views.home.searchWord'.tr(),
            hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.normal, fontSize: KlsSizes.textNormal),
            contentPadding: EdgeInsets.symmetric(vertical: 8.sp, horizontal: 16.sp),
            suffixIcon: const Icon(
              Icons.search,
              color: KlsColors.primary,
            ),
          ),
          onTap: actionWhenSearching,
          onChanged: (_) => actionWhenSearching(),
        ),
      ),
    );
  }

  OutlineInputBorder _border(Color color) => OutlineInputBorder(
        borderSide: BorderSide(width: 0.5, color: color),
        borderRadius: BorderRadius.circular(24),
      );
}
