import 'package:flutter/material.dart';
import 'package:logging/logging.dart';

class ResizableSplitView extends StatefulWidget {
  @override
  _ResizableSplitViewState createState() => _ResizableSplitViewState();

  final Widget left;
  final Widget right;
  final double? initialLeftWidth;
  final double? leftWidthMin;
  final double? leftWidthMax;

  const ResizableSplitView({
    super.key,
    required this.left,
    required this.right,
    this.initialLeftWidth,
    this.leftWidthMin,
    this.leftWidthMax,
  });
}

class _ResizableSplitViewState extends State<ResizableSplitView> {
  static final logger = Logger((ResizableSplitView).toString());
  double _leftWidth = 200.0; 

  @override
  void initState() {
    super.initState();
    if (widget.initialLeftWidth != null) {
      _leftWidth = widget.initialLeftWidth!;
    }

    logger.fine(
        'Init with {initialLeftWidth: ${widget.initialLeftWidth}, leftWidthMin: ${widget.leftWidthMin}, leftWidthMax: ${widget.leftWidthMax}}');
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Row(
          children: [
            
            SizedBox(
              width: _leftWidth,
              child: widget.left,
            ),

            
            GestureDetector(
              onHorizontalDragUpdate: (details) {
                setState(() {
                  var newWidth = (_leftWidth + details.delta.dx).clamp(100.0, constraints.maxWidth - 100.0);

                  
                  
                  
                  
                  

                  
                  _leftWidth = newWidth;
                });
              },
              child: Container(
                width: 4,
                color: Colors.grey.shade500,
                child: Center(
                  child: Container(
                    width: 2,
                    color: Colors.grey.shade800,
                  ),
                ),
              ),
            ),

            
            Expanded(child: widget.right),
          ],
        );
      },
    );
  }
}
