import 'package:vgisc_glossary/app/index.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:sizer/sizer.dart';

typedef SlidableActionEvent<T> = void Function(BuildContext context, T item);
typedef WordListItemOnAction<T> = void Function(T item);

class DesktopWordListItem<T> extends StatefulWidget {
  final WordView word;
  final SlidableActionEvent<WordView>? onDeleted;
  final WordListItemOnAction<WordView>? onPressed;

  final bool isViewed;
  final bool isSaved;
  final bool canDelete;

  final bool showSearchIcon;

  const DesktopWordListItem({
    super.key,
    required this.word,
    this.isViewed = false,
    this.isSaved = false,
    this.onDeleted,
    this.onPressed,
    this.canDelete = true,
    this.showSearchIcon = false,
  });

  @override
  State<DesktopWordListItem<T>> createState() => _DesktopWordListItemState<T>();
}

class _DesktopWordListItemState<T> extends State<DesktopWordListItem<T>> {
  bool _isHovered = false; 

  @override
  Widget build(BuildContext context) {
    final leadingIcon = widget.isViewed
        ? const KlsCircleIcon(
            Icons.history,
            backgroundColor: Color(0xFFE7E7E7),
            iconColor: Color(0xFF666666),
          )
        : null;

    final trailingIcon = widget.isSaved ? const Icon(Icons.bookmark, color: KlsColors.primary) : null;

    final subStyle = Theme.of(context).textTheme.titleSmall?.copyWith(
          fontSize: 16,
          fontWeight: FontWeight.w400,
          fontStyle: FontStyle.normal,
          color: const Color(0xFF999999),
        );

    var titleText = '${widget.word.english}';
    if (StringUtils.isNotEmpty(widget.word.abbreviation)) {
      titleText += ' (${widget.word.abbreviation})';
    }

    final item = ListTile(
      leading: widget.showSearchIcon
          ? const KlsCircleIcon(
              Icons.history,
              backgroundColor: Color(0xFFE7E7E7),
              iconColor: Color(0xFF666666),
            )
          : null,
      trailing: trailingIcon,
      title: widget.isSaved
          ? RichText(
              text: TextSpan(
                  text: widget.word.english,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(color: KlsColors.primary, fontSize: KlsSizes.textHeader),
                  children: [
                    if (StringUtils.isNotEmpty(widget.word.abbreviation))
                      TextSpan(text: ' (${widget.word.abbreviation})', style: subStyle),
                  ]),
            )
          : Text(titleText),
      subtitle: widget.word.vietnamese != null ? Text(widget.word.vietnamese ?? '') : null,
      onTap: () => widget.onPressed != null ? widget.onPressed!(widget.word) : null,
      
    );

    return MouseRegion(
      onEnter: (_) {
        setState(() {
          _isHovered = true; 
        });
      },
      onExit: (_) {
        setState(() {
          _isHovered = false; 
        });
      },
      child: item,
    );
  }
}
