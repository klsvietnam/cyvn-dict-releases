import 'dart:math';

import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/app/utils/device_utils.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';

class KlsHeaderDesktopAppBar extends StatelessWidget {
  static final Logger logger = Logger((KlsHeaderDesktopAppBar).toString());

  final List<Widget>? children;

  const KlsHeaderDesktopAppBar({super.key, this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: KlsColors.primaryWindows, 
      child: Stack(
        children: [
          
          Align(
            alignment: Alignment.centerRight,
            child: ColorFiltered(
              colorFilter: const ColorFilter.mode(
                KlsColors.primaryWindows, 
                BlendMode.overlay, 
              ),
              child: Image.asset(
                'assets/images/app/desktop/header_windows.png',
                height: 200, 
                width: max(DeviceUtils.width / 2, 360),
                fit: BoxFit.cover, 
              ),
            ),
          ),

          ...(children ?? []),
        ],
      ),
    );
  }
}
