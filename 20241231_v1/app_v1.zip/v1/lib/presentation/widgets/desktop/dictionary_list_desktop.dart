import "package:collection/collection.dart";
import 'package:vgisc_glossary/app/base/app_themes.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sticky_header/flutter_sticky_header.dart';
import 'package:logging/logging.dart';

import '../../../app/utils/string_utils.dart';


class DictionaryListDesktop extends StatefulWidget {
  const DictionaryListDesktop({
    super.key,
    required this.displayingWords,
    this.onTap,
  });

  final List<WordView> displayingWords;
  final Function(WordView)? onTap;

  @override
  State<DictionaryListDesktop> createState() => _DictionaryListDesktopState();
}

class _DictionaryListDesktopState extends State<DictionaryListDesktop> {
  static final logger = Logger((DictionaryListDesktop).toString());

  
  int? selectedIndex;
  String? selectedGroup;

  @override
  Widget build(BuildContext context) {
    final groupList = groupBy(widget.displayingWords, (item) => item.firstChar);

    final groups = groupList.keys.toList()..sort();
    return CustomScrollView(slivers: groups.map((group) => __buildGroup(group, groupList[group]!)).toList());
  }

  Widget __buildGroup(String group, List<WordView> groupItems) {
    return SliverStickyHeader(
      header: __buildGroupHeader(group),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate(
          (_, index) => __buildGroupItem(index, group, groupItems[index]),
          childCount: groupItems.length,
        ),
      ),
    );
  }

  Widget __buildGroupHeader(String group) {
    return Container(
      height: 48.0,
      color: KlsColors.primary,
      padding: const EdgeInsets.symmetric(horizontal: 12.0),
      alignment: Alignment.centerLeft,
      child: Text(
        group,
        style: const TextStyle(color: Colors.white),
      ),
    );
  }

  Widget __buildGroupItem(int index, String group, WordView word) {
    String title = '${word.english}';
    if (StringUtils.isNotEmpty(word.abbreviation)) {
      title += ' (${word.abbreviation})';
    }
    final isSelected = selectedGroup == group && selectedIndex == index;

    return ListTile(
      tileColor: isSelected ? KlsColors.secondary2 : null,
      title: Text(
        title,
        style: const TextStyle(fontSize: 18),
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: word.vietnamese != null
          ? Text(
              word.vietnamese ?? '',
              style: TextStyle(fontSize: 16, color: isSelected ? Colors.black87 : null),
              overflow: TextOverflow.ellipsis,
            )
          : null,
      
      onTap: () {
        selectedIndex = index;
        selectedGroup = group;
        if (widget.onTap != null) {
          widget.onTap!(word);
        }
      },
    );
  }
}
