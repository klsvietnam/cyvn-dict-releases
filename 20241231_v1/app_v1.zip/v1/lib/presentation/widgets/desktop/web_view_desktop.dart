import 'dart:collection';

import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../app/base/app_constants.dart';
import '../../../app/base/app_themes.dart';
import '../../../app/utils/string_utils.dart';
import '../../../initialization.dart';
import '../../notifiers/desktop_dictionary_notifier.dart';
import '../../notifiers/dictionary_notifier_interface.dart';
import '../../utils/kls_snackbar_utils.dart';

const kTextSizePlaceholder = '{{kTextSizePlaceholder}}';
const kTextSizeSourceJS = """
window.addEventListener('DOMContentLoaded', function(event) {
  document.body.style.fontSize = '${kTextSizePlaceholder}px';
});
""";
final textSizeUserScript = UserScript(
    source: kTextSizeSourceJS.replaceAll(kTextSizePlaceholder, '$kWindowInitialFontSize'),
    injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START);

class WebViewDesktop extends StatefulWidget {
  const WebViewDesktop({
    super.key,
    required this.word,
    this.onCreated,
    this.onLinkClicked,
  });

  final WordView? word;
  final Function(InAppWebViewController)? onCreated;
  final Function(String)? onLinkClicked;

  @override
  State<WebViewDesktop> createState() => _WebViewDesktopState();
}

class _WebViewDesktopState extends State<WebViewDesktop> {
  static final logger = Logger((WebViewDesktop).toString());
  int textSize = kWindowInitialFontSize;

  @override
  Widget build(BuildContext context) {
    return Consumer<DesktopDictionaryNotifier>(
      builder: (_, dict, __) {
        if (dict.state == DictionaryState.loading) {
          return const Center(child: CircularProgressIndicator());
        } else if (dict.state == DictionaryState.error) {
          SnackBarUtils.error(dict.errorMessage ?? 'Error');
        }

        final saved = widget.word?.isSaved ?? false;

        return kIsWeb
            ? Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  __buildActionButtons(dict, saved),
                  Expanded(child: __buildWebView(context)),
                ],
              )
            : Stack(
                children: [
                  __buildWebView(context),
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 16.0, right: 32),
                      child: __buildActionButtons(dict, saved),
                    ),
                  )
                ],
              );
      },
    );
  }

  Widget __buildWebView(BuildContext context) {
    return InAppWebView(
      webViewEnvironment: Initialization.webViewEnvironment,
      initialData: InAppWebViewInitialData(data: widget.word?.html ?? ''),
      initialUserScripts:
          UnmodifiableListView(!kIsWeb && defaultTargetPlatform == TargetPlatform.android ? [] : [textSizeUserScript]),
      initialSettings: InAppWebViewSettings(
        textZoom: textSize,
        supportZoom: true,
        useShouldOverrideUrlLoading: true,
        transparentBackground: true,
        
      ),
      onWebViewCreated: (InAppWebViewController controller) {
        if (widget.onCreated != null) {
          widget.onCreated!(controller);
        }
      },
      shouldOverrideUrlLoading: (inAppWebViewController, navigationAction) async {
        var url = navigationAction.request.url!.toString();

        logger.info('Clicked on $url, navi: $navigationAction');

        if (url.startsWith(AppConstants.refLinkPrefix)) {
          final linkedWord = Uri.decodeFull(url).replaceAll(AppConstants.refLinkPrefix, '').trim();

          logger.info('Clicked on $linkedWord');

          if (widget.onLinkClicked != null) {
            widget.onLinkClicked!(linkedWord);
          }

          return NavigationActionPolicy.CANCEL;
        }

        return NavigationActionPolicy.ALLOW;
      },
    );
  }

  Widget __buildActionButtons(DesktopDictionaryNotifier dict, bool saved) {
    if (widget.word == null) {
      return Container();
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        IconButton(
          onPressed: () async {
            textSize += 2;

            if (!await zoom(dict.webController, textSize)) {
              SnackBarUtils.error('messages.zoom_error'.tr());
            }
          },
          tooltip: 'menu.zoom_in'.tr(),
          icon: const Icon(Icons.zoom_in, size: 30),
          padding: const EdgeInsets.all(16),
        ),
        IconButton(
          onPressed: () async {
            textSize -= 2;

            if (!await zoom(dict.webController, textSize)) {
              SnackBarUtils.error('messages.zoom_error'.tr());
            }
          },
          tooltip: 'menu.zoom_out'.tr(),
          icon: const Icon(Icons.zoom_out, size: 30),
          padding: const EdgeInsets.all(16),
        ),
        IconButton(
          onPressed: () async {
            textSize = kWindowInitialFontSize;

            if (!await zoom(dict.webController, textSize)) {
              SnackBarUtils.error('messages.zoom_error'.tr());
            }
          },
          tooltip: 'menu.zoom_default'.tr(),
          icon: const Icon(Icons.zoom_in_map, size: 30),
          padding: const EdgeInsets.all(16),
        ),
        IconButton(
          onPressed: () async {
            final currentWord = widget.word;
            if (currentWord == null) {
              SnackBarUtils.error('views.word.msg_share_please_choose_a_word'.tr());
              return;
            }

            try {
              await Clipboard.setData(ClipboardData(text: currentWord.shareContent!));
              SnackBarUtils.success('messages.copy_to_clipboard_successful'.tr());
            } on Exception catch (e, stacktrace) {
              logger.severe('Khong the copy vao clipboard', e, stacktrace);
              SnackBarUtils.error('messages.copy_to_clipboard_error'.tr());
            }
          },
          tooltip: 'menu.copy_to_clipboard'.tr(),
          icon: const Icon(Icons.copy, size: 30),
          padding: const EdgeInsets.all(16),
        ),
        IconButton(
          onPressed: () async {
            final currentWord = widget.word;
            if (currentWord == null) {
              SnackBarUtils.error('views.word.msg_share_please_choose_a_word'.tr());
              return;
            }

            final content = currentWord.shareContent;
            if (StringUtils.isNotEmpty(content)) {
              final result = await Share.share(
                content!,
                subject: 'views.word.share_subject'.tr(namedArgs: {'word': currentWord.displayText}),
              );

              
              
              
              
              
              
            }
          },
          tooltip: 'menu.share'.tr(),
          icon: const Icon(Icons.share, size: 30),
          padding: const EdgeInsets.all(16),
        ),
        IconButton(
          onPressed: () async {
            final currentWord = widget.word;
            if (currentWord == null) {
              SnackBarUtils.error('views.word.msg_save_please_choose_a_word'.tr());
              return;
            }

            final isSaved = await dict.isItemSaved(currentWord.id);
            if (!isSaved) {
              
              await dict.addToFavourite(currentWord);
              SnackBarUtils.success('views.word.msg_save_successful'.tr());
            } else {
              await dict.removeFromFavourite(currentWord);
              SnackBarUtils.success('views.word.msg_delete_successful'.tr());
            }
          },
          tooltip: 'menu.favourite'.tr(),
          icon: Icon(
            saved ? Icons.bookmark : Icons.bookmark_outline,
            color: saved ? KlsColors.primary : null,
            size: 30,
          ),
          padding: const EdgeInsets.all(16),
        ),
      ],
    );
  }

  Future<bool> zoom(InAppWebViewController? webController, int? size) async {
    try {
      if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
        await webController?.setSettings(settings: InAppWebViewSettings(textZoom: size));
      } else {
        
        await webController?.evaluateJavascript(source: 'document.body.style.fontSize = "${size}px";');

        
        await webController?.removeUserScript(userScript: textSizeUserScript);
        textSizeUserScript.source = kTextSizeSourceJS.replaceAll(kTextSizePlaceholder, '$size');
        await webController?.addUserScript(userScript: textSizeUserScript);
      }
      
      return true;
    } on Exception catch (e, stacktrace) {
      logger.warning('Khong the zoom', e, stacktrace);
    }

    return false;
  }
}
