import 'package:flutter/material.dart';
import 'package:logging/logging.dart';

import '../../../app/base/app_themes.dart';
import '../../../app/utils/string_utils.dart';

class SearchWidgetDesktop extends StatelessWidget {
  static final logger = Logger((SearchWidgetDesktop).toString());

  const SearchWidgetDesktop({
    super.key,
    required this.controller,
    this.hintText,
    this.fillColor = Colors.white54,
    this.onClearText,
    this.onTextChanged,
  });

  final TextEditingController controller;
  final String? hintText;
  final Color? fillColor;
  final Function()? onClearText;
  final Function(String)? onTextChanged;

  @override
  Widget build(BuildContext context) {
    final suffixIcon = StringUtils.isNotEmpty(controller.text)
        ? GestureDetector(
            child: const Padding(
              padding: EdgeInsets.all(16),
              child: Icon(Icons.clear),
            ),
            onTap: () {
              if (StringUtils.isNotEmpty(controller.text)) {
                if (onClearText != null) {
                  onClearText!();
                }
              } else {
                
                logger.fine('fine, do nothing');
              }
            },
          )
        : const Padding(
            padding: EdgeInsets.all(16),
            child: Icon(Icons.search, color: KlsColors.primary, size: 30),
          );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16),
      child: TextField(
        controller: controller,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 18),
        decoration: InputDecoration(
          filled: true,
          fillColor: fillColor,
          focusColor: KlsColors.primary,
          focusedBorder: _border(KlsColors.primary),
          border: _border(Colors.grey),
          enabledBorder: _border(Colors.grey),
          hintText: hintText,
          hintStyle: const TextStyle(color: Colors.grey, fontWeight: FontWeight.normal, fontSize: 18),
          
          contentPadding: const EdgeInsets.symmetric(horizontal: 32, vertical: 0),
          suffixIcon: suffixIcon,
        ),
        
        onChanged: onTextChanged,
      ),
    );
  }

  OutlineInputBorder _border(Color color) => OutlineInputBorder(
        borderSide: BorderSide(width: 0.5, color: color),
        borderRadius: BorderRadius.circular(100),
      );
}
