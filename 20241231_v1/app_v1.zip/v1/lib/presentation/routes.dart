import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/app/utils/device_utils.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:vgisc_glossary/presentation/index.dart';
import 'package:vgisc_glossary/presentation/views/home_screen_desktop.dart';
import 'package:vgisc_glossary/presentation/views/search_screen_desktop.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:logging/logging.dart';
import 'package:provider/provider.dart';

class Routes {
  Routes._();

  static const initial = '/initial';
  static const home = '/home';
  static const search = '/home/search';
  static const viewWordFromHome = '/home/viewWord';
  static const viewWordFromSearch = '/home/search/viewWord';

  static const favourite = '/favourite';
  static const share = '/share';
  static const settings = '/settings';
}


GoRoute _viewWordRoute(String name) => GoRoute(
      name: name,
      path: "viewWord",
      builder: (context, state) {
        final dict = Provider.of<DictionaryNotifier>(context, listen: false);
        final newWord = state.extra as WordView;

        dict.changeCurrentDisplayWord(newWord);

        return const WordScreen();
      },
    );


final GoRouter mobileRoutes = GoRouter(
  observers: <NavigatorObserver>[MyNavObserver(debugLogDiagnostics: false)],
  initialLocation: Routes.initial,
  routes: <RouteBase>[
    GoRoute(
      name: Routes.initial,
      path: Routes.initial,
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      name: Routes.home,
      path: Routes.home,
      builder: (context, state) => const HomeScreen(),

      
      
      routes: [
        GoRoute(
          name: Routes.search,
          path: "search",
          builder: (_, state) => const SearchScreen(),
          routes: [
            _viewWordRoute(Routes.viewWordFromSearch),
          ],
        ),
        _viewWordRoute(Routes.viewWordFromHome),
      ],
    ),
  ],
  
  redirect: (context, state) {
    
    
    
    final appState = Provider.of<AppNotifier>(context, listen: false);
    final bool isInitialized = appState.initialized;

    debugPrint('router state: '
        'init: $isInitialized'
        ', uri: ${state.uri}'
        ', path: ${state.path}'
        ', name: ${state.name}'
        ', matchedLocation: ${state.matchedLocation}');

    if (!isInitialized) {
      if (state.matchedLocation != Routes.initial) {
        return Routes.initial;
      }

      debugPrint('Waiting for initializing. No need to redirect, keep this place.');
      return null;
    } else if (state.matchedLocation == Routes.initial) {
      debugPrint('Redirect to home screen');
      return Routes.home;
    }
    debugPrint('No need to redirect, keep this place.');
    return null;
  },
  debugLogDiagnostics: true,
);

final GoRouter desktopRoutes = GoRouter(
  routes: [
    GoRoute(
      name: Routes.initial,
      path: Routes.initial,
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      name: Routes.home,
      path: Routes.home,
      builder: (context, state) => const HomeScreenDesktop(),

      
      
      routes: [
        GoRoute(
          name: Routes.search,
          path: "search",
          builder: (_, state) => const SearchScreenDesktop(),
          routes: [
            _viewWordRoute(Routes.viewWordFromSearch),
          ],
        ),
        _viewWordRoute(Routes.viewWordFromHome),
      ],
    ),
  ],
  observers: <NavigatorObserver>[MyNavObserver(debugLogDiagnostics: false)],
  initialLocation: Routes.initial,
  redirect: (context, state) {
    
    
    
    final appState = Provider.of<AppNotifier>(context, listen: false);
    final bool isInitialized = appState.initialized;

    debugPrint('router state: '
        'init: $isInitialized'
        ', uri: ${state.uri}'
        ', path: ${state.path}'
        ', name: ${state.name}'
        ', matchedLocation: ${state.matchedLocation}');

    if (!isInitialized) {
      if (state.matchedLocation != Routes.initial) {
        return Routes.initial;
      }

      debugPrint('Waiting for initializing. No need to redirect, keep this place.');
      return null;
    } else if (state.matchedLocation == Routes.initial) {
      debugPrint('Redirect to home screen');
      return Routes.home;
    }
    debugPrint('No need to redirect, keep this place.');
    return null;
  },
  debugLogDiagnostics: true,
);


final appRoutes = DeviceUtils.isDesktop ? desktopRoutes : mobileRoutes;



class MyNavObserver extends NavigatorObserver {
  final bool debugLogDiagnostics;

  
  MyNavObserver({this.debugLogDiagnostics = false}) {
    if (debugLogDiagnostics) {
      log.onRecord.listen((LogRecord e) => debugPrint('$e'));
    } else {
      log.onRecord.listen(null);
    }
  }

  
  final Logger log = Logger('MyNavObserver');

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (debugLogDiagnostics) {
      log.fine('didPush: ${route.str}, previousRoute= ${previousRoute?.str}');
    }
    SnackBarUtils.clear();
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (debugLogDiagnostics) {
      log.fine('didPop: ${route.str}, previousRoute= ${previousRoute?.str}');
    }
    SnackBarUtils.clear();
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (debugLogDiagnostics) {
      log.fine('didRemove: ${route.str}, previousRoute= ${previousRoute?.str}');
    }
    SnackBarUtils.clear();
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    if (debugLogDiagnostics) {
      log.fine('didReplace: new= ${newRoute?.str}, old= ${oldRoute?.str}');
    }
    SnackBarUtils.clear();
  }











}

extension on Route<dynamic> {
  String get str => 'route(${settings.name}: ${settings.arguments})';
}
