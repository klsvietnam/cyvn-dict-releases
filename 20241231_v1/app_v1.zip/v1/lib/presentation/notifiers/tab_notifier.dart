import 'package:flutter/cupertino.dart';
import 'package:logging/logging.dart';

class TabNotifier extends ChangeNotifier {
  static final Logger logger = Logger((TabNotifier).toString());

  int _tabIndex = 0;

  int get currentTabIndex => _tabIndex;

  set currentTabIndex(int value) {
    if (_tabIndex != value) {
      _tabIndex = value;
      notifyListeners();
    }
  }
}
