import 'dart:math';

import 'package:vgisc_glossary/data/index.dart';
import 'package:vgisc_glossary/data/repositories/dictionary_repository_interface.dart';
import 'package:vgisc_glossary/data/repositories/exception_mapper.dart';
import 'package:vgisc_glossary/di.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:vgisc_glossary/presentation/notifiers/kls_notifier_mixin.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:logging/logging.dart';

import 'dictionary_notifier_interface.dart';


class DictionaryNotifier extends ChangeNotifier
    with KlsNotifierMixin<DictionaryState>
    implements DictionaryNotifierInterface {
  @override
  final Logger logger = Logger((DictionaryNotifier).toString());

  late final DictionaryRepositoryInterface _db;

  
  DictionaryNotifier() : _db = DI.get<DictionaryRepositoryInterface>();

  bool get isLoading => state == DictionaryState.loading;

  bool get hasError => state == DictionaryState.error;

  
  
  
  List<WordView> _searchItems = []; 
  List<WordView> get searchItems => _searchItems;

  
  final TextEditingController _controller = TextEditingController();

  TextEditingController get controller => _controller;

  
  @override
  Future<List<WordView>> search(String query) async {
    if (query.isEmpty) return [];

    updateState(newState: DictionaryState.fetching);

    try {
      final stopwatch = Stopwatch()..start();
      _searchItems = await _db.findBy(query);
      logger.fine('Query: [$query], result in ${stopwatch.elapsed}: $_searchItems');
      stopwatch.stop();

      updateState(newState: DictionaryState.success);
    } catch (e, stacktrace) {
      logger.severe('Error in search', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }

    return _searchItems;
  }

  
  @override
  Future<WordView?> findByWord(String word) async {
    final searchResults = await _db.findByWord(word);

    logger.fine('findByWord results: $searchResults');

    return searchResults;
  }

  @override
  void clearSearch() {
    controller.text = '';
    notifyListeners();
  }

  
  
  

  List<WordView> _recentViewItems = [];

  List<WordView> get recentViewItems => _recentViewItems;

  @override
  Future<List<WordView>> getRecentViewItems() async {
    updateState(newState: DictionaryState.fetching); 
    try {
      _recentViewItems = await _db.findLastViewedWords(size: 100);
      updateState(newState: DictionaryState.success);
    } catch (e, stacktrace) {
      logger.severe('getRecentViewItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }

    notifyListeners();
    return _recentViewItems;
  }

  @override
  Future<void> addToRecentViewItems(WordView word) async {
    updateState(newState: DictionaryState.fetching);

    try {
      
      await _db.createOrUpdateAttendedWord(
        wordId: word.id,
        isViewed: true,
        viewAt: DateTime.now(),
        lastUpdateTime: DateTime.now(),
      );
      
      final latestWordItem = await _db.findById(word.id);
      __updateChanges(latestWordItem);
      logger.fine('Thêm mới/update thông tin favourite $latestWordItem');

      
      final currentItem = _recentViewItems.where((item) => item.id == word.id).firstOrNull;
      if (currentItem != null) {
        
        final currentIndex = _recentViewItems.indexOf(currentItem);
        _recentViewItems.removeAt(currentIndex);
        _recentViewItems.insert(0, latestWordItem!);
      } else {
        
        _recentViewItems.insert(0, latestWordItem!);
      }

      updateState(newState: DictionaryState.success);
    } catch (e, stacktrace) {
      logger.severe('addToRecentViewItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  @override
  Future<void> deleteRecentViewItems(WordView word) async {
    updateState(newState: DictionaryState.fetching);

    if (word.attendedId == null) {
      updateState(
        newState: DictionaryState.error,
        
        errorMessage: 'views.home.error_attended_word_invalid'.tr(namedArgs: {'word': word.displayText}),
      );
      return;
    }

    try {
      
      await _db.createOrUpdateAttendedWord(
        wordId: word.id,
        isViewed: false,
        viewAt: null,
        lastUpdateTime: DateTime.now(),
      );

      
      final latestWordItem = await _db.findById(word.id);
      __updateChanges(latestWordItem);
      _current = latestWordItem;

      final deletedIndex = _recentViewItems.indexWhere((i) => i.id == word.id);
      if (deletedIndex > -1) {
        _recentViewItems.removeAt(deletedIndex);
      }

      updateState(newState: DictionaryState.success);
    } catch (e, stacktrace) {
      logger.severe('deleteRecentViewItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  
  
  

  List<WordView> _savedItems = [];

  List<WordView> get savedItems => _savedItems;

  
  @override
  Future<bool> isItemSaved(int wordId) async {
    final item = await _db.findById(wordId);

    return item?.isSaved ?? false;
  }

  @override
  Future<List<WordView>> getSavedItems() async {
    updateState(newState: DictionaryState.fetching); 
    try {
      _savedItems = await _db.findSavedWords(size: 100);
      updateState(newState: DictionaryState.success);
    } catch (e, stacktrace) {
      logger.severe('getSavedItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }

    notifyListeners();
    return _savedItems;
  }

  @override
  Future<void> addToFavourite(WordView word) async {
    updateState(newState: DictionaryState.fetching);

    try {
      await _db.createOrUpdateAttendedWord(
        wordId: word.id,
        isSaved: true,
        savedAt: DateTime.now(),
        lastUpdateTime: DateTime.now(),
      );
      
      final latestWordItem = await _db.findById(word.id);
      __updateChanges(latestWordItem);

      _savedItems.add(latestWordItem!);

      updateState(newState: DictionaryState.success);
      logger.fine('Thêm mới/update thông tin favourite $latestWordItem');
    } catch (e, stacktrace) {
      logger.severe('addToFavourite error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  @override
  Future<void> removeFromFavourite(WordView word) async {
    final attendedWordInDb = await _db.findAttendedWordByWordId(word.id);
    if (attendedWordInDb == null) {
      updateState(
        newState: DictionaryState.error,
        
        errorMessage: 'views.home.error_attended_word_invalid'.tr(namedArgs: {'word': word.displayText}),
      );
      return;
    }

    try {
      
      await _db.createOrUpdateAttendedWord(
        wordId: word.id,
        isSaved: false,
        savedAt: DateTime.now(),
        lastUpdateTime: DateTime.now(),
      );

      
      final latestWordItem = await _db.findById(word.id);
      __updateChanges(latestWordItem);
      final deletedIndex = _savedItems.indexWhere((i) => i.id == word.id);
      if (deletedIndex > -1) {
        _savedItems.removeAt(deletedIndex);
        logger.fine('Da xoa favourite item $deletedIndex');
      } else {
        logger.fine('Khong tim thay index de xoa favourite item');
      }

      _current = latestWordItem;

      updateState(newState: DictionaryState.success);
      logger.fine('Xóa thông tin favourite $latestWordItem');
    } catch (e, stacktrace) {
      logger.severe('removeFromFavourite error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  
  
  
  WordView? _current;

  WordView? get current => _current;

  @override
  void changeCurrentDisplayWord(WordView newWord) {
    _current = newWord;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      notifyListeners();
    });
    logger.fine('current displaying item changed $newWord');
  }

  void __updateChanges(WordView? updatedWordItem) {
    if (updatedWordItem == null) {
      return;
    }

    var item = _searchItems.where((i) => i.id == updatedWordItem.id).firstOrNull;
    if (item != null) {
      item = __updateWordView(item, updatedWordItem);
    }

    item = recentViewItems.where((i) => i.id == updatedWordItem.id).firstOrNull;
    if (item != null) {
      item = __updateWordView(item, updatedWordItem);
    }

    item = savedItems.where((i) => i.id == updatedWordItem.id).firstOrNull;
    if (item != null) {
      item = __updateWordView(item, updatedWordItem);
    }

    if (_current != null) {
      _current = __updateWordView(_current!, updatedWordItem);
    } else {
      _current = updatedWordItem;
    }
  }

  WordView __updateWordView(WordView oldItem, WordView newItem) {
    return oldItem.copyWith(
      english: newItem.english,
      vietnamese: newItem.vietnamese,
      abbreviation: newItem.abbreviation,
      explanation: newItem.explanation,
      synonym: newItem.synonym,
      deleted: newItem.deleted,
      attendedId: newItem.attendedId,
      isViewed: newItem.isViewed,
      viewAt: newItem.viewAt,
      isSaved: newItem.isSaved,
      savedAt: newItem.savedAt,
    );
  }
}
