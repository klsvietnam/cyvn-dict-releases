import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:logging/logging.dart';
import 'package:vgisc_glossary/app/index.dart';
import 'package:vgisc_glossary/app/utils/date_utils.dart';
import 'package:vgisc_glossary/data/repositories/dictionary_repository_interface.dart';
import 'package:vgisc_glossary/di.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:vgisc_glossary/presentation/notifiers/kls_notifier_mixin.dart';

import 'dictionary_notifier_interface.dart';


class DesktopDictionaryNotifier extends ChangeNotifier
    with KlsNotifierMixin<DictionaryState>
    implements DictionaryNotifierInterface {
  @override
  final Logger logger = Logger((DesktopDictionaryNotifier).toString());

  late final DictionaryRepositoryInterface? _db;
  DictionaryRepositoryInterface get db {
    _db ??= DI.get<DictionaryRepositoryInterface>();

    return _db!;
  }

  
  DesktopDictionaryNotifier() : _db = DI.get<DictionaryRepositoryInterface>();

  bool get isLoading => state == DictionaryState.loading;

  bool get hasError => state == DictionaryState.error;

  
  final TextEditingController _controller = TextEditingController();

  TextEditingController get controller => _controller;

  
  InAppWebViewController? webController;

  
  final List<WordView> _dictionary = [];

  List<WordView> get dictionary => _dictionary;

  
  List<WordView> get displayingItems => StringUtils.isEmpty(controller.text) ? _dictionary : _searchItems;

  Future<List<WordView>> load({bool force = false}) async {
    if (!force && _dictionary.isNotEmpty) {
      return _dictionary;
    }

    updateState(newState: DictionaryState.fetching);

    try {
      final dic = await db.findAllWords();

      _dictionary.addAll(dic);
      

      updateState(newState: DictionaryState.success);
      logger.fine('Load all dictionary into memory, size: ${_dictionary.length} words');
      return dic;
    } catch (e, stacktrace) {
      logger.severe('Error in load', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
      return [];
    }
  }

  
  
  
  List<WordView> _searchItems = []; 
  List<WordView> get searchItems => _searchItems;

  
  @override
  Future<List<WordView>> search(String query) async {
    if (query.isEmpty) return [];

    updateState(newState: DictionaryState.fetching);

    try {
      final stopwatch = Stopwatch()..start();

      _searchItems = _dictionary.where((w) => w.isMatch(query)).toList();
      logger.fine('Query: [$query], result in ${stopwatch.elapsed}: ${searchItems.length}');
      stopwatch.stop();

      updateState(newState: DictionaryState.success);
      return _searchItems;
    } catch (e, stacktrace) {
      logger.severe('Error in search', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
      return [];
    }
  }

  
  @override
  Future<WordView?> findByWord(String word) async {
    final searchResults = _dictionary.where((w) => w.english == word || w.vietnamese == word).firstOrNull;

    logger.fine('findByWord results: $searchResults');

    return searchResults;
  }

  @override
  void clearSearch() {
    _controller.text = '';
    notifyListeners();
  }

  
  
  

  List<WordView> get recentViewItems {
    final recentViewItems = _dictionary.where((w) => w.isViewed ?? false).toList();
    recentViewItems.sort((w1, w2) => DateUtils.compare(w1.viewAt, w2.viewAt));
    return recentViewItems;
  }

  @override
  Future<List<WordView>> getRecentViewItems() async {
    updateState(newState: DictionaryState.fetching); 
    try {
      final items = _dictionary.where((w) => w.isViewed ?? false).toList();
      items.sort((w1, w2) => DateUtils.compare(w1.viewAt, w2.viewAt));
      updateState(newState: DictionaryState.success);
      return items;
    } catch (e, stacktrace) {
      logger.severe('getRecentViewItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
      return [];
    }
  }

  @override
  Future<void> addToRecentViewItems(WordView word) async {
    updateState(newState: DictionaryState.fetching);

    try {
      
      await db.createOrUpdateAttendedWord(
        wordId: word.id,
        isViewed: true,
        viewAt: DateTime.now(),
        lastUpdateTime: DateTime.now(),
      );

      
      final latestWordItem = await db.findById(word.id);
      __updateChanges(latestWordItem);
      logger.fine('Thêm mới/update thông tin favourite $latestWordItem');

      updateState(newState: DictionaryState.success);
    } catch (e, stacktrace) {
      logger.severe('addToRecentViewItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  @override
  Future<void> deleteRecentViewItems(WordView word) async {
    updateState(newState: DictionaryState.fetching);

    if (word.attendedId == null) {
      updateState(
        newState: DictionaryState.error,
        
        errorMessage: 'views.home.error_attended_word_invalid'.tr(namedArgs: {'word': word.displayText}),
      );
      return;
    }

    try {
      
      await db.createOrUpdateAttendedWord(
        wordId: word.id,
        isViewed: false,
        viewAt: null,
        lastUpdateTime: DateTime.now(),
      );

      
      final latestWordItem = await db.findById(word.id);
      __updateChanges(latestWordItem);
      _current = latestWordItem;

      updateState(newState: DictionaryState.success);
    } catch (e, stacktrace) {
      logger.severe('deleteRecentViewItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  
  
  
  
  
  
  
  
  
  
  

  List<WordView> get savedItems {
    final savedItems = _dictionary.where((w) => w.isSaved ?? false).toList();
    

    return savedItems;
  }

  
  @override
  Future<bool> isItemSaved(int wordId) async {
    final item = _dictionary.where((w) => w.id == wordId).firstOrNull;

    return item?.isSaved ?? false;
  }

  @override
  Future<List<WordView>> getSavedItems() async {
    updateState(newState: DictionaryState.fetching); 
    try {
      final savedItems = _dictionary.where((w) => w.isSaved ?? false).toList();
      savedItems.sort((w1, w2) => DateUtils.compare(w1.savedAt, w2.savedAt));
      updateState(newState: DictionaryState.success);

      return savedItems;
    } catch (e, stacktrace) {
      logger.severe('getSavedItems error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());

      return [];
    }
  }

  @override
  Future<void> addToFavourite(WordView word) async {
    updateState(newState: DictionaryState.fetching);

    try {
      
      await db.createOrUpdateAttendedWord(
        wordId: word.id,
        isSaved: true,
        savedAt: DateTime.now(),
        lastUpdateTime: DateTime.now(),
      );

      
      final latestWordItem = await db.findById(word.id);
      __updateChanges(latestWordItem);

      updateState(newState: DictionaryState.success);
      logger.fine('Thêm mới/update thông tin favourite $latestWordItem');
    } catch (e, stacktrace) {
      logger.severe('addToFavourite error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  @override
  Future<void> removeFromFavourite(WordView word) async {
    final attendedWordInDb = await db.findAttendedWordByWordId(word.id);
    if (attendedWordInDb == null) {
      updateState(
        newState: DictionaryState.error,
        
        errorMessage: 'views.home.error_attended_word_invalid'.tr(namedArgs: {'word': word.displayText}),
      );
      return;
    }

    try {
      
      await db.createOrUpdateAttendedWord(
        wordId: word.id,
        isSaved: false,
        savedAt: DateTime.now(),
        lastUpdateTime: DateTime.now(),
      );

      
      final latestWordItem = await db.findById(word.id);
      __updateChanges(latestWordItem);
      _current = latestWordItem;

      updateState(newState: DictionaryState.success);
      logger.fine('Xóa thông tin favourite $latestWordItem');
    } catch (e, stacktrace) {
      logger.severe('removeFromFavourite error', e, stacktrace);
      updateState(newState: DictionaryState.error, errorMessage: e.toString());
    }
  }

  
  
  
  WordView? _current;

  WordView? get current => _current;

  @override
  void changeCurrentDisplayWord(WordView newWord) {
    _current = newWord;
    if (webController != null) {
      webController?.loadData(data: newWord.html);
    } else {
      logger.fine('Ignore load html content, because webController is null');
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      notifyListeners();
    });
    logger.fine('current displaying item changed $newWord');
  }

  void __updateChanges(WordView? updatedWordItem) {
    if (updatedWordItem == null) {
      return;
    }

    var item = _dictionary.where((i) => i.id == updatedWordItem.id).firstOrNull;
    if (item != null) {
      item = __updateWordView(item, updatedWordItem);
    }

    if (_current != null) {
      _current = __updateWordView(_current!, updatedWordItem);
    } else {
      _current = updatedWordItem;
    }
  }

  WordView __updateWordView(WordView oldItem, WordView newItem) {
    return oldItem.copyWith(
      english: newItem.english,
      vietnamese: newItem.vietnamese,
      abbreviation: newItem.abbreviation,
      explanation: newItem.explanation,
      synonym: newItem.synonym,
      deleted: newItem.deleted,
      attendedId: newItem.attendedId,
      isViewed: newItem.isViewed,
      viewAt: newItem.viewAt,
      isSaved: newItem.isSaved,
      savedAt: newItem.savedAt,
    );
  }
}
