import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:flutter/cupertino.dart';

enum DictionaryState {
  idle, // Initial state
  adding,
  fetching, // Fetching
  loading, // Loading state (optional)
  success, // Success state
  error, // Error state
  updating, // Updating
  deleting, // Deleting
}

abstract class DictionaryNotifierInterface extends ChangeNotifier {
  /// Tìm kiếm theo từ khóa người dùng nhập vào
  Future<List<WordView>> search(String query);

  /// Tim theo toàn bộ từ
  Future<WordView?> findByWord(String word);

  void clearSearch();

  /// ==========================================
  /// RECENT VIEWS
  /// ==========================================
  Future<List<WordView>> getRecentViewItems();

  Future<void> addToRecentViewItems(WordView word);

  Future<void> deleteRecentViewItems(WordView word);

  /// ==========================================
  /// FAVOURITE / SAVED
  /// ==========================================

  /// Check whether saved or not
  Future<bool> isItemSaved(int wordId);

  Future<List<WordView>> getSavedItems();

  Future<void> addToFavourite(WordView word);

  Future<void> removeFromFavourite(WordView word);

  /// ==========================================
  /// CURRENT DISPLAYING WORD
  /// ==========================================

  void changeCurrentDisplayWord(WordView newWord);
}
