import 'package:vgisc_glossary/data/datasources/local/shared_pref/pref_helper.dart';
import 'package:vgisc_glossary/di.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:flutter/foundation.dart';
import 'package:logging/logging.dart';

class AppNotifier extends ChangeNotifier {
  static final Logger logger = Logger((AppNotifier).toString());

  
  
  
  UserSetting _userSettings = UserSetting.defaults();

  UserSetting get userSettings => _userSettings;

  
  Future<void> applySettings({AppLanguage? language}) async {
    _userSettings = _userSettings.copyWith(
      selectedLang: language,
    );

    final sharedPref = DI.get<PrefHelper>();
    await sharedPref.saveUserSettings(_userSettings);

    notifyListeners();
  }

  bool _initialized = false;
  bool get initialized => _initialized;

  set initialized(bool value) {
    if (_initialized != value) {
      _initialized = value;

      notifyListeners();
    }
  }
}
