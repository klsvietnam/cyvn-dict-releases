import 'package:flutter/material.dart';
import 'package:universal_platform/universal_platform.dart';
import 'package:vgisc_glossary/app/base/app_constants.dart';

enum MessageType {
  info,
  warning,
  success,
  error,
}

class MessageStyle {
  final Icon icon;
  final Color? backgroundColor;
  final Color? textColor;

  /// thời gian hiển thị snackbar (tính theo giây). Mặc định của snackbar là 4 giây
  final int? durationInSec;

  MessageStyle({required this.icon, this.backgroundColor, this.textColor, this.durationInSec = 4});
}

Map<MessageType, MessageStyle> _snackBarStyles = {
  MessageType.info: MessageStyle(
    icon: const Icon(Icons.info, color: Colors.white),
    backgroundColor: Colors.white,
  ),
  MessageType.warning: MessageStyle(
    icon: const Icon(Icons.warning, color: Colors.white),
    backgroundColor: Colors.orangeAccent,
    durationInSec: 6,
  ),
  MessageType.success: MessageStyle(
    icon: const Icon(Icons.check, color: Colors.white),
    backgroundColor: Colors.green,
  ),
  MessageType.error: MessageStyle(
    icon: const Icon(Icons.error, color: Colors.white),
    backgroundColor: Colors.redAccent,
    durationInSec: 10,
  ),
};

class SnackBarUtils {
  SnackBarUtils._();

  static void success(String message) {
    return showSnackBar(message, messageType: MessageType.success);
  }

  static void error(String message) {
    return showSnackBar(message, messageType: MessageType.error);
  }

  static void showSnackBar(String message, {MessageType messageType = MessageType.info}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final style = _snackBarStyles[messageType];
      final snackBar = SnackBar(
        backgroundColor: style?.backgroundColor ?? Colors.white,
        content: Row(
          children: <Widget>[
            style?.icon ?? const Icon(Icons.info),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                message,
                style: style?.textColor != null
                    ? TextStyle(
                        color: style?.textColor,
                        fontSize: UniversalPlatform.isDesktopOrWeb ? 20 : null,
                      )
                    : TextStyle(fontSize: UniversalPlatform.isDesktopOrWeb ? 20 : null),
              ),
            )
          ],
        ),
        duration: Duration(seconds: style?.durationInSec ?? 4),
        showCloseIcon: true,
      );

      globalScaffoldMessengerKey.currentState
        ?..clearSnackBars()
        ..showSnackBar(snackBar);
    });
  }

  static void clear() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      globalScaffoldMessengerKey.currentState?.removeCurrentSnackBar();
    });
  }
}
