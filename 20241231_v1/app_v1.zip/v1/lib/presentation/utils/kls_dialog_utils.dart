import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

/// refer: https://github.com/gtgalone/confirm_dialog/blob/main/lib/confirm_dialog.dart
/// The `title` argument is used to title of alert dialog.
/// The `content` argument is used to content of alert dialog.
/// The `textOK` argument is used to text for 'OK' Button of alert dialog.
/// The `textCancel` argument is used to text for 'Cancel' Button of alert dialog.
/// The `canPop` argument is `canPop` of PopScope.
/// The `onPopInvoked` argument is `onPopInvoked` of PopScope.
///
/// Returns a [Future<bool>].
Future<bool> showAlertDialog(
  BuildContext context, {
  Widget? title,
  Widget? content,
  Widget? textOK,
  Widget? textCancel,
  bool canPop = false,
  void Function(bool, dynamic)? onPopInvoked,
}) async {
  final bool? isConfirm = await showDialog<bool>(
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) => PopScope(
      canPop: canPop,
      onPopInvokedWithResult: onPopInvoked,
      child: AlertDialog(
        title: title ??
            Text(
              "views.dialog.confirm".tr(),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 16),
            ),
        content: SingleChildScrollView(
          child: content ??
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text('views.dialog.are_you_sure'.tr()),
              ),
        ),
        actions: <Widget>[
          TextButton(
            child: textCancel ?? Text(MaterialLocalizations.of(context).cancelButtonLabel),
            onPressed: () => Navigator.pop(context, false),
          ),
          TextButton(
            child: textOK ?? Text(MaterialLocalizations.of(context).okButtonLabel),
            onPressed: () => Navigator.pop(context, true),
          ),
        ],
      ),
    ),
  );
  return isConfirm ?? false;
}
