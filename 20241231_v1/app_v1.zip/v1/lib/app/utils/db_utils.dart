import 'dart:io';

import 'package:universal_platform/universal_platform.dart';

import 'package:vgisc_glossary/app/base/app_constants.dart';
import 'package:vgisc_glossary/data/datasources/local/db/db_migrator.dart';
import 'package:floor/floor.dart';
import 'package:flutter/services.dart';
import 'package:logging/logging.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class DbUtils {
  static final logger = Logger((DbUtils).toString());

  static Future<String> getDbPath({String dbName = AppConstants.dbName}) async {
    final dbPath = UniversalPlatform.isWindows
        ? (await getApplicationSupportDirectory()).path
        : await sqfliteDatabaseFactory.getDatabasesPath();

    final targetDbPath = join(dbPath, dbName);

    return targetDbPath;
  }

  
  
  static Future<void> copyDb({
    bool overwrite = false,
    String assetDbName = AppConstants.dbName,
    String targetDbName = AppConstants.dbName,
  }) async {
    try {
      final dbExists = await sqfliteDatabaseFactory.databaseExists(targetDbName);
      if (dbExists) {
        logger.fine('DB existed');
        if (overwrite) {
          logger.info('Replace existing DB');
          sqfliteDatabaseFactory.deleteDatabase(targetDbName);
        } else {
          return;
        }
      }

      final targetDbPath = await getDbPath(dbName: targetDbName);
      final dir = Directory(dirname(targetDbPath));
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }

      
      final dbData = await rootBundle.load(join('assets/db/', assetDbName));
      final bytes = dbData.buffer.asUint8List(dbData.offsetInBytes, dbData.lengthInBytes);

      await File(targetDbPath).writeAsBytes(bytes);
      logger.info('DB copied. $targetDbPath');
    } on Exception catch (e, stacktrace) {
      logger.severe('Không thể copy DB từ assets sang thư mục chứa DB của app', e, stacktrace);
      rethrow;
    }
  }

  static Future<void> migrateDb() async {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;

    final migrator = DbMigrator();
    logger.info('Migration START');
    final result = await migrator.migrate();
    logger.info('Migration FINISH, result: $result');
  }

  static Future<void> deleteTempDb(String tempDbName) async {
    if (tempDbName == AppConstants.dbName) {
      logger.warning("You're trying to delete main DB. It's can make app crash. This action is stopped.");
      return;
    }

    final tempDbPath = await getDbPath(dbName: tempDbName);
    if (await File(tempDbPath).exists()) {
      try {
        await File(tempDbPath).delete();
      } catch (e, stacktrace) {
        logger.warning('Khong the xoa file $tempDbPath', e, stacktrace);
      }
    }
  }
}
