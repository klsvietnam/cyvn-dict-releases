import 'package:intl/intl.dart';
import 'package:html/parser.dart';

final moneyFormat = NumberFormat();
final numberFormat = NumberFormat();

class StringUtils {
  StringUtils._();

  static bool isEmpty(String? txt) {
    if (txt == null) return true;

    return txt.isEmpty;
  }

  static bool isEmptyOrBlank(String? txt) {
    if (txt == null) return true;

    return txt.trim().isEmpty;
  }

  static bool isNotEmpty(String? txt) {
    if (txt == null) return false;

    return txt.isNotEmpty;
  }

  static bool isNotEmptyOrBlank(String? txt) {
    if (txt == null) return false;

    return txt.trim().isNotEmpty;
  }

  static String formatDate(DateTime dateTime, {String format = 'yyyy-MM-dd'}) {
    return DateFormat(format).format(dateTime);
  }

  static DateTime parseDate(String dateTimeString, {String format = 'yyyy-MM-dd'}) {
    return DateFormat(format).parse(dateTimeString);
  }

  static String convertDateFormat(String dateTime, {String fromFormat = 'yyyy-MM-dd', String toFormat = 'dd/MM/yyyy'}) {
    if (dateTime.isNotEmpty) {
      
      

      return formatDate(parseDate(dateTime, format: fromFormat), format: toFormat);
    }

    return dateTime;
  }

  String getFirstDay(DateTime dateTime) {
    return DateFormat("01/MM/yyyy").format(dateTime);
  }

  String formatDateTimeToParamString(DateTime dateTime) {
    return DateFormat("MM/dd/yyyy").format(dateTime);
  }

  DateTime getFirstDayOfMonth(DateTime dateTime) {
    return DateFormat("dd/MM/yyyy").parse(DateFormat("01/MM/yyyy").format(dateTime));
  }

  String formatMoney(dynamic money) {
    if (money is String) {
      return money;
    }

    return moneyFormat.format((money ?? 0).toInt().toDouble());
  }

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

  static String? stripHtmlTags(String? source) {
    if (isEmpty(source)) {
      return source;
    }

    final document = parse(source);
    return parse(document.body?.text).documentElement?.text;
  }

  
  
  
  static int compare(String? s1, String? s2) {
    if (s1 == null && s2 == null) {
      return 0;
    }

    if (s1 != null && s2 != null) {
      return s1.compareTo(s2);
    }

    if (s1 != null) {
      return -1;
    } else if (s2 != null) {
      return 1;
    }

    return 0;
  }
}
