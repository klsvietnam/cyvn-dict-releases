import 'package:universal_platform/universal_platform.dart';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/app/base/app_constants.dart';
import 'package:flutter/material.dart';

enum DeviceType {
  mobile,
  tablet,
  windows,
  linux,
  macos,
}

class DeviceUtils {
  DeviceUtils._();

  
  static Size get size => MediaQuery.of(globalScaffoldMessengerKey.currentContext!).size;
  static double get width => MediaQuery.of(globalScaffoldMessengerKey.currentContext!).size.width;
  static double get height => MediaQuery.of(globalScaffoldMessengerKey.currentContext!).size.height;

  static DeviceType getDeviceType(MediaQueryData mediaQueryData) {
    if (UniversalPlatform.isWindows) return DeviceType.windows;
    if (UniversalPlatform.isLinux) return DeviceType.linux;
    if (UniversalPlatform.isMacOS) return DeviceType.macos;

    final isTablet = min(mediaQueryData.size.width, mediaQueryData.size.height) > 600;
    if (isTablet) return DeviceType.tablet;

    return DeviceType.mobile;
  }

  static bool get isMobile => UniversalPlatform.isAndroid || UniversalPlatform.isIOS;
  static bool get isDesktop => kIsWeb || UniversalPlatform.isWindows || UniversalPlatform.isLinux || UniversalPlatform.isMacOS;

  static String? _deviceId;
  static bool _deviceIdDetected = false;

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}
