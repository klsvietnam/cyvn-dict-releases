import 'package:universal_platform/universal_platform.dart';

import 'package:flutter/foundation.dart';
import 'package:logging/logging.dart';

import 'file_log_handler.dart';

class LogInitialization {
  static final appLogger = Logger('AppLogger');

  
  static final Map<Level, String> levelColors = {
    
    
    Level.WARNING: '\u001b[35m', 
    Level.SEVERE: '\u001b[31m', 
    
    Level.FINE: '\u001b[90m', 
  };

  LogInitialization._();

  static Future<void> init() async {
    if (kDebugMode) {
      Logger.root.level = Level.ALL;
      Logger.root.onRecord.listen((record) {
        final formattedMessage = _formatLogMessage(record);
        final coloredMessage = _colorLogMessage(formattedMessage, record.level);
        debugPrint(coloredMessage);
      });
    } else {
      Logger.root.level = Level.INFO;

      
      if (UniversalPlatform.isWindows) {
        final fileHandler = FileLogHandler();
        await fileHandler.init();

        Logger.root.onRecord.listen((record) {
          fileHandler.writeLog(_formatLogMessage(record));
        });
      }
    }

    
    FlutterError.onError = (details) {
      FlutterError.presentError(details);

      appLogger.severe('Error occurs', details.exception, details.stack);
    };
    PlatformDispatcher.instance.onError = (error, stack) {
      appLogger.severe('Error occurs', error, stack);
      return true;
    };
  }

  
  static String _formatLogMessage(LogRecord record) {
    return '${record.time} ${record.level.name} ${record.loggerName} ${record.message}';
  }

  
  static String _colorLogMessage(String message, Level level) {
    

    const resetColor = '\x1B[0m';
    final color = levelColors[level] ?? ''; 
    return color != '' ? '$color$message$resetColor' : message;
  }
}
