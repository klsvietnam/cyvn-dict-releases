import 'dart:io';

import 'package:vgisc_glossary/app/base/app_settings.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

class FileLogHandler {
  late File _logFile;

  
  Future<void> init({String? path}) async {
    if (path != null) {
      _logFile = File(path);
      debugPrint('Log file path: $path');
    } else {
      final directory = await getApplicationSupportDirectory();
      const suffix = AppSettings.env == 'prod' ? '' : '.${AppSettings.env}';
      final logPath = '${directory.path}/logs/vgisc_glossary$suffix.log';
      _logFile = File(logPath);
      debugPrint('Log file path: $logPath');
    }

    
    if (!await _logFile.exists()) {
      await _logFile.create(recursive: true);
    }

    
  }

  
  void writeLog(String message) async {
    await _logFile.writeAsString('$message\n', mode: FileMode.append);
  }
}
