import 'package:envied/envied.dart';

part 'app_settings.g.dart';

@envied
abstract class AppSettings {
  
  @EnviedField(varName: 'ENV', defaultValue: 'dev')
  static const String env = _AppSettings.env;

  @EnviedField(varName: 'VERSION')
  static const String version = _AppSettings.version;

  @EnviedField(varName: 'API_URL', defaultValue: 'http://localhost:8000')
  static const String apiUrl = _AppSettings.apiUrl;

  @EnviedField(varName: 'API_ERROR_RETRY_COUNT', defaultValue: 1)
  static const int apiErrorRetryCount = _AppSettings.apiErrorRetryCount;

  @EnviedField(varName: 'REF_LINK_PREFIX', defaultValue: 'https://klsvietnam.com/kls-dict/')
  static const String refLinkPrefix = _AppSettings.refLinkPrefix;

  
  
  
  
  
  
  @EnviedField(varName: 'ASSET_DB_VERSION', defaultValue: '2024-01-01T00:00:00Z')
  static const String assetDbVersion = _AppSettings.assetDbVersion;

  @EnviedField(varName: 'SHARED_PREF_FILE', defaultValue: 'pref.dev')
  static const String prefBox = _AppSettings.prefBox;

  @EnviedField(varName: 'SENTRY_DSN', obfuscate: true, defaultValue: '')
  static final String sentryDsn = _AppSettings.sentryDsn;

  @EnviedField(varName: 'SENTRY_TRACE_SAMPLE_RATE', defaultValue: 0)
  static const double sentryTraceSampleRate = _AppSettings.sentryTraceSampleRate;

  @EnviedField(varName: 'SENTRY_PROFILE_SAMPLE_RATE', defaultValue: 0)
  static const double sentryProfileSampleRate = _AppSettings.sentryProfileSampleRate;

  @override
  String toString() {
    return 'AppSettings {'
        ' env: $env'
        ', version: $version'
        ', apiUrl: $apiUrl'
        ', apiErrorRetryCount: $apiErrorRetryCount'
        ', refLinkPrefix: $refLinkPrefix'
        ', assetDbVersion: $assetDbVersion'
        ' }';
  }
}
