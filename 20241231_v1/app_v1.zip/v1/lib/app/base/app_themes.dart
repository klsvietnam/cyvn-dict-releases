import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class KlsColors {
  KlsColors._();

  static const Color primaryWindows = Color(0xFF881A11);
  static const Color primary = Color(0xFF991B1B); 
  static final Color primary10 = primary.withOpacity(0.1);
  static final Color primary12 = primary.withOpacity(0.12);
  static final Color primary24 = primary.withOpacity(0.24);
  static final Color primary30 = primary.withOpacity(0.30);
  static final Color primary38 = primary.withOpacity(0.38);
  static final Color primary54 = primary.withOpacity(0.54);
  static final Color primary60 = primary.withOpacity(0.60);
  static final Color primary70 = primary.withOpacity(0.70);

  static const Color secondary = Color(0xFFF08C76);
  static const Color secondary2 = Color(0xFFa9a6dc);

  static const Color background = Color(0xBF881A11); 
  static const Color textColor = Color(0xFF3C4046);

  static const Color textFieldBackground = Color(0xFFF6F6F6);
}

final double kDefaultPadding = 16.0.sp;
final double kDefaultPadding2 = 16.0.sp / 2;

class KlsSizes {
  KlsSizes._();

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

  
  static final double displayLarge = 96.sp;

  
  static final double displayMedium = 60.sp;

  
  static final double displaySmall = 48.sp;

  
  static final double headlineLarge = 40.sp;

  
  static final double headlineMedium = 34.sp;

  
  static final double headlineSmall = 24.sp;

  
  static final double titleLarge = 22.sp;

  
  static final double titleMedium = 20.sp;

  
  static final double titleSmall = 18.sp;

  
  static final double bodyLarge = 28.sp;

  
  static final double bodyMedium = 16.sp;

  
  static final double bodySmall = 14.sp;

  
  static final double labelLarge = 16.sp;

  
  static final double labelMedium = 14.sp;

  
  static final double labelSmall = 12.sp;

  static final double textNormal = bodyMedium;
  static final double subtext = 12.sp;

  static final double textHeader = 18.sp;

  static Map<String, double?> getTestSizes(BuildContext context) {
    final defaultTextFontSize = DefaultTextStyle.of(context).style.fontSize;
    final textTheme = Theme.of(context).textTheme;

    final map = {
      'defaultTextFontSize': defaultTextFontSize,
      '12sp': 12.sp,
      '16sp': 16.sp,
      '20sp': 20.sp,
      '24sp': 24.sp,
      'textNormal': textNormal,
      'textHeader': textHeader,
      'labelSmall': textTheme.labelSmall?.fontSize,
      'labelMedium': textTheme.labelMedium?.fontSize,
      'labelLarge': textTheme.labelLarge?.fontSize,
      'bodySmall': textTheme.bodySmall?.fontSize,
      'bodyMedium': textTheme.bodyMedium?.fontSize,
      'bodyLarge': textTheme.bodyLarge?.fontSize,
      'titleSmall': textTheme.titleSmall?.fontSize,
      'titleMedium': textTheme.titleMedium?.fontSize,
      'titleLarge': textTheme.titleLarge?.fontSize,
      'headlineSmall': textTheme.headlineSmall?.fontSize,
      'headlineMedium': textTheme.headlineMedium?.fontSize,
      'displaySmall': textTheme.displaySmall?.fontSize,
      'displayMedium': textTheme.displayMedium?.fontSize,
      'displayLarge': textTheme.displayLarge?.fontSize,
    };
    debugPrint(map.toString());
    return map;
  }
}


const iosTransition = PageTransitionsTheme(builders: {
  TargetPlatform.android: CupertinoPageTransitionsBuilder(),
  TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
});

class AppThemes {
  static final light = ThemeData.light().copyWith(
    pageTransitionsTheme: iosTransition,
    colorScheme: ColorScheme.fromSeed(seedColor: KlsColors.primary),
    primaryColor: KlsColors.primary,
    
    
    scaffoldBackgroundColor: Colors.white,

    textTheme: ThemeData.light()
        .textTheme
        .apply(
          bodyColor: KlsColors.textColor,
        )
        .copyWith(
          displayLarge: ThemeData.light().textTheme.displayLarge?.copyWith(fontSize: KlsSizes.displayLarge),
          displayMedium: ThemeData.light().textTheme.displayMedium?.copyWith(fontSize: KlsSizes.displayMedium),
          displaySmall: ThemeData.light().textTheme.displaySmall?.copyWith(fontSize: KlsSizes.displaySmall),
          headlineLarge: ThemeData.light().textTheme.headlineLarge?.copyWith(fontSize: KlsSizes.headlineLarge),
          headlineMedium: ThemeData.light().textTheme.headlineMedium?.copyWith(fontSize: KlsSizes.headlineMedium),
          headlineSmall: ThemeData.light().textTheme.headlineSmall?.copyWith(fontSize: KlsSizes.headlineSmall),
          titleLarge: ThemeData.light().textTheme.titleLarge?.copyWith(fontSize: KlsSizes.titleLarge),
          titleMedium: ThemeData.light().textTheme.titleMedium?.copyWith(fontSize: KlsSizes.titleMedium),
          titleSmall: ThemeData.light().textTheme.titleSmall?.copyWith(fontSize: KlsSizes.titleSmall),
          bodyLarge: ThemeData.light().textTheme.bodyLarge?.copyWith(fontSize: KlsSizes.bodyLarge),
          bodyMedium: ThemeData.light().textTheme.bodyMedium?.copyWith(fontSize: KlsSizes.bodyMedium),
          bodySmall: ThemeData.light().textTheme.bodySmall?.copyWith(fontSize: KlsSizes.bodySmall),
          labelLarge: ThemeData.light().textTheme.labelLarge?.copyWith(fontSize: KlsSizes.labelLarge),
          labelMedium: ThemeData.light().textTheme.labelMedium?.copyWith(fontSize: KlsSizes.labelMedium),
          labelSmall: ThemeData.light().textTheme.labelSmall?.copyWith(fontSize: KlsSizes.labelSmall),
        ),
    appBarTheme: ThemeData.light().appBarTheme.copyWith(
          backgroundColor: Colors.white,
          titleTextStyle: ThemeData.light().appBarTheme.titleTextStyle?.copyWith(fontSize: KlsSizes.titleMedium) ??
              ThemeData.light().textTheme.titleLarge?.copyWith(fontSize: KlsSizes.titleMedium),
        ),
    floatingActionButtonTheme: ThemeData.light().floatingActionButtonTheme.copyWith(
          backgroundColor: Colors.white70,
          elevation: 12,
          shape: RoundedRectangleBorder(
            side: BorderSide(width: 2, color: KlsColors.primary70),
            borderRadius: BorderRadius.circular(100),
          ),
        ),
    inputDecorationTheme: ThemeData.light().inputDecorationTheme.copyWith(
          hintStyle: ThemeData.light()
              .inputDecorationTheme
              .hintStyle
              ?.copyWith(color: Colors.grey, fontWeight: FontWeight.normal, fontSize: KlsSizes.textNormal),
        ),
    bottomNavigationBarTheme: ThemeData.light().bottomNavigationBarTheme.copyWith(
          selectedLabelStyle:
              ThemeData.light().bottomNavigationBarTheme.selectedLabelStyle?.copyWith(fontWeight: FontWeight.w500) ??
                  const TextStyle(fontWeight: FontWeight.w500),
          elevation: 32,
        ),
    listTileTheme: ThemeData.light().listTileTheme.copyWith(
          titleTextStyle: ThemeData.light().listTileTheme.titleTextStyle?.copyWith(fontSize: KlsSizes.textNormal) ??
              ThemeData.light()
                  .textTheme
                  .titleSmall
                  ?.copyWith(fontSize: KlsSizes.textNormal, fontWeight: FontWeight.w500),
          subtitleTextStyle: ThemeData.light().listTileTheme.subtitleTextStyle?.copyWith(
                    fontSize: KlsSizes.textNormal,
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                    color: const Color(0xFF999999),
                  ) ??
              ThemeData.light().textTheme.titleSmall?.copyWith(
                    fontSize: KlsSizes.textNormal,
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                    color: const Color(0xFF999999),
                  ),
        ),
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  );
















}
