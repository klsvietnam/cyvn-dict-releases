// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_settings.dart';

// **************************************************************************
// EnviedGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
final class _AppSettings {
  static const String env = 'dev';

  static const String version = '0.0.1';

  static const String apiUrl = 'http://localhost:3000';

  static const int apiErrorRetryCount = 1;

  static const String refLinkPrefix = 'https://klsvietnam.com/kls-dict/';

  static const String assetDbVersion = '2024-01-01T00:00:00Z';

  static const String prefBox = 'pref.dev';

  static const List<int> _enviedkeysentryDsn = <int>[
    1820045972,
    417963833,
    4107360197,
    3077451432,
    152640785,
    2077225771,
    3105953598,
    1519797783,
    2446995983,
    1992915462,
    1147008120,
    2467014354,
    2222849470,
    455595619,
    2065920949,
    1708351606,
    1283211657,
    494037913,
    3040365448,
    2201584589,
    936044882,
    2040061196,
    3955007661,
    1959281607,
    1289250182,
    2853021870,
    738584825,
    568542645,
    3260932380,
    4046083803,
    2786514404,
    754883422,
    3228708097,
    2679703188,
    2024121151,
    3883376690,
    2361823847,
    1614526071,
    1722667495,
  ];

  static const List<int> _envieddatasentryDsn = <int>[
    1820046076,
    417963853,
    4107360177,
    3077451480,
    152640866,
    2077225745,
    3105953553,
    1519797816,
    2446996087,
    1992915582,
    1147008000,
    2467014290,
    2222849478,
    455595547,
    2065920973,
    1708351576,
    1283211744,
    494038007,
    3040365551,
    2201584552,
    936044833,
    2040061304,
    3955007619,
    1959281586,
    1289250293,
    2853021824,
    738584714,
    568542672,
    3260932466,
    4046083759,
    2786514326,
    754883367,
    3228708143,
    2679703293,
    2024121168,
    3883376669,
    2361823775,
    1614525967,
    1722667423,
  ];

  static final String sentryDsn = String.fromCharCodes(List<int>.generate(
    _envieddatasentryDsn.length,
    (int i) => i,
    growable: false,
  ).map((int i) => _envieddatasentryDsn[i] ^ _enviedkeysentryDsn[i]));

  static const double sentryTraceSampleRate = 0;

  static const double sentryProfileSampleRate = 0;
}
