import 'package:vgisc_glossary/data/data_dependencies.dart';
import 'package:vgisc_glossary/domain/domain_dependencies.dart';
import 'package:vgisc_glossary/presentation/presentation_dependencies.dart';
import 'package:logging/logging.dart';

class AppDI {
  static final log = Logger((AppDI).toString());

  static bool _init = false;

  static Future<void> init() async {
    if (_init) {
      return;
    }

    _init = true;
    log.fine('Initializing dependencies');

    await DataDependencies.init();

    await DomainDependencies.init();

    await PresentationDependencies.init();

    log.info('Initialized dependencies');
  }
}
