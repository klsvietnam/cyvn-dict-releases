import 'package:vgisc_glossary/app/base/app_settings.dart';
import 'package:vgisc_glossary/data/models/user_model.dart';
import 'package:vgisc_glossary/domain/entities/app_language.dart';
import 'package:flutter/material.dart';

class AppConstants {
  
  AppConstants._();

  static const dbName = 'dict.db';
  static const tempDbName = 'temp_dict.db';

  static String refLinkPrefix = AppSettings.refLinkPrefix;
  static String htmlTemplate = '';

  static String baseApiUrl = AppSettings.apiUrl;
  static const appIdentifier = 'com.klsvietnam.cyvn-dict';

  static const success = 0;

  static const error = 1;
}

class AppSharedKeys {
  AppSharedKeys._();

  static const username = 'username';
  static const password = 'password';
  static const rememberMe = 'remember_me';
}

class AppSession {
  AppSession._();

  static UserModel? currentUser;
  static bool autoLogin = true;
  static bool isLoggedIn = false;
  static String appVersion = '0.0.0.1';
}

class HiveIds {
  HiveIds._();

  static const userSettings = 0;
  
  static const appLanguage = 2;
  static const user = 3;
  static const attendedWords = 4;
}

final GlobalKey<ScaffoldMessengerState> globalScaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
final GlobalKey<ScaffoldState> globalScaffoldKey = GlobalKey<ScaffoldState>();

final gSupportedLanguages = [
  AppLanguage(languageCode: 'vi', countryCode: 'VN', displayText: 'Tiếng Việt'),
  AppLanguage(languageCode: 'en', countryCode: 'US', displayText: 'English'),
];
final gSupportedLocales = gSupportedLanguages.map((e) => e.locale).toList();
final gFallbackLocale = gSupportedLocales[0];
final gStartLocale = gSupportedLocales[0];
final gSupportedLangTexts = gSupportedLanguages.map((e) => e.displayText).toList();


const kIosInitialFontSize = 20;


const kWindowInitialFontSize = 28;
