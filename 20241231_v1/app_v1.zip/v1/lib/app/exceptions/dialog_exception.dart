import 'base_exception.dart';

class DialogException extends BaseException {
  // final Dialogs dialog;
  final String dialog;

  DialogException(int code, String message, {required this.dialog}) : super(code, message, ExceptionType.dialog);
}
