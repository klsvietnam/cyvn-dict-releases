import 'package:flutter/foundation.dart';

import '../utils/string_utils.dart';

enum ExceptionType { snack, toast, inline, alert, dialog, redirect, onPage }

abstract class BaseException implements Exception {
  final int code;
  final String message;
  final String? details;
  final ExceptionType exceptionType;

  const BaseException(this.code, this.message, this.exceptionType, {this.details});

  @override
  String toString() {
    final msg = <String>[];
    msg.add('$message ($code)');
    if (kDebugMode && StringUtils.isNotEmpty(details)) {
      msg.add(details!);
    }

    return msg.join('\r\n');
  }
}
