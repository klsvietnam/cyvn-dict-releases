import 'base_exception.dart';

class ToastException extends BaseException {
  ToastException(int code, String message, {String? details})
      : super(code, message, ExceptionType.toast, details: details);

}
