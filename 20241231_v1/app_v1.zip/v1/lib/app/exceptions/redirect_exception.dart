import 'base_exception.dart';

enum Redirect { openHomeScreen, openLoginScreen }

class RedirectException extends BaseException {
  final Redirect redirect;
  final dynamic data;

  RedirectException(
    int code,
    String message, {
    required this.redirect,
    required this.data,
  }) : super(code, message, ExceptionType.redirect);
}
