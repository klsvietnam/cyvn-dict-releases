import 'base_exception.dart';

class InlineException extends BaseException {
  // final List<Tag> tags;
  final List<String> tags;

  InlineException(int code, String message, {required this.tags}) : super(code, message, ExceptionType.inline);

  @override
  String toString() {
    return tags.join('\r\n');
  }
}
