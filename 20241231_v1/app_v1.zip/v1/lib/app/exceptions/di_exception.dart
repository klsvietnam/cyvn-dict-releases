import 'package:vgisc_glossary/app/exceptions/base_exception.dart';

/// dependency injection error
class DiException extends BaseException {
  DiException(String message) : super(-1, message, ExceptionType.alert);

  @override
  String toString() => 'Dependency injection Exception: $message';
}
