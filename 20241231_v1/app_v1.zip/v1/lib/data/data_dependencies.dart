import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/data/datasources/index.dart';
import 'package:vgisc_glossary/data/repositories/dictionary_repository_interface.dart';
import 'package:vgisc_glossary/data/repositories/index.dart';
import 'package:vgisc_glossary/data/repositories/web_dictionary_repository.dart';
import 'package:vgisc_glossary/di.dart';
import 'package:logging/logging.dart';

class DataDependencies {
  static final Logger logger = Logger((DataDependencies).toString());

  static Future<void> init() async {
    logger.fine('Start init data dependencies');

    try {
      /// datasource
      await LocalDataDependencies.init();
      await RemoteDataDependencies.init();

      /// repositories

      if (!kIsWeb) {
        DI.put<DictionaryRepositoryInterface>(DictionaryRepository(
          db: DI.get<AppDatabase>().dictionaryDb,
          api: DI.get<DictionaryApi>(),
        ));
      } else {
        DI.put<DictionaryRepositoryInterface>(WebDictionaryRepository(
          api: DI.get<DictionaryApi>(),
        ));
      }
    } catch (e, s) {
      logger.severe('Initialization error', e, s);
      rethrow;
    }

    logger.fine('Finish init data dependencies');
  }
}
