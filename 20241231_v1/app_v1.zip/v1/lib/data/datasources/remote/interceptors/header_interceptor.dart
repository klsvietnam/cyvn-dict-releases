import 'package:universal_platform/universal_platform.dart';

import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/data/datasources/local/shared_pref/index.dart';
import 'package:dio/dio.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:vgisc_glossary/data/datasources/local/shared_pref/pref_helper.dart';
import 'package:vgisc_glossary/di.dart';

// import 'package:web/web.dart' as html show window;

class HeaderInterceptor extends InterceptorsWrapper {
  final String userAgentKey = 'User-Agent';
  final String authHeaderKey = 'Authorization';
  final String bearer = 'Bearer';

  String? token;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) async {
    final userAgentValue = await userAgentClientHintsHeader();

    final pref = DI.get<PrefHelper>();

    // lưu token vào memory để tăng tốc request
    token ??= await pref.getToken();
    if (token?.isNotEmpty == true) {
      options.headers[authHeaderKey] = '$bearer $token';
      debugPrint('Add token to headers of request ${options.path}');
    } else {
      debugPrint('Token is empty');
    }
    if (!kIsWeb) {
      options.headers[userAgentKey] = userAgentValue;
    }

    handler.next(options);
  }

  Future<String> userAgentClientHintsHeader() async {
    try {
      final packageInfo = await PackageInfo.fromPlatform();
      return '${UniversalPlatform.operatingSystem} - ${packageInfo.buildNumber}';
    } on Exception catch (_) {
      return 'The Platform not support get info';
    }
  }
}
