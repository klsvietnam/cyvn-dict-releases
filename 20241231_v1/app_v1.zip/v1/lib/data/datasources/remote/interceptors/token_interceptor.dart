import 'dart:io';

import 'package:vgisc_glossary/app/base/index.dart';
import 'package:dio/dio.dart';
import 'package:vgisc_glossary/data/datasources/local/shared_pref/pref_helper.dart';
import 'package:vgisc_glossary/di.dart';

import '../api/user_api.dart';
import '../builder/dio_builder.dart';

class TokenInterceptor extends QueuedInterceptor {
  final Dio currentDio;
  final String auth = 'Authorization';
  final String bearer = 'Bearer';

  TokenInterceptor({required this.currentDio});

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) async {
    if (err.response != null && err.response?.statusCode == HttpStatus.unauthorized) {
      

      
      
      
      

      const tokenFromRequest = '';
      final tokenFromStorage = await DI.get<PrefHelper>().getToken();
      String? token = tokenFromStorage;

      
      
      

      
      final request = err.requestOptions;
      try {
        
        if (request.headers.containsKey(auth)) {
          
          request.headers
              .update(auth, (value) => (value.toString().contains(bearer) == true) ? '$bearer $token' : token);
        }

        final response = await currentDio.request(
          request.path,
          data: request.data,
          queryParameters: request.queryParameters,
          cancelToken: request.cancelToken,
          options: Options(
              method: request.method,
              sendTimeout: request.sendTimeout,
              extra: request.extra,
              headers: request.headers,
              responseType: request.responseType,
              contentType: request.contentType,
              receiveDataWhenStatusError: request.receiveDataWhenStatusError,
              followRedirects: request.followRedirects,
              maxRedirects: request.maxRedirects,
              requestEncoder: request.requestEncoder,
              responseDecoder: request.responseDecoder,
              listFormat: request.listFormat),
          onReceiveProgress: request.onReceiveProgress,
        );

        handler.resolve(response);
      } on DioException catch (e) {
        handler.next(e);
      }
    }

    super.onError(err, handler);
  }

  Future<String> requestToken() async {
    final dio = DioBuilder.getInstance(
        ignoredToken: true, options: BaseOptions(baseUrl: '${AppConstants.baseApiUrl}/requestToken'));
    try {
      final userApi = UserApi(dio);
      userApi.refreshToken();
    } on Exception catch (e, stacktrace) {
      return Future.error(e, stacktrace);
    }
    return 'token';
  }
}
