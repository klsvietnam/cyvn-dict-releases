import 'package:vgisc_glossary/data/index.dart';
import 'package:json_annotation/json_annotation.dart';

part 'dictionary_info_response.g.dart';

@JsonSerializable()
class DictionaryInfoResponse {
  final int status;

  @JsonKey(name: 'data')
  final DictionaryInfoModel? data;

  DictionaryInfoResponse(this.status, this.data);

  factory DictionaryInfoResponse.fromJson(Map<String, dynamic> json) => _$DictionaryInfoResponseFromJson(json);
  Map<String, dynamic> toJson() => _$DictionaryInfoResponseToJson(this);
}
