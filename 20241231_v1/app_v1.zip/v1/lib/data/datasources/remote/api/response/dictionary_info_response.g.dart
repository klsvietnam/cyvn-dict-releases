// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dictionary_info_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DictionaryInfoResponse _$DictionaryInfoResponseFromJson(
        Map<String, dynamic> json) =>
    DictionaryInfoResponse(
      (json['status'] as num).toInt(),
      json['data'] == null
          ? null
          : DictionaryInfoModel.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$DictionaryInfoResponseToJson(
        DictionaryInfoResponse instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
    };
