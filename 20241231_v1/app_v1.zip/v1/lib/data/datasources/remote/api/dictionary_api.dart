import 'package:vgisc_glossary/data/models/index.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/error_logger.dart';
import 'package:retrofit/http.dart';

part 'dictionary_api.g.dart';

@RestApi()
abstract class DictionaryApi {
  factory DictionaryApi(Dio dioBuilder) = _DictionaryApi;

  @GET('/api/checkLatestDic')
  Future<DictionaryInfoModel> checkLatest();

  @GET('/api/words')
  Future<List<WordViewModel>?> findAllWords();

  @GET('/api/words')
  Future<List<WordViewModel>?> findById(@Query('id') int wordId);

  // @POST('/downloadLatest')
  // Future<RegisterResponse> download();
}
