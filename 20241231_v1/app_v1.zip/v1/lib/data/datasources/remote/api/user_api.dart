import 'package:vgisc_glossary/data/index.dart';
import 'package:vgisc_glossary/data/models/token_data_model.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/error_logger.dart';
import 'package:retrofit/http.dart';

part 'user_api.g.dart';

@RestApi()
abstract class UserApi {
  factory UserApi(Dio dioBuilder) = _UserApi;

  @POST('/authenticate')
  Future<TokenDataModel> refreshToken();

  // @POST('/register')
  // Future<RegisterResponse> register(@Body() UserDataModel userDataModel);
}
