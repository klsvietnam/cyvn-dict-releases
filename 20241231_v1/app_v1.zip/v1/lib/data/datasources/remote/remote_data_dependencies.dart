import 'package:vgisc_glossary/app/base/app_constants.dart';
import 'package:vgisc_glossary/data/datasources/remote/api/dictionary_api.dart';
import 'package:vgisc_glossary/data/datasources/remote/api/user_api.dart';
import 'package:vgisc_glossary/data/datasources/remote/builder/dio_builder.dart';
import 'package:vgisc_glossary/di.dart';

import 'package:vgisc_glossary/data/datasources/index.dart';
import 'package:vgisc_glossary/data/repositories/index.dart';
import 'package:floor/floor.dart';
import 'package:logging/logging.dart';

class RemoteDataDependencies {
  static final Logger logger = Logger((RemoteDataDependencies).toString());

  static Future<void> init() async {
    logger.fine('Start init remote datasource');

    final _dioBuilder = DioBuilder.getInstance();
    DI.put<DioBuilder>(_dioBuilder);

    DI.put<DictionaryApi>(DictionaryApi(_dioBuilder));
    DI.put(UserApi(_dioBuilder));

    logger.fine('Finish init remote datasource');
  }
}
