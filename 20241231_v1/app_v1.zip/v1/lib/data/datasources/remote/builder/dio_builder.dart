import 'package:logging/logging.dart';
import 'package:vgisc_glossary/app/base/app_constants.dart';
import 'package:dio_smart_retry/dio_smart_retry.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/app/base/app_settings.dart';

import '../interceptors/index.dart';

class DioBuilder extends DioMixin implements Dio {
  static final logger = Logger((DioBuilder).toString());

  
  final String contentType = 'application/json';
  final int connectionTimeOutMls = 30000;
  final int readTimeOutMls = 30000;
  final int writeTimeOutMls = 30000;

  static DioBuilder getInstance({bool ignoredToken = false, BaseOptions? options}) =>
      DioBuilder._(ignoredToken, options);

  DioBuilder._(bool ignoredToken, [BaseOptions? options]) {
    options = BaseOptions(
      baseUrl: options?.baseUrl ?? AppConstants.baseApiUrl,
      contentType: contentType,
      connectTimeout: Duration(milliseconds: connectionTimeOutMls),
      receiveTimeout: Duration(milliseconds: readTimeOutMls),
      sendTimeout: Duration(milliseconds: writeTimeOutMls),
    );

    this.options = options;

    
    
    

    
    if (kDebugMode) {
      interceptors.add(LogInterceptor(responseBody: false, requestBody: false));
    }

    
    interceptors.add(HeaderInterceptor());

    
    if (!ignoredToken) {
      interceptors.add(TokenInterceptor(currentDio: this));
    }

    interceptors.add(RetryInterceptor(
      dio: this,
      logPrint: logger.info, 
      retries: AppSettings.apiErrorRetryCount, 
      retryDelays: const [
        
        Duration(seconds: 1), 
        Duration(seconds: 2), 
        Duration(seconds: 4), 
        Duration(seconds: 8),
        Duration(seconds: 16),
      ],
    ));
    logger.fine('Config API retry ${AppSettings.apiErrorRetryCount} times.');

    
    
    httpClientAdapter = HttpClientAdapter();
    
    
    
    
    
  }
}
