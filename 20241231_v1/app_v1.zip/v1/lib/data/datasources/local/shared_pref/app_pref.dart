import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:hive/hive.dart';
import 'package:logging/logging.dart';

import 'pref_helper.dart';

class AppPrefs extends PrefHelper {
  static final logger = Logger((AppPrefs).toString());

  static const String _firstRunKey = 'first_run_key';
  static const String _tokenKey = 'token_key';
  static const String _userKey = 'user_key';
  static const String _userSettingKey = 'user_setting_key';
  static const String _webAttendedWordKey = 'attended_words_key';

  final Box _prefBox;

  AppPrefs({required Box prefBox}) : _prefBox = prefBox;

  @override
  Future<bool> firstRun() async {
    return _prefBox.get(_firstRunKey) ?? true;
  }

  @override
  Future<void> setFirstRun(bool isFirstRun) async {
    await _prefBox.put(_firstRunKey, isFirstRun);
  }

  @override
  Future<String?> getToken() async {
    return _prefBox.get(_tokenKey);
  }

  @override
  Future setToken(String token) async {
    await _prefBox.put(_tokenKey, token);
  }

  @override
  Future<void> removeToken() async {
    await _prefBox.delete(_tokenKey);
  }

  @override
  Future<User?> getUserSaved() async {
    final User? user = _prefBox.get(_userKey);

    return user;
  }

  @override
  Future saveUser(User user) async {
    await _prefBox.put(_userKey, user);
  }

  @override
  Future<void> removeUserSaved() async {
    await _prefBox.delete(_userKey);
  }

  @override
  Future<void> saveUserSettings(UserSetting settings) async {
    await _prefBox.put(_userSettingKey, settings);
  }

  @override
  Future<UserSetting?> getUserSettings() async {
    final UserSetting? userSetting = _prefBox.get(_userSettingKey);

    return userSetting;
  }

  @override
  Future<void> removeUserSettings() async {
    await _prefBox.delete(_userSettingKey);
  }

  @override
  Future<List<WebAttendedWord>> getWebAttendedWords() async {
    if (!kIsWeb) {
      throw UnsupportedError('This method is supported for web platform only.');
    }
    final List<dynamic> items = await _prefBox.get(_webAttendedWordKey) ?? [];

    
    
    
    return items.cast<WebAttendedWord>();
  }

  @override
  Future<void> removeWebAttendedWord(int id) async {
    if (!kIsWeb) {
      throw UnsupportedError('This method is supported for web platform only.');
    }
    var items = await getWebAttendedWords();

    
    items = items.where((i) => i.id != id).toList();

    await saveWebAttendedWords(items);
  }

  @override
  Future<void> saveWebAttendedWords(List<WebAttendedWord> items) async {
    if (!kIsWeb) {
      throw UnsupportedError('This method is supported for web platform only.');
    }
    await _prefBox.put(_webAttendedWordKey, items);
  }
}
