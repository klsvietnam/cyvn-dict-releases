import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/app/base/app_settings.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:hive/hive.dart';
import 'package:vgisc_glossary/domain/entities/web_attended_word.dart';

import 'app_pref.dart';
import 'pref_helper.dart';

class AppStorage {
  AppStorage._();

  static AppStorage init() {
    Hive.registerAdapter(AppLanguageAdapter());
    Hive.registerAdapter(UserSettingAdapter());
    Hive.registerAdapter(UserAdapter());

    if (kIsWeb) {
      Hive.registerAdapter(WebAttendedWordAdapter());
    }

    return AppStorage._();
  }

  Future<PrefHelper> prefHelper() async {
    return AppPrefs(prefBox: await Hive.openBox(AppSettings.prefBox));
  }
}
