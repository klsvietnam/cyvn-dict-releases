import 'package:vgisc_glossary/domain/entities/index.dart';

abstract class PrefHelper {
  Future<bool> firstRun();

  Future<void> setFirstRun(bool isFirstRun);

  Future<String?> getToken();

  Future setToken(String token);

  Future<void> removeToken();

  Future saveUser(User user);

  Future<User?> getUserSaved();

  Future<void> removeUserSaved();

  Future<void> saveUserSettings(UserSetting settings);
  Future<UserSetting?> getUserSettings();
  Future<void> removeUserSettings();

  
  Future<void> saveWebAttendedWords(List<WebAttendedWord> items);
  Future<List<WebAttendedWord>> getWebAttendedWords();
  Future<void> removeWebAttendedWord(int id);
}
