import 'package:floor/floor.dart';
import 'package:intl/intl.dart';

class DateTimeConverter extends TypeConverter<DateTime, String> {
  @override
  DateTime decode(String databaseValue) {
    return DateTime.parse(databaseValue);
  }

  @override
  String encode(DateTime value) {
    return value.toIso8601String();
  }
}

class NullableDateTimeConverter extends TypeConverter<DateTime?, String?> {
  @override
  DateTime? decode(String? databaseValue) {
    if (databaseValue == null) return null;

    return DateTime.parse(databaseValue);
  }

  @override
  String? encode(DateTime? value) {
    if (value == null) return null;

    return value.toIso8601String();
  }
}
