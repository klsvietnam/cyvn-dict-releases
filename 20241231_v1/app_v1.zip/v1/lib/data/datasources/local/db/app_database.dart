import 'dart:async';
import 'package:vgisc_glossary/data/models/index.dart';
import 'package:floor/floor.dart';
import 'package:sqflite/sqflite.dart' as sqflite;

import 'date_time_converter.dart';
import 'dictionary_datasource.dart';

part 'app_database.g.dart'; // the generated code will be there

@Database(version: 2, entities: [
  AttendedWordModel,
  WordItemModel,
], views: [
  WordViewModel
])
@TypeConverters([DateTimeConverter, NullableDateTimeConverter])
abstract class AppDatabase extends FloorDatabase {
  DictionaryDataSource get dictionaryDb;
}
