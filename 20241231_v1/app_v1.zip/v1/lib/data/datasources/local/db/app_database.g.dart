

part of 'app_database.dart';





abstract class $AppDatabaseBuilderContract {
  
  $AppDatabaseBuilderContract addMigrations(List<Migration> migrations);

  
  $AppDatabaseBuilderContract addCallback(Callback callback);

  
  Future<AppDatabase> build();
}


class $FloorAppDatabase {
  
  
  static $AppDatabaseBuilderContract databaseBuilder(String name) =>
      _$AppDatabaseBuilder(name);

  
  
  
  static $AppDatabaseBuilderContract inMemoryDatabaseBuilder() =>
      _$AppDatabaseBuilder(null);
}

class _$AppDatabaseBuilder implements $AppDatabaseBuilderContract {
  _$AppDatabaseBuilder(this.name);

  final String? name;

  final List<Migration> _migrations = [];

  Callback? _callback;

  @override
  $AppDatabaseBuilderContract addMigrations(List<Migration> migrations) {
    _migrations.addAll(migrations);
    return this;
  }

  @override
  $AppDatabaseBuilderContract addCallback(Callback callback) {
    _callback = callback;
    return this;
  }

  @override
  Future<AppDatabase> build() async {
    final path = name != null
        ? await sqfliteDatabaseFactory.getDatabasePath(name!)
        : ':memory:';
    final database = _$AppDatabase();
    database.database = await database.open(
      path,
      _migrations,
      _callback,
    );
    return database;
  }
}

class _$AppDatabase extends AppDatabase {
  _$AppDatabase([StreamController<String>? listener]) {
    changeListener = listener ?? StreamController<String>.broadcast();
  }

  DictionaryDataSource? _dictionaryDbInstance;

  Future<sqflite.Database> open(
    String path,
    List<Migration> migrations, [
    Callback? callback,
  ]) async {
    final databaseOptions = sqflite.OpenDatabaseOptions(
      version: 2,
      onConfigure: (database) async {
        await database.execute('PRAGMA foreign_keys = ON');
        await callback?.onConfigure?.call(database);
      },
      onOpen: (database) async {
        await callback?.onOpen?.call(database);
      },
      onUpgrade: (database, startVersion, endVersion) async {
        await MigrationAdapter.runMigrations(
            database, startVersion, endVersion, migrations);

        await callback?.onUpgrade?.call(database, startVersion, endVersion);
      },
      onCreate: (database, version) async {
        await database.execute(
            'CREATE TABLE IF NOT EXISTS `attended_words` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `word_id` INTEGER NOT NULL, `seen` INTEGER, `seen_at` TEXT, `saved` INTEGER, `saved_at` TEXT, `last_update` TEXT)');
        await database.execute(
            'CREATE TABLE IF NOT EXISTS `word_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `english` TEXT NOT NULL, `vietnamese` TEXT NOT NULL, `abbreviation` TEXT, `explanation` TEXT NOT NULL, `synonym` TEXT, `deleted` INTEGER)');

        await database.execute(
            'CREATE VIEW IF NOT EXISTS `word_view` AS SELECT\n\twi.id,\n\twi.english,\n\twi.vietnamese,\n\twi.abbreviation,\n\twi.explanation,\n\taw.id AS attended_id,\n\taw.seen,\n\taw.seen_at,\n\taw.saved,\n\taw.saved_at\nFROM word_items wi\nLEFT JOIN attended_words aw ON wi.id = aw.word_id\n');

        await callback?.onCreate?.call(database, version);
      },
    );
    return sqfliteDatabaseFactory.openDatabase(path, options: databaseOptions);
  }

  @override
  DictionaryDataSource get dictionaryDb {
    return _dictionaryDbInstance ??=
        _$DictionaryDataSource(database, changeListener);
  }
}

class _$DictionaryDataSource extends DictionaryDataSource {
  _$DictionaryDataSource(
    this.database,
    this.changeListener,
  )   : _queryAdapter = QueryAdapter(database),
        _wordItemModelInsertionAdapter = InsertionAdapter(
            database,
            'word_items',
            (WordItemModel item) => <String, Object?>{
                  'id': item.id,
                  'english': item.english,
                  'vietnamese': item.vietnamese,
                  'abbreviation': item.abbreviation,
                  'explanation': item.explanation,
                  'synonym': item.synonym,
                  'deleted':
                      item.deleted == null ? null : (item.deleted! ? 1 : 0)
                }),
        _attendedWordModelInsertionAdapter = InsertionAdapter(
            database,
            'attended_words',
            (AttendedWordModel item) => <String, Object?>{
                  'id': item.id,
                  'word_id': item.wordId,
                  'seen':
                      item.isViewed == null ? null : (item.isViewed! ? 1 : 0),
                  'seen_at': _nullableDateTimeConverter.encode(item.viewAt),
                  'saved':
                      item.isSaved == null ? null : (item.isSaved! ? 1 : 0),
                  'saved_at': _nullableDateTimeConverter.encode(item.savedAt),
                  'last_update':
                      _nullableDateTimeConverter.encode(item.lastUpdateTime)
                }),
        _wordItemModelUpdateAdapter = UpdateAdapter(
            database,
            'word_items',
            ['id'],
            (WordItemModel item) => <String, Object?>{
                  'id': item.id,
                  'english': item.english,
                  'vietnamese': item.vietnamese,
                  'abbreviation': item.abbreviation,
                  'explanation': item.explanation,
                  'synonym': item.synonym,
                  'deleted':
                      item.deleted == null ? null : (item.deleted! ? 1 : 0)
                }),
        _attendedWordModelUpdateAdapter = UpdateAdapter(
            database,
            'attended_words',
            ['id'],
            (AttendedWordModel item) => <String, Object?>{
                  'id': item.id,
                  'word_id': item.wordId,
                  'seen':
                      item.isViewed == null ? null : (item.isViewed! ? 1 : 0),
                  'seen_at': _nullableDateTimeConverter.encode(item.viewAt),
                  'saved':
                      item.isSaved == null ? null : (item.isSaved! ? 1 : 0),
                  'saved_at': _nullableDateTimeConverter.encode(item.savedAt),
                  'last_update':
                      _nullableDateTimeConverter.encode(item.lastUpdateTime)
                });

  final sqflite.DatabaseExecutor database;

  final StreamController<String> changeListener;

  final QueryAdapter _queryAdapter;

  final InsertionAdapter<WordItemModel> _wordItemModelInsertionAdapter;

  final InsertionAdapter<AttendedWordModel> _attendedWordModelInsertionAdapter;

  final UpdateAdapter<WordItemModel> _wordItemModelUpdateAdapter;

  final UpdateAdapter<AttendedWordModel> _attendedWordModelUpdateAdapter;

  @override
  Future<List<WordViewModel>?> findAll() async {
    return _queryAdapter.queryList('SELECT * FROM word_view',
        mapper: (Map<String, Object?> row) => WordViewModel(
            id: row['id'] as int,
            english: row['english'] as String?,
            vietnamese: row['vietnamese'] as String?,
            abbreviation: row['abbreviation'] as String?,
            explanation: row['explanation'] as String,
            synonym: row['synonym'] as String?,
            deleted:
                row['deleted'] == null ? null : (row['deleted'] as int) != 0,
            attendedId: row['attended_id'] as int?,
            isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0,
            viewAt:
                _nullableDateTimeConverter.decode(row['seen_at'] as String?),
            isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0,
            savedAt:
                _nullableDateTimeConverter.decode(row['saved_at'] as String?)));
  }

  @override
  Future<WordViewModel?> findById(int id) async {
    return _queryAdapter.query('SELECT * FROM word_view WHERE id = ?1',
        mapper: (Map<String, Object?> row) => WordViewModel(
            id: row['id'] as int,
            english: row['english'] as String?,
            vietnamese: row['vietnamese'] as String?,
            abbreviation: row['abbreviation'] as String?,
            explanation: row['explanation'] as String,
            synonym: row['synonym'] as String?,
            deleted:
                row['deleted'] == null ? null : (row['deleted'] as int) != 0,
            attendedId: row['attended_id'] as int?,
            isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0,
            viewAt:
                _nullableDateTimeConverter.decode(row['seen_at'] as String?),
            isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0,
            savedAt:
                _nullableDateTimeConverter.decode(row['saved_at'] as String?)),
        arguments: [id]);
  }

  @override
  Future<WordViewModel?> findByWord(String word) async {
    return _queryAdapter.query(
        'SELECT * FROM word_view WHERE (english = ?1) OR (vietnamese = ?1) LIMIT 1',
        mapper: (Map<String, Object?> row) => WordViewModel(id: row['id'] as int, english: row['english'] as String?, vietnamese: row['vietnamese'] as String?, abbreviation: row['abbreviation'] as String?, explanation: row['explanation'] as String, synonym: row['synonym'] as String?, deleted: row['deleted'] == null ? null : (row['deleted'] as int) != 0, attendedId: row['attended_id'] as int?, isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0, viewAt: _nullableDateTimeConverter.decode(row['seen_at'] as String?), isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0, savedAt: _nullableDateTimeConverter.decode(row['saved_at'] as String?)),
        arguments: [word]);
  }

  @override
  Future<List<WordViewModel>?> findBy(String word) async {
    return _queryAdapter.queryList(
        'SELECT * FROM word_view WHERE (english LIKE ?1) OR (vietnamese LIKE ?1) OR (abbreviation LIKE ?1)',
        mapper: (Map<String, Object?> row) => WordViewModel(id: row['id'] as int, english: row['english'] as String?, vietnamese: row['vietnamese'] as String?, abbreviation: row['abbreviation'] as String?, explanation: row['explanation'] as String, synonym: row['synonym'] as String?, deleted: row['deleted'] == null ? null : (row['deleted'] as int) != 0, attendedId: row['attended_id'] as int?, isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0, viewAt: _nullableDateTimeConverter.decode(row['seen_at'] as String?), isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0, savedAt: _nullableDateTimeConverter.decode(row['saved_at'] as String?)),
        arguments: [word]);
  }

  @override
  Future<List<WordViewModel>?> findLastViewedWords(
    int limit,
    int offset,
  ) async {
    return _queryAdapter.queryList(
        'SELECT * FROM word_view WHERE seen_at IS NOT NULL ORDER BY seen_at DESC LIMIT ?1 OFFSET ?2',
        mapper: (Map<String, Object?> row) => WordViewModel(id: row['id'] as int, english: row['english'] as String?, vietnamese: row['vietnamese'] as String?, abbreviation: row['abbreviation'] as String?, explanation: row['explanation'] as String, synonym: row['synonym'] as String?, deleted: row['deleted'] == null ? null : (row['deleted'] as int) != 0, attendedId: row['attended_id'] as int?, isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0, viewAt: _nullableDateTimeConverter.decode(row['seen_at'] as String?), isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0, savedAt: _nullableDateTimeConverter.decode(row['saved_at'] as String?)),
        arguments: [limit, offset]);
  }

  @override
  Future<List<WordViewModel>?> findSavedWords(
    int limit,
    int offset,
  ) async {
    return _queryAdapter.queryList(
        'SELECT * FROM word_view WHERE saved_at IS NOT NULL ORDER BY english ASC LIMIT ?1 OFFSET ?2',
        mapper: (Map<String, Object?> row) => WordViewModel(id: row['id'] as int, english: row['english'] as String?, vietnamese: row['vietnamese'] as String?, abbreviation: row['abbreviation'] as String?, explanation: row['explanation'] as String, synonym: row['synonym'] as String?, deleted: row['deleted'] == null ? null : (row['deleted'] as int) != 0, attendedId: row['attended_id'] as int?, isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0, viewAt: _nullableDateTimeConverter.decode(row['seen_at'] as String?), isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0, savedAt: _nullableDateTimeConverter.decode(row['saved_at'] as String?)),
        arguments: [limit, offset]);
  }

  @override
  Future<AttendedWordModel?> findAttendedWordById(int id) async {
    return _queryAdapter.query('SELECT * FROM attended_words WHERE id = ?1',
        mapper: (Map<String, Object?> row) => AttendedWordModel(
            id: row['id'] as int?,
            wordId: row['word_id'] as int,
            isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0,
            viewAt:
                _nullableDateTimeConverter.decode(row['seen_at'] as String?),
            isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0,
            savedAt:
                _nullableDateTimeConverter.decode(row['saved_at'] as String?),
            lastUpdateTime: _nullableDateTimeConverter
                .decode(row['last_update'] as String?)),
        arguments: [id]);
  }

  @override
  Future<AttendedWordModel?> findAttendedWordByWordId(int wordId) async {
    return _queryAdapter.query(
        'SELECT * FROM attended_words WHERE word_id = ?1 LIMIT 1',
        mapper: (Map<String, Object?> row) => AttendedWordModel(
            id: row['id'] as int?,
            wordId: row['word_id'] as int,
            isViewed: row['seen'] == null ? null : (row['seen'] as int) != 0,
            viewAt:
                _nullableDateTimeConverter.decode(row['seen_at'] as String?),
            isSaved: row['saved'] == null ? null : (row['saved'] as int) != 0,
            savedAt:
                _nullableDateTimeConverter.decode(row['saved_at'] as String?),
            lastUpdateTime: _nullableDateTimeConverter
                .decode(row['last_update'] as String?)),
        arguments: [wordId]);
  }

  @override
  Future<void> insertWordItem(WordItemModel item) async {
    await _wordItemModelInsertionAdapter.insert(item, OnConflictStrategy.abort);
  }

  @override
  Future<void> insertAttendedWord(AttendedWordModel item) async {
    await _attendedWordModelInsertionAdapter.insert(
        item, OnConflictStrategy.abort);
  }

  @override
  Future<void> updateWordItem(WordItemModel item) async {
    await _wordItemModelUpdateAdapter.update(item, OnConflictStrategy.abort);
  }

  @override
  Future<void> updateAttendedWord(AttendedWordModel item) async {
    await _attendedWordModelUpdateAdapter.update(
        item, OnConflictStrategy.abort);
  }
}


final _dateTimeConverter = DateTimeConverter();
final _nullableDateTimeConverter = NullableDateTimeConverter();
