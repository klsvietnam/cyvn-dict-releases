import 'package:vgisc_glossary/data/index.dart';
import 'package:floor/floor.dart';

@dao
abstract class DictionaryDataSource {
  @Query('SELECT * FROM word_view')
  Future<List<WordViewModel>?> findAll();

  @Query('SELECT * FROM word_view WHERE id = :id')
  Future<WordViewModel?> findById(int id);

  @Query('SELECT * FROM word_view WHERE (english = :word) OR (vietnamese = :word) LIMIT 1')
  Future<WordViewModel?> findByWord(String word);

  @Query('SELECT * FROM word_view '
      'WHERE (english LIKE :word) '
      'OR (vietnamese LIKE :word) '
      'OR (abbreviation LIKE :word) '
      // 'OR (explanation LIKE :word)'
      )
  Future<List<WordViewModel>?> findBy(String word);

  @Query('SELECT * FROM word_view WHERE seen_at IS NOT NULL ORDER BY seen_at DESC LIMIT :limit OFFSET :offset')
  Future<List<WordViewModel>?> findLastViewedWords(int limit, int offset);

  @Query('SELECT * FROM word_view WHERE saved_at IS NOT NULL ORDER BY english ASC LIMIT :limit OFFSET :offset')
  Future<List<WordViewModel>?> findSavedWords(int limit, int offset);

  @insert
  Future<void> insertWordItem(WordItemModel item);

  @update
  Future<void> updateWordItem(WordItemModel item);

  @Query('SELECT * FROM attended_words WHERE id = :id')
  Future<AttendedWordModel?> findAttendedWordById(int id);

  @Query('SELECT * FROM attended_words WHERE word_id = :wordId LIMIT 1')
  Future<AttendedWordModel?> findAttendedWordByWordId(int wordId);

  @insert
  Future<void> insertAttendedWord(AttendedWordModel item);

  @update
  Future<void> updateAttendedWord(AttendedWordModel item);
}
