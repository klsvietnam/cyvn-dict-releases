import 'dart:io';

import 'package:logging/logging.dart';
import 'package:sqflite/sqflite.dart';
import 'package:vgisc_glossary/app/index.dart';

class DbMigrator {
  static final logger = Logger((DbMigrator).toString());

  
  
  
  
  
  Future<bool> migrate() async {
    final dbPath = await DbUtils.getDbPath(dbName: AppConstants.dbName);

    
    if (!await File(dbPath).exists()) {
      logger.info('1. Copy DB to migrate');
      await DbUtils.copyDb(
        overwrite: true,
        assetDbName: AppConstants.dbName,
        targetDbName: AppConstants.dbName,
      );
      return true;
    }

    Database? tempDb;
    Database? workingDb;

    try {
      
      bool needMigration = false;
      workingDb = await openDatabase(await DbUtils.getDbPath(dbName: AppConstants.dbName));
      final isWorkingSettingExists = await isTableExists(workingDb, 'settings');
      if (!isWorkingSettingExists) {
        logger.info('There is no table settings. Have to migrate.');
        needMigration = true;
      } else {
        final workingDbVersion = await getSetting(workingDb, 'version');
        if (StringUtils.isEmpty(workingDbVersion) || workingDbVersion!.compareTo(AppSettings.assetDbVersion) < 0) {
          logger.info(
              'Working version: $workingDbVersion, asset version: ${AppSettings.assetDbVersion}. Have to migrate.');
          needMigration = true;
        }
      }

      if (!needMigration) {
        logger.info('Version is the same. No need to migrate.');
        return true;
      }

      
      await DbUtils.copyDb(
        overwrite: true,
        assetDbName: AppConstants.dbName,
        targetDbName: AppConstants.tempDbName,
      );
      tempDb = await openDatabase(await DbUtils.getDbPath(dbName: AppConstants.tempDbName));

      
      await copyAndUpdateData(tempDb, workingDb);

      
      await updateDbVersion(workingDb, AppSettings.assetDbVersion);

      return true;
    } on Exception catch (e, stacktrace) {
      logger.severe('Có lỗi khi migrate DB', e, stacktrace);
    } finally {
      
      await tempDb?.close();
      await workingDb?.close();

      
      await DbUtils.deleteTempDb(AppConstants.tempDbName);
    }

    return false;
  }

  
  Future<bool> isTableExists(Database database, String tableName) async {
    final List<Map<String, dynamic>> result = await database.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
      [tableName],
    );
    return result.isNotEmpty;
  }

  
  Future<String?> getSetting(Database database, String key, {String? subKey}) async {
    var conditions = 'key=?';
    final args = [key];
    if (StringUtils.isNotEmpty(subKey)) {
      conditions += ' AND sub_key=?';
      args.add(subKey!);
    }

    final List<Map<String, dynamic>> result = await database.query(
      'settings',
      where: conditions,
      whereArgs: args,
      limit: 1,
    );

    if (result.isNotEmpty) {
      return result.first['value']; 
    }

    return null;
  }

  Future<void> copyAndUpdateData(Database db1, Database db2) async {
    const tempTableName = 'temp_word_items';
    const mainTableName = 'word_items';

    updateColumn(String columnName) =>
        '$columnName = (SELECT $columnName FROM $tempTableName temp WHERE temp.id = main.id)';

    try {
      
      await db2.execute('''
CREATE TABLE IF NOT EXISTS `$tempTableName` (
  `id` INTEGER NOT NULL, 
  `english` TEXT NOT NULL, 
  `vietnamese` TEXT NOT NULL, 
  `abbreviation` TEXT, 
  `explanation` TEXT NOT NULL, 
  `synonym` TEXT, 
  "deleted" INTEGER NULL, 
  PRIMARY KEY (`id`)
);
      ''');

      
      await db2.delete(tempTableName);

      
      final List<Map<String, dynamic>> data = await db1.query(mainTableName);

      
      for (final row in data) {
        await db2.insert(tempTableName, row);
      }

      
      await db2.execute('''
UPDATE $mainTableName AS main
SET 
  ${updateColumn('english')},
  ${updateColumn('vietnamese')},
  ${updateColumn('abbreviation')},
  ${updateColumn('explanation')},
  ${updateColumn('synonym')},
  ${updateColumn('deleted')}
WHERE EXISTS (
  SELECT 1 FROM $tempTableName temp WHERE temp.id = main.id
);
      ''');

      
      await db2.execute('''
INSERT INTO "$mainTableName" ("id", "english", "vietnamese", "abbreviation", "explanation", "synonym", "deleted") 
SELECT "id", "english", "vietnamese", "abbreviation", "explanation", "synonym", "deleted" FROM $tempTableName AS temp
WHERE temp.id NOT IN (SELECT id FROM $mainTableName);
      ''');

      
      await db2.execute('''
UPDATE $mainTableName AS main
SET 
	deleted = 1
WHERE main.id NOT IN (SELECT id FROM $tempTableName)
OR main.id IN (SELECT id FROM $tempTableName temp WHERE temp.deleted = 1);
      ''');

      logger.info("Data copied and updated successfully.");
    } catch (e, stacktrace) {
      logger.severe("Error during update DB", e, stacktrace);
      rethrow;
    }
  }

  Future<void> updateDbVersion(Database db, String tempDbVersion) async {
    
    if (!await isTableExists(db, 'settings')) {
      await db.execute('''
CREATE TABLE IF NOT EXISTS "settings" (
	"id" INTEGER NOT NULL,
	"key" TEXT NOT NULL,
	"sub_key" TEXT NULL,
	"value" TEXT NOT NULL,
	PRIMARY KEY ("id")
);
      ''');
    }

    final version = await getSetting(db, 'version');
    if (version == null) {
      
      await db.execute('INSERT INTO "settings" ("key", "value") VALUES (?, ?);', ['version', tempDbVersion]);
    } else {
      
      await db.execute('UPDATE "settings" SET value=? WHERE key=?;', [tempDbVersion, 'version']);
    }
  }
}
