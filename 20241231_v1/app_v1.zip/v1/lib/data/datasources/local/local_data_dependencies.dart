import 'package:universal_platform/universal_platform.dart';

import 'package:flutter/foundation.dart';
import 'package:vgisc_glossary/app/index.dart';
import 'package:vgisc_glossary/data/datasources/index.dart';
import 'package:vgisc_glossary/data/datasources/local/shared_pref/pref_helper.dart';
import 'package:vgisc_glossary/di.dart';
import 'package:floor/floor.dart';
import 'package:hive/hive.dart';
import 'package:logging/logging.dart';
import 'package:path_provider/path_provider.dart';

class LocalDataDependencies {
  static final Logger logger = Logger((LocalDataDependencies).toString());

  static Future<void> init() async {
    logger.fine('Start init local datasource');

    
    if (!kIsWeb) {
      final dir = UniversalPlatform.isWindows
          ? await getApplicationSupportDirectory()
          : await getApplicationDocumentsDirectory();
      Hive.init(dir.path);
      logger.fine('Hive\'s path is: ${dir.path}');
    }

    final pref = await AppStorage.init().prefHelper();
    DI.put<PrefHelper>(pref);

    final isFirstRun = await pref.firstRun();
    if (isFirstRun) {
      if (!kIsWeb) {
        logger.fine('First run. init DB');
        await DbUtils.copyDb();
      }

      await pref.setFirstRun(false);
    } else {
      if (!kIsWeb) {
        logger.fine('Not first run. DB is located at ${await DbUtils.getDbPath()}');
        await DbUtils.migrateDb();
      }
    }

    if (kIsWeb) {
      logger.info('Finish init local datasource. {firstRun: $isFirstRun}');
      return;
    }

    
    final dbPath = await DbUtils.getDbPath();
    final db =
        await $FloorAppDatabase.databaseBuilder(dbPath).addCallback(dbCallback()).addMigrations(dbMigrations()).build();
    DI.put<AppDatabase>(db);

    logger.info('Finish init local datasource. {firstRun: $isFirstRun, db path: $dbPath');
  }

  static Callback dbCallback() {
    return Callback(
      onCreate: (db, version) => logger.fine('DB $db, version $version is created'),
      onOpen: (db) => logger.fine('DB $db is opened'),
      onUpgrade: (db, startVersion, endVersion) =>
          logger.fine('DB $db is upgraded (from version $startVersion to $endVersion'),
    );
  }

  static List<Migration> dbMigrations() {
    final migration1To2 = Migration(1, 2, (db) async {
      const sqlList = [
        'ALTER TABLE word_items ADD COLUMN deleted INTEGER',
        'ALTER TABLE attended_words ADD COLUMN seen_at INTEGER',
        'ALTER TABLE attended_words ADD COLUMN saved_at INTEGER',
        'DROP VIEW IF EXISTS word_view',
        'CREATE VIEW IF NOT EXISTS `word_view` AS SELECT\n\twi.id,\n\twi.english,\n\twi.vietnamese,\n\twi.abbreviation,\n\twi.explanation,\n\taw.id AS attended_id,\n\taw.seen,\n\taw.seen_at,\n\taw.saved,\n\taw.saved_at\nFROM word_items wi\nLEFT JOIN attended_words aw ON wi.id = aw.word_id',
      ];

      try {
        
        await db.execute(sqlList.join(';'));
        
      } on Exception catch (e) {
        logger.severe('Error in migration1To2', e);
      }
    });

    return [
      
    ];
  }
}
