import 'package:json_annotation/json_annotation.dart';

import 'base/data_model.dart';

part 'dictionary_info_model.g.dart';

@JsonSerializable()
class DictionaryInfoModel with DataModel {
  final int? dictId;
  final String? dictName;
  final String? hash;
  final DateTime? lastChanged;

  DictionaryInfoModel(this.dictId, this.dictName, this.hash, this.lastChanged);

  factory DictionaryInfoModel.fromJson(Map<String, dynamic> json) => _$DictionaryInfoModelFromJson(json);

  Map<String, dynamic> toJson() => _$DictionaryInfoModelToJson(this);
}
