import 'package:floor/floor.dart';
import 'package:json_annotation/json_annotation.dart';

part 'word_item_model.g.dart';

@JsonSerializable()
@Entity(tableName: 'word_items')
class WordItemModel {
  @PrimaryKey(autoGenerate: true)
  final int? id;

  final String english;
  final String vietnamese;

  
  final String? abbreviation;

  
  final String explanation;

  
  final String? synonym;

  
  @ColumnInfo(name: 'deleted')
  final bool? deleted;

  WordItemModel({
    required this.id,
    required this.english,
    required this.vietnamese,
    this.abbreviation,
    required this.explanation,
    this.synonym,
    this.deleted = false,
  });

  factory WordItemModel.fromJson(Map<String, dynamic> json) =>
      _$WordItemModelFromJson(json);
  Map<String, dynamic> toJson() => _$WordItemModelToJson(this);

  @override
  String toString() {
    return 'WordItemModel{id: $id, english: $english, vietnamese: $vietnamese}';
  }
}
