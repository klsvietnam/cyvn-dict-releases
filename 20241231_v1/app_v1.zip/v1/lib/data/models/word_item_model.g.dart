// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'word_item_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

WordItemModel _$WordItemModelFromJson(Map<String, dynamic> json) =>
    WordItemModel(
      id: (json['id'] as num?)?.toInt(),
      english: json['english'] as String,
      vietnamese: json['vietnamese'] as String,
      abbreviation: json['abbreviation'] as String?,
      explanation: json['explanation'] as String,
      synonym: json['synonym'] as String?,
      deleted: json['deleted'] as bool? ?? false,
    );

Map<String, dynamic> _$WordItemModelToJson(WordItemModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'english': instance.english,
      'vietnamese': instance.vietnamese,
      'abbreviation': instance.abbreviation,
      'explanation': instance.explanation,
      'synonym': instance.synonym,
      'deleted': instance.deleted,
    };
