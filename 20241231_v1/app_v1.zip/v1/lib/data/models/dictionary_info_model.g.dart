// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dictionary_info_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DictionaryInfoModel _$DictionaryInfoModelFromJson(Map<String, dynamic> json) =>
    DictionaryInfoModel(
      (json['dictId'] as num?)?.toInt(),
      json['dictName'] as String?,
      json['hash'] as String?,
      json['lastChanged'] == null
          ? null
          : DateTime.parse(json['lastChanged'] as String),
    );

Map<String, dynamic> _$DictionaryInfoModelToJson(
        DictionaryInfoModel instance) =>
    <String, dynamic>{
      'dictId': instance.dictId,
      'dictName': instance.dictName,
      'hash': instance.hash,
      'lastChanged': instance.lastChanged?.toIso8601String(),
    };
