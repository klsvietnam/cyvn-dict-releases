import 'package:json_annotation/json_annotation.dart';

part 'paging_result_model.g.dart';

@JsonSerializable(genericArgumentFactories: true)
class PagingResultModel<T> {
  @JsonKey(name: 'results')
  final List<T>? results;

  @JsonKey(name: 'totalSize')
  final int? totalSize;

  @JsonKey(name: 'pageIndex')
  final int? pageIndex;

  @JsonKey(name: 'pageSize')
  final int? pageSize;

  PagingResultModel({
    this.results,
    this.totalSize,
    this.pageIndex,
    this.pageSize,
  });

  factory PagingResultModel.fromJson(Map<String, dynamic> json, T Function(Object? json) fromJsonT) =>
      _$PagingResultModelFromJson<T>(json, fromJsonT);

  Map<String, dynamic> toJson(Object? Function(T value) toJsonT) => _$PagingResultModelToJson(this, toJsonT);
}
