import 'dart:io';

import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';

import 'base_error.dart';

enum AppErrorType {
  network,
  badRequest,
  unauthorized,
  notFound,
  cancel,
  timeout,
  server,
  business,
  unknown,
}

class AppError {
  final String message;

  /// chi ti?t l?i
  final String? details;
  final AppErrorType type;

  final int? headerCode;
  final List<BaseError>? errors;

  AppError(this.type, this.message, {this.details, int? code, List<BaseError>? err})
      : headerCode = code,
        errors = err;

  factory AppError.from(Exception error) {
    var type = AppErrorType.unknown;
    var message = '';
    var details = '';
    int? headerCode;
    List<BaseError>? errors;

    if (error is DioException) {
      message = error.message ?? 'Error occurs';
      headerCode = error.response?.statusCode ?? -1;

      switch (error.type) {
        case DioExceptionType.connectionTimeout:
        case DioExceptionType.receiveTimeout:
          type = AppErrorType.timeout;
          break;
        case DioExceptionType.sendTimeout:
          type = AppErrorType.network;
          break;
        case DioExceptionType.badResponse:
          switch (error.response?.statusCode) {
            case HttpStatus.unauthorized: // 401
              type = AppErrorType.unauthorized;
              break;
            case HttpStatus.badRequest: // 400
            case HttpStatus.notFound: // 404
            case HttpStatus.methodNotAllowed: // 405
            case HttpStatus.unprocessableEntity: // 422
            case HttpStatus.internalServerError: // 500
            case HttpStatus.badGateway: // 502
            case HttpStatus.serviceUnavailable: // 503
            case HttpStatus.gatewayTimeout: // 504
              type = AppErrorType.server;
              errors = [BaseError(errorCode: -1, message: error.message)];
              break;
            default:
              type = AppErrorType.unknown;
              break;
          }
          break;
        case DioExceptionType.cancel:
          type = AppErrorType.cancel;
          break;

        case DioExceptionType.unknown:
        default:
          if (error.error is SocketException) {
            // SocketException: Failed host lookup: '***'
            // (OS Error: No address associated with hostname, errno = 7)
            type = AppErrorType.network;
            final err = error.error as SocketException;
            details = '${err.osError ?? 'messages.error_internet_connection'.tr()} (${err.address}:${err.port})';
          } else {
            type = AppErrorType.unknown;
          }
          break;
      }
    } else {
      type = AppErrorType.unknown;
      message = '$error';
    }

    return AppError(type, message, details: details, code: headerCode, err: errors);
  }

  @override
  String toString() {
    return 'AppError{type: $type, message: $message, headerCode: $headerCode, errors: $errors}';
  }
}
