import 'package:json_annotation/json_annotation.dart';

part 'base_error.g.dart';

@JsonSerializable()
class BaseError {
  @JsonKey(name: 'code')
  final int? errorCode;

  @JsonKey(name: 'message')
  final String? message;

  BaseError({this.errorCode, this.message});

  factory BaseError.fromJson(Map<String, dynamic> json) => _$BaseErrorFromJson(json);
  Map<String, dynamic> toJson() => _$BaseErrorToJson(this);

  @override
  String toString() {
    return 'code: $errorCode, message: $message';
  }
}
