// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'paging_result_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PagingResultModel<T> _$PagingResultModelFromJson<T>(
  Map<String, dynamic> json,
  T Function(Object? json) fromJsonT,
) =>
    PagingResultModel<T>(
      results: (json['results'] as List<dynamic>?)?.map(fromJsonT).toList(),
      totalSize: (json['totalSize'] as num?)?.toInt(),
      pageIndex: (json['pageIndex'] as num?)?.toInt(),
      pageSize: (json['pageSize'] as num?)?.toInt(),
    );

Map<String, dynamic> _$PagingResultModelToJson<T>(
  PagingResultModel<T> instance,
  Object? Function(T value) toJsonT,
) =>
    <String, dynamic>{
      'results': instance.results?.map(toJsonT).toList(),
      'totalSize': instance.totalSize,
      'pageIndex': instance.pageIndex,
      'pageSize': instance.pageSize,
    };
