// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'word_view_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

WordViewModel _$WordViewModelFromJson(Map<String, dynamic> json) =>
    WordViewModel(
      id: (json['id'] as num).toInt(),
      english: json['english'] as String?,
      vietnamese: json['vietnamese'] as String?,
      abbreviation: json['abbreviation'] as String?,
      explanation: json['explanation'] as String,
      synonym: json['synonym'] as String?,
      deleted: json['deleted'] == null
          ? false
          : WordViewModel._boolFromInt((json['deleted'] as num?)?.toInt()),
      attendedId: (json['attendedId'] as num?)?.toInt(),
      isViewed: json['isViewed'] as bool? ?? false,
      viewAt: json['viewAt'] == null
          ? null
          : DateTime.parse(json['viewAt'] as String),
      isSaved: json['isSaved'] as bool? ?? false,
      savedAt: json['savedAt'] == null
          ? null
          : DateTime.parse(json['savedAt'] as String),
    );

Map<String, dynamic> _$WordViewModelToJson(WordViewModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'english': instance.english,
      'vietnamese': instance.vietnamese,
      'abbreviation': instance.abbreviation,
      'explanation': instance.explanation,
      'synonym': instance.synonym,
      'deleted': WordViewModel._boolToInt(instance.deleted),
      'attendedId': instance.attendedId,
      'isViewed': instance.isViewed,
      'viewAt': instance.viewAt?.toIso8601String(),
      'isSaved': instance.isSaved,
      'savedAt': instance.savedAt?.toIso8601String(),
    };
