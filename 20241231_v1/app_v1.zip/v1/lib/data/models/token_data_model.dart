import 'package:json_annotation/json_annotation.dart';

import 'base/data_model.dart';

part 'token_data_model.g.dart';

@JsonSerializable(checked: true)
class TokenDataModel with DataModel {
  final String? token;

  TokenDataModel(this.token);

  factory TokenDataModel.fromJson(Map<String, dynamic> json) => _$TokenDataModelFromJson(json);

  Map<String, dynamic> toJson() => _$TokenDataModelToJson(this);
}
