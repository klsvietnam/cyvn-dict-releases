import 'package:floor/floor.dart';
import 'package:json_annotation/json_annotation.dart';

part 'attended_word_model.g.dart';




@JsonSerializable()
@Entity(tableName: 'attended_words')
class AttendedWordModel {
  @PrimaryKey(autoGenerate: true)
  final int? id;

  @ColumnInfo(name: 'word_id')
  final int wordId;

  @ColumnInfo(name: 'seen')
  final bool? isViewed;

  @ColumnInfo(name: 'seen_at')
  final DateTime? viewAt;

  @ColumnInfo(name: 'saved')
  final bool? isSaved;

  @ColumnInfo(name: 'saved_at')
  final DateTime? savedAt;

  @ColumnInfo(name: 'last_update')
  final DateTime? lastUpdateTime;

  AttendedWordModel({
    required this.id,
    required this.wordId,
    this.isViewed = false,
    this.viewAt,
    this.isSaved = false,
    this.savedAt,
    this.lastUpdateTime,
  });

  AttendedWordModel copyWith({
    bool? isViewed,
    DateTime? viewAt,
    bool? isSaved,
    DateTime? savedAt,
    DateTime? lastUpdateTime,
  }) {
    return AttendedWordModel(
      id: id,
      wordId: wordId,
      isViewed: isViewed ?? this.isViewed,
      viewAt: viewAt ?? this.viewAt,
      isSaved: isSaved ?? this.isSaved,
      savedAt: savedAt ?? this.savedAt,
      lastUpdateTime: lastUpdateTime ?? this.lastUpdateTime,
    );
  }

  factory AttendedWordModel.fromJson(Map<String, dynamic> json) => _$AttendedWordModelFromJson(json);

  Map<String, dynamic> toJson() => _$AttendedWordModelToJson(this);

  @override
  String toString() {
    return 'AttendedWordModel{id: $id, word_id: $wordId, seen: $isViewed, saved: $isSaved, last update: $lastUpdateTime}';
  }
}
