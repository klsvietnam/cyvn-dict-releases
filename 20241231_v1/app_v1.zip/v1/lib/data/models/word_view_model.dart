import 'package:floor/floor.dart';
import 'package:json_annotation/json_annotation.dart';

part 'word_view_model.g.dart';




@JsonSerializable()
@DatabaseView('''
SELECT
	wi.id,
	wi.english,
	wi.vietnamese,
	wi.abbreviation,
	wi.explanation,
	aw.id AS attended_id,
	aw.seen,
	aw.seen_at,
	aw.saved,
	aw.saved_at
FROM word_items wi
LEFT JOIN attended_words aw ON wi.id = aw.word_id
''', viewName: 'word_view')
class WordViewModel {
  final int id;
  final String? english;
  final String? vietnamese;

  
  final String? abbreviation;

  
  final String explanation;

  
  final String? synonym;

  
  @JsonKey(fromJson: _boolFromInt, toJson: _boolToInt)
  final bool? deleted;

  static bool? _boolFromInt(int? deleted) => deleted != null ? deleted == 1 : null;

  static int? _boolToInt(bool? deleted) => deleted != null ? (deleted ? 1 : 0) : null;

  @ColumnInfo(name: 'attended_id')
  final int? attendedId;

  @ColumnInfo(name: 'seen')
  final bool? isViewed;
  @ColumnInfo(name: 'seen_at')
  final DateTime? viewAt;

  @ColumnInfo(name: 'saved')
  final bool? isSaved;
  @ColumnInfo(name: 'saved_at')
  final DateTime? savedAt;

  WordViewModel({
    required this.id,
    required this.english,
    required this.vietnamese,
    required this.abbreviation,
    required this.explanation,
    required this.synonym,
    this.deleted = false,
    this.attendedId,
    this.isViewed = false,
    this.viewAt,
    this.isSaved = false,
    this.savedAt,
  });

  factory WordViewModel.fromJson(Map<String, dynamic> json) => _$WordViewModelFromJson(json);
  Map<String, dynamic> toJson() => _$WordViewModelToJson(this);

  @override
  String toString() {
    return 'WordViewModel{id: $id, en: $english, vi: $vietnamese, abbr: $abbreviation, seen: $isViewed, saved: $isSaved}';
  }
}
