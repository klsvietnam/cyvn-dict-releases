// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'token_data_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TokenDataModel _$TokenDataModelFromJson(Map<String, dynamic> json) =>
    $checkedCreate(
      'TokenDataModel',
      json,
      ($checkedConvert) {
        final val = TokenDataModel(
          $checkedConvert('token', (v) => v as String?),
        );
        return val;
      },
    );

Map<String, dynamic> _$TokenDataModelToJson(TokenDataModel instance) =>
    <String, dynamic>{
      'token': instance.token,
    };
