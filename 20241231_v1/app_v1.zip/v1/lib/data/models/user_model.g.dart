// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserModel _$UserModelFromJson(Map<String, dynamic> json) => UserModel(
      (json['id'] as num?)?.toInt(),
      json['name'] as String,
      json['fullName'] as String,
      json['email'] as String?,
      json['phoneNumber'] as String,
      (json['languageId'] as num?)?.toInt(),
      (json['roleIds'] as List<dynamic>?)
          ?.map((e) => (e as num).toInt())
          .toList(),
    );

Map<String, dynamic> _$UserModelToJson(UserModel instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'fullName': instance.fullName,
      'email': instance.email,
      'phoneNumber': instance.phoneNumber,
      'languageId': instance.languageId,
      'roleIds': instance.roleIds,
    };
