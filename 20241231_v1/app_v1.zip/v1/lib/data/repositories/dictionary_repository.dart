import 'package:vgisc_glossary/data/index.dart';
import 'package:vgisc_glossary/data/repositories/dictionary_repository_interface.dart';
import 'package:vgisc_glossary/data/repositories/exception_mapper.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:logging/logging.dart';
import '../models/base/app_error.dart';
import 'base_repository.dart';

class DictionaryRepository extends BaseRepository implements DictionaryRepositoryInterface {
  static final logger = Logger((DictionaryRepository).toString());
  late final DictionaryDataSource db;
  late final DictionaryApi api;
  final ExceptionMapper _exceptionMapper = ExceptionMapper();

  DictionaryRepository({required this.db, required this.api});

  @override
  Future<List<WordView>> findAllWords() async {
    final words = await db.findAll() ?? [];
    return words.map(mapWordViewModelToEntity).toList();
  }

  @override
  Future<List<WordView>> findBy(String query) async {
    final words = await db.findBy('%$query%') ?? [];
    return words.map(mapWordViewModelToEntity).toList();
  }

  @override
  Future<WordView?> findById(int wordId) async {
    final model = await db.findById(wordId);
    if (model == null) {
      return null;
    }

    return mapWordViewModelToEntity(model);
  }

  @override
  Future<WordView?> findByWord(String word) async {
    final model = await db.findByWord(word);
    if (model == null) {
      return null;
    }

    return mapWordViewModelToEntity(model);
  }

  @override
  Future<AttendedWord?> findAttendedWordById(int attendedId) async {
    final model = await db.findAttendedWordById(attendedId);
    if (model == null) {
      return null;
    }

    return mapAttendedWordModelToEntity(model);
  }

  @override
  Future<AttendedWord?> findAttendedWordByWordId(int wordId) async {
    final model = await db.findAttendedWordByWordId(wordId);
    if (model == null) {
      return null;
    }

    return mapAttendedWordModelToEntity(model);
  }

  @override
  Future<void> createOrUpdateAttendedWord({
    required int wordId,
    bool? isViewed,
    DateTime? viewAt,
    bool? isSaved,
    DateTime? savedAt,
    DateTime? lastUpdateTime,
  }) async {
    final model = await db.findAttendedWordByWordId(wordId);

    if (model != null) {
      return db.updateAttendedWord(model.copyWith(
        isViewed: isViewed,
        viewAt: viewAt,
        isSaved: isSaved,
        savedAt: savedAt,
        lastUpdateTime: lastUpdateTime ?? DateTime.now(),
      ));
    } else {
      return db.insertAttendedWord(AttendedWordModel(
        id: null,
        wordId: wordId,
        isViewed: isViewed,
        viewAt: viewAt,
        isSaved: isSaved,
        savedAt: savedAt,
        lastUpdateTime: lastUpdateTime,
      ));
    }
  }

  @override
  Future<List<WordView>> findLastViewedWords({int page = 1, int size = 10}) async {
    int limit = size <= 0 ? 10 : size;
    int offset = page <= 0 ? size : (page - 1) * size;
    final lastViewedWords = await db.findLastViewedWords(limit, offset) ?? [];

    return lastViewedWords.map(mapWordViewModelToEntity).toList();
  }

  @override
  Future<List<WordView>> findSavedWords({int page = 1, int size = 10}) async {
    int limit = size <= 0 ? 10 : size;
    int offset = page <= 0 ? size : (page - 1) * size;
    final lastViewedWords = await db.findSavedWords(limit, offset) ?? [];

    return lastViewedWords.map(mapWordViewModelToEntity).toList();
  }

  @override
  Future<DictionaryInfoModel> checkLatestDic() async {
    try {
      return await api.checkLatest();
    } on Exception catch (e) {
      throw await _exceptionMapper.mapperTo(AppError.from(e));
    }
  }
}
