import 'package:vgisc_glossary/data/index.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';

abstract class DictionaryRepositoryInterface {
  Future<List<WordView>> findAllWords();

  Future<List<WordView>> findBy(String query);

  Future<WordView?> findById(int wordId);

  Future<WordView?> findByWord(String word);

  Future<AttendedWord?> findAttendedWordById(int attendedId);

  Future<AttendedWord?> findAttendedWordByWordId(int wordId);

  Future<void> createOrUpdateAttendedWord({
    required int wordId,
    bool? isViewed,
    DateTime? viewAt,
    bool? isSaved,
    DateTime? savedAt,
    DateTime? lastUpdateTime,
  });

  Future<List<WordView>> findLastViewedWords({int page = 1, int size = 10});

  Future<List<WordView>> findSavedWords({int page = 1, int size = 10});

  Future<DictionaryInfoModel> checkLatestDic();
}
