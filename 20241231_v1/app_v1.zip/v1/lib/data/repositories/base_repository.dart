import 'package:vgisc_glossary/data/index.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:flutter/foundation.dart';

abstract class BaseRepository {
  @protected
  WordView mapWordViewModelToEntity(WordViewModel model) {
    return WordView(
      id: model.id,
      english: model.english,
      vietnamese: model.vietnamese,
      abbreviation: model.abbreviation,
      explanation: model.explanation,
      synonym: model.synonym,
      deleted: model.deleted,
      attendedId: model.attendedId,
      isViewed: model.isViewed,
      viewAt: model.viewAt,
      isSaved: model.isSaved,
      savedAt: model.savedAt,
    );
  }

  @protected
  AttendedWord mapAttendedWordModelToEntity(AttendedWordModel model) {
    return AttendedWord(
      id: model.id,
      wordId: model.wordId,
      isViewed: model.isViewed,
      viewAt: model.viewAt,
      isSaved: model.isSaved,
      savedAt: model.savedAt,
      lastUpdateTime: model.lastUpdateTime,
    );
  }

  @protected
  AttendedWordModel mapAttendedWordEntityToModel(AttendedWord entity) {
    return AttendedWordModel(
      id: entity.id,
      wordId: entity.wordId,
      isViewed: entity.isViewed,
      viewAt: entity.viewAt,
      isSaved: entity.isSaved,
      savedAt: entity.savedAt,
      lastUpdateTime: entity.lastUpdateTime,
    );
  }
}
