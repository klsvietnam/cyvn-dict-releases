import 'package:vgisc_glossary/app/utils/string_utils.dart';
import 'package:vgisc_glossary/data/models/base/base_error.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../app/exceptions/base_exception.dart';
import '../../app/exceptions/inline_exception.dart';
import '../../app/exceptions/on_page_exception.dart';
import '../../app/exceptions/redirect_exception.dart';
import '../../app/exceptions/toast_exception.dart';
import '../models/base/app_error.dart';

class ExceptionMapper {
  ExceptionMapper();

  Future<AppError> mapperFrom(BaseException exception) => throw UnimplementedError();

  Future<BaseException> mapperTo(AppError error) async {
    switch (error.type) {
      case AppErrorType.network:
        return ToastException(-1, 'messages.error_internet_connection'.tr(), details: error.details);

      case AppErrorType.server:
        if (error.errors?.length == 1) {
          return await _mapperFromSingleError(error.errors!.first);
        } else if ((error.errors?.length ?? 0) > 1) {
          return await _mapperFromMultipleErrors(error.errors!);
        } else {
          return ToastException(-1, error.message, details: error.details);
        }

      case AppErrorType.unauthorized: 
        return RedirectException(
          -1,
          error.message,
          redirect: Redirect.openLoginScreen,
          data: null,
        );

      case AppErrorType.unknown:
      case AppErrorType.cancel:
      case AppErrorType.timeout:
      default:
        return ToastException(-1, error.message);
    }
  }

  Future<BaseException> _mapperFromSingleError(BaseError errorDataModel) async {
    switch (errorDataModel.errorCode) {
      case 1000:
      default:
        return OnPageException(errorDataModel.errorCode!, errorDataModel.message!);
    }
  }

  
  Future<BaseException> _mapperFromMultipleErrors(List<BaseError> errors) async {
    final tagList = await _mapperFromErrors(errors);
    return InlineException(-1, 'multiple errors will appear to check multiple fields', tags: tagList);
  }

  Future<List<String>> _mapperFromErrors(List<BaseError> errors) async {
    final tags = <String>[];
    for (var error in errors) {
      
      if (StringUtils.isNotEmpty(error.message)) {
        tags.add(error.message!);
      }
    }

    return tags;
  }
}
