import 'package:vgisc_glossary/data/datasources/local/shared_pref/pref_helper.dart';
import 'package:vgisc_glossary/data/index.dart';
import 'package:vgisc_glossary/data/repositories/dictionary_repository_interface.dart';
import 'package:vgisc_glossary/data/repositories/exception_mapper.dart';
import 'package:vgisc_glossary/di.dart';
import 'package:vgisc_glossary/domain/entities/index.dart';
import 'package:logging/logging.dart';
import '../models/base/app_error.dart';
import 'base_repository.dart';

class WebDictionaryRepository extends BaseRepository implements DictionaryRepositoryInterface {
  static final logger = Logger((WebDictionaryRepository).toString());
  late final DictionaryApi api;
  final ExceptionMapper _exceptionMapper = ExceptionMapper();

  WebDictionaryRepository({required this.api});

  @override
  Future<List<WordView>> findAllWords() async {
    final words = await api.findAllWords() ?? [];
    final attendedWords = await DI.get<PrefHelper>().getWebAttendedWords();

    
    final finalWords = words.map((w) => _mapWordViewModelToEntityForWeb(w, attendedWords)).toList();

    return finalWords.map(mapWordViewModelToEntity).toList();
  }

  @override
  Future<List<WordView>> findBy(String query) async {
    throw UnimplementedError('Method is not used. This method is for implementation of interface purpose only.');
  }

  @override
  Future<WordView?> findById(int wordId) async {
    final w = await api.findById(wordId);
    if (w == null || w.isEmpty) {
      return null;
    }

    final attendedWords = await DI.get<PrefHelper>().getWebAttendedWords();
    return mapWordViewModelToEntity(_mapWordViewModelToEntityForWeb(w[0], attendedWords));
  }

  WordViewModel _mapWordViewModelToEntityForWeb(WordViewModel apiModel, List<WebAttendedWord> localAttendedWords) {
    final attendedWord = localAttendedWords.where((i) => i.wordId == apiModel.id).firstOrNull;
    return attendedWord == null
        ? apiModel
        : WordViewModel(
            id: apiModel.id,
            english: apiModel.english,
            vietnamese: apiModel.vietnamese,
            abbreviation: apiModel.abbreviation,
            explanation: apiModel.explanation,
            synonym: apiModel.synonym,
            deleted: apiModel.deleted,
            attendedId: attendedWord.id,
            isViewed: attendedWord.isViewed,
            viewAt: attendedWord.viewAt,
            isSaved: attendedWord.isSaved,
            savedAt: attendedWord.savedAt,
          );
  }

  @override
  Future<WordView?> findByWord(String word) async {
    throw UnimplementedError('Method is not used. This method is for implementation of interface purpose only.');
  }

  @override
  Future<AttendedWord?> findAttendedWordById(int attendedId) async {
    throw UnimplementedError('Method is not used. This method is for implementation of interface purpose only.');
  }

  @override
  Future<AttendedWord?> findAttendedWordByWordId(int wordId) async {
    final attendedWords = await DI.get<PrefHelper>().getWebAttendedWords();

    final webAttendedWord = attendedWords.where((i) => i.wordId == wordId).firstOrNull;

    if (webAttendedWord == null) {
      return null;
    }

    return AttendedWord(
      id: webAttendedWord.id,
      wordId: webAttendedWord.wordId,
      isViewed: webAttendedWord.isViewed,
      viewAt: webAttendedWord.viewAt,
      isSaved: webAttendedWord.isSaved,
      savedAt: webAttendedWord.savedAt,
      lastUpdateTime: webAttendedWord.lastUpdateTime,
    );
  }

  @override
  Future<void> createOrUpdateAttendedWord({
    required int wordId,
    bool? isViewed,
    DateTime? viewAt,
    bool? isSaved,
    DateTime? savedAt,
    DateTime? lastUpdateTime,
  }) async {
    logger.fine('update attended word BEGIN');
    final sharedPref = DI.get<PrefHelper>();
    var attendedWords = await sharedPref.getWebAttendedWords();

    final webAttendedWord = attendedWords.where((i) => i.wordId == wordId).firstOrNull;
    if (webAttendedWord == null) {
      attendedWords.add(WebAttendedWord(
        id: attendedWords.fold<int>(0, (max, item) => (item.id != null && item.id! > max) ? item.id! : max) + 1,
        wordId: wordId,
        isViewed: isViewed,
        viewAt: viewAt,
        isSaved: isSaved,
        savedAt: savedAt,
        lastUpdateTime: lastUpdateTime ?? DateTime.now(),
      ));
    } else {
      attendedWords = attendedWords.map((item) {
        if (item.id == webAttendedWord.id) {
          return item;
        }

        return WebAttendedWord(
          id: item.id,
          wordId: item.wordId,
          isViewed: isViewed,
          viewAt: viewAt,
          isSaved: isSaved,
          savedAt: savedAt,
          lastUpdateTime: lastUpdateTime ?? DateTime.now(),
        );
      }).toList();
    }

    
    sharedPref.saveWebAttendedWords(attendedWords);
    logger.fine('update attended word END');
  }

  @override
  Future<List<WordView>> findLastViewedWords({int page = 1, int size = 10}) async {
    throw UnimplementedError('Method is not used. This method is for implementation of interface purpose only.');
  }

  @override
  Future<List<WordView>> findSavedWords({int page = 1, int size = 10}) async {
    throw UnimplementedError('Method is not used. This method is for implementation of interface purpose only.');
  }

  @override
  Future<DictionaryInfoModel> checkLatestDic() async {
    try {
      return await api.checkLatest();
    } on Exception catch (e) {
      throw await _exceptionMapper.mapperTo(AppError.from(e));
    }
  }
}
