import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider/path_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  test('Show all supported directories', () async {
    final dirList = {
      'cache': getApplicationCacheDirectory(),
      'documents': getApplicationDocumentsDirectory(),
      'support': getApplicationSupportDirectory(),
      'download': getDownloadsDirectory(),
      'library': getLibraryDirectory(),
      // 'temporary': getTemporaryDirectory(),
    };

    for (final key in dirList.keys) {
      final path = await dirList[key];
      debugPrint('$key : $path');
    }
  });
}
