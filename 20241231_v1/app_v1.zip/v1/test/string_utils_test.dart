import 'package:vgisc_glossary/app/index.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('StringUtils stripHtmlTags', () {
    const html =
        '<p>Là một loại chữ ký điện tử trong mật mã học, trong đó chữ ký được tạo ra bằng cách sử dụng một định danh của thực thể.</p><p>Điều này cho phép người dùng không cần phải có một cặp khóa (khóa công khai và khóa riêng tư), và thay vào đó có thể sử dụng định danh của họ để tạo và xác minh chữ ký. Xem <a href="https://abc.com/x">Identity-based cryptography</a>.</p> ';
    debugPrint(StringUtils.stripHtmlTags(html));
  });
}
