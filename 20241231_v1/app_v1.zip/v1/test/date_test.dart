import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Date format with milliseconds', () {
    debugPrint(DateFormat('yyyy/MM/dd HH:mm:ss/.sss').format(DateTime.now()));
    debugPrint(DateTime.now().toIso8601String());

    print(DateTime.parse('2024-10-23T09:26:55.898737'));
  });
}
